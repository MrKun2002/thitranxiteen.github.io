<?php

/*
function gtranslate($var){
$nf = loadhtml('http://translate.google.com.vn/m?hl=vi&sl=auto&tl=vi&ie=UTF-8&prev=_m&q='.urlencode($var));
preg_match('/<div dir="ltr" class="t0">(.*?)<\/div>/', $nf, $m);
echo $m[1];
}
function checkper($user_id, $id){
$rights=0;
$req=mysql_query("select `type`,`id`,`refid` from `forum` where `id`='$id'");
$res=mysql_fetch_assoc($req);
if($res['type']=='f'){
$re1=mysql_query("select `usid` from `forum_per` where `usid`='$user_id' and `fid`='$id' and `r`='1'");
$ffid=$id;
if(mysql_num_rows($re1)>0)
$rights=1;
}
if($res['type']=='r'){
$re1=mysql_query("select `usid` from `forum_per` where `usid`='$user_id' and `fid`='".$res['refid']."' and `r`='1'");
if(mysql_num_rows($re1)>0)
$rights=1;
}

if($res['type']=='t'){
$req1=mysql_query("select `type`,`refid` from `forum` where `id`='".$res['refid']."'");
$res1=mysql_fetch_assoc($req1);
$re1=mysql_query("select `usid` from `forum_per` where `usid`='$user_id' and `fid`='".$res1['refid']."' and `r`='1'");
if(mysql_num_rows($re1)>0)
$rights=1;
}
if($res['type']=='m'){
$req1=mysql_query("select `type`,`refid` from `forum` where `id`='".$res['refid']."'");
$res1=mysql_fetch_assoc($req1);
$req2=mysql_query("select `type`,`refid` from `forum` where `id`='".$res1['refid']."'");
$res2=mysql_fetch_assoc($req2);
$re1=mysql_query("select `usid` from `forum_per` where `usid`='$user_id' and `fid`='".$res2['refid']."' and `r`='1'");
if(mysql_num_rows($re1)>0)
$rights=1;
}
return $rights;
}



function keyw ($str) {
        $url = "http://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=" . urlencode($str) . '&rsz=large&start=1';
        $body = loadhtml ($url);
        $json = json_decode($body);
        for($x=0;$x<count($json->responseData->results);$x++){
        $tt  .= ',' . $json->responseData->results[$x]->title . ',' . $json->responseData->results[$x]->content;
        }
        preg_match_all ('#<b>(.+?)</b>#',$tt,$result);
        foreach (array_unique($result[0]) as $kw) {
              $keyw .=  (preg_replace (array('#<b>#','#</b>#','#\.+#'),array('','',''),$kw)) . ',';
        }
        return $keyw;
}

function laynoidung($noidung, $start, $stop) {
$bd = explode($start,$noidung);
$kt = explode($stop, $bd[1]);
$content = $kt[0];
return $content;
}
function delhtml($text){
$nd = array("/\<em\>(.*?)\<\/em\>/is" => "$1", "/\<b\>(.*?)\<\/b\>/is" => "$1",
"/\<i\>(.*?)\<\/i\>/is" => "$1",
"/\<u\>(.*?)\<\/u\>/is" => "$1",
"/\<s\>(.*?)\<\/s\>/is" => "$1",
"/\<center\>(.*?)\<\/center\>/is" => "$1", "/\<h2\>(.*?)\<\/h2\>/is" => "$1", "/\<p\>(.*?)\<\/p\>/is" => "$1", "/\<ul\>(.*?)\<\/ul\>/is" => "$1", "/\<li\>(.*?)\<\/li\>/is" => "$1", "/\<div class=(.*?)\>(.*?)\<\/div\>/is" => "$2", "/\<div align=(.*?)\>(.*?)\<\/div\>/is" => "$2", "/\<span style=(.*?)\>(.*?)\<\/span\>/is" => "$2", "/\<span class=(.*?)\>(.*?)\<\/span\>/is" => "$2", "/\<I class=(.*?)\>(.*?)\<\/I\>/is" => "$2", "/\<I style=(.*?)\>(.*?)\<\/I\>/is" => "$2", "/\<strong\>(.*?)\<\/strong\>/is" => "$1", "/\<br class=(.*?)\>/is" => "", "/\<z (.*?)\>/is" => "", "/\<em\>(.*?)\<\/em\>/is" => "$1", "/\<font size=(.*?)\>(.*?)\<\/font\>/is" => "$2", "/\<div style=(.*?)\>(.*?)\<\/div\>/is" => "$2", "/\<font(.*?)\>(.*?)\<\/font\>/is" => "$2", "/\<td(.*?)\>(.*?)\<\/td\>/is" => "$2", "/\<tr(.*?)\>(.*?)\<\/tr\>/is" => "$2", "/\<p(.*?)\>(.*?)\<\/p\>/is" => "$2", "/\<a href=(.*?)\>Tải ảnh về máy\<\/a\>/is" => "");
$text = preg_replace(array_keys($nd), array_values($nd), $text);
return $text;
}
*/
function nokia($str) {
    $gd =  array("A"=>"A",	"a"=>"a",
		"B"=>"B",	"b"=>"b",
		"C"=>"C",	"c"=>"c",
		"D"=>"D",	"d"=>"d",
		"E"=>"E",	"e"=>"e",
		"F"=>"F",	"f"=>"f",
		"G"=>"G",	"g"=>"g",
		"H"=>"H",	"h"=>"h",
		"I"=>"I",	"i"=>"i",
		"J"=>"J",	"j"=>"j",
		"K"=>"K",	"k"=>"k",
		"L"=>"L",	"l"=>"l",
		"M"=>"M",	"m"=>"m",
		"N"=>"N",	"n"=>"n",
		"O"=>"O",	"o"=>"o",
		"P"=>"P",	"p"=>"p",
		"R"=>"R",	"r"=>"r",
		"S"=>"S",	"s"=>"s",
		"T"=>"T",	"t"=>"t",
		"U"=>"U",	"u"=>"u",
		"V"=>"V",	"v"=>"v",
		"W"=>"W",	"w"=>"w",
		"Y"=>"Y",	"y"=>"y",
		"Z"=>"Z",	"z"=>"z",
		"Á"=>"Á",	"Ã"=>"Ã",	"Ạ"=>"Ạ",	"À"=>"À",	"Ả"=>"Ả",
		"É"=>"É",	"Ẽ"=>"Ẽ",	"Ẹ"=>"Ẹ",	"È"=>"È",	"Ẻ"=>"Ẻ",
		"Ý"=>"Ý",	"Ỹ"=>"Ỹ",	"Ỵ"=>"Ỵ",	"Ỳ"=>"Ỳ",	"Ỷ"=>"Ỷ",
		"Ú"=>"Ú",	"Ũ"=>"Ũ",	"Ụ"=>"Ụ",	"Ù"=>"Ù",	"Ủ"=>"Ủ",
		"Ó"=>"Ó",	"Õ"=>"Õ",	"Ọ"=>"Ọ",	"Ò"=>"Ò",	"Ỏ"=>"Ỏ",
		"Í"=>"Í",	"Ĩ"=>"Ĩ",	"Ị"=>"Ị",	"Ì"=>"Ì",	"Ỉ"=>"Ỉ",
		"Ấ"=>"Ấ",	"Ẫ"=>"Ẫ",	"Ậ"=>"Ậ",		"Ầ"=>"Ầ",	"Ẩ"=>"Ẩ",
		"Ế"=>"Ế",	"Ễ"=>"Ễ",	"Ệ"=>"Ệ",		"Ề"=>"Ề",	"Ể"=>"Ể",
		"Ố"=>"Ố",	"Ỗ"=>"Ỗ",	"Ộ"=>"Ộ",		"Ồ"=>"Ồ",	"Ổ"=>"Ổ",
		"Ớ"=>"Ớ",	"Ỡ"=>"Ỡ",	"Ợ"=>"Ợ",		"Ờ"=>"Ờ",	"Ở"=>"Ở",
		"Ắ"=>"Ắ",	"Ẵ"=>"Ẵ",	"Ặ"=>"Ặ",		"Ằ"=>"Ằ",	"Ẳ"=>"Ẳ",
		"Ứ"=>"Ứ",	"Ữ"=>"Ữ",	"Ự"=>"Ự",		"Ừ"=>"Ừ",	"Ử"=>"Ử",
		"á"=>"á",	"ã"=>"ã",	"ạ"=>"ạ",	"à"=>"à",	"ả"=>"ả",
		"é"=>"é",	"ẽ"=>"ẽ",	"ẹ"=>"ẹ",	"è"=>"è",	"ẻ"=>"ẻ",
		"ý"=>"ý",	"ỹ"=>"ỹ",	"ỵ"=>"ỵ",	"ỳ"=>"ỳ",	"ỷ"=>"ỷ",
		"ú"=>"ú",	"ũ"=>"ũ",	"ụ"=>"ụ",	"ù"=>"ù",	"ủ"=>"ủ",
		"ó"=>"ó",	"õ"=>"õ",	"ọ"=>"ọ",	"ò"=>"ò",	"ỏ"=>"ỏ",
		"í"=>"í",	"ĩ"=>"ĩ",	"ị"=>"ị",	"ì"=>"ì",	"ỉ"=>"ỉ",
		"ấ"=>"ấ",	"ẫ"=>"ẫ",	"ậ"=>"ậ",	"ầ"=>"ầ",	"ẩ"=>"ẩ",
		"ế"=>"ế",	"ễ"=>"ễ",	"ệ"=>"ệ",	"ề"=>"ề",	"ể"=>"ể",
		"ố"=>"ố",	"ỗ"=>"ỗ",	"ộ"=>"ộ",	"ồ"=>"ồ",	"ổ"=>"ổ",
		"ế"=>"ế",	"ễ"=>"ễ",	"ệ"=>"ệ",	"ề"=>"ề",	"ể"=>"ể",
		"ớ"=>"ớ",	"ỡ"=>"ỡ",	"ợ"=>"ợ",	"ờ"=>"ờ",	"ở"=>"ở",
		"ắ"=>"ắ",	"ẵ"=>"ẵ",	"ặ"=>"ặ",	"ằ"=>"ằ",	"ẳ"=>"ẳ",
		"ứ"=>"ứ",	"ữ"=>"ữ",	"ự"=>"ự",	"ừ"=>"ừ",	"ử"=>"ử");
$a = str_replace(array_keys($gd), array_values($gd), $str);
return $a;
}
/*
function chuyen($link){
header("Location: $link");
}
function catchuoi($chuoi,$gioihan){
$chuoi = preg_replace('#\[b\](.*?)\[/b\]#si', '\1',$chuoi);
$chuoi = preg_replace('#\[i\](.*?)\[/i\]#si', '\1',$chuoi);
$chuoi = preg_replace('#\[u\](.*?)\[/u\]#si', '\1',$chuoi);
$chuoi = preg_replace('#\[s\](.*?)\[/s\]#si', '\1',$chuoi);
$chuoi = preg_replace('#\[center\](.*?)\[/center\]#si', '\1',$chuoi);
$chuoi = preg_replace("#\[url=(. ?)\](. ?)\[/url\]#is", "\\1",$chuoi);
$chuoi = preg_replace("#\[URL=(. ?)\](. ?)\[/URL\]#is", "\\2",$chuoi);
$chuoi = preg_replace("#\[IMG\](. ?)\[/IMG\]#is", "\\1",$chuoi);
$chuoi = preg_replace("#\[COLOR=(.*?)\](.*?)\[/COLOR\]#is", "\\2",$chuoi);
$chuoi = preg_replace("#\[SIZE=(.*?)\](. ?)\[/SIZE\]#is", "\\2",$chuoi);
$chuoi = preg_replace("#\[FONT=(.*?)\](. ?)\[/FONT\]#is", "\\2",$chuoi);
$chuoi = preg_replace("#\[BG=(.*?)\](. ?)\[/BG\]#is", "\\2",$chuoi);
$chuoi = preg_replace("#\[7MAU\](.*?)\[/7MAU\]#is", "\\1",$chuoi);
$chuoi = preg_replace("#\[CODE=(.*?)\](. ?)\[/CODE\]#is", "\\2",$chuoi);
$chuoi = preg_replace("#\[PHP=(.*?)\](. ?)\[/PHP\]#is", "\\2",$chuoi);
$chuoi = str_replace('<br/>','',$chuoi);
$chuoi = str_replace('[code]','',$chuoi);
$chuoi = str_replace('[php]','',$chuoi);
$chuoi = str_replace('[img]','',$chuoi);
if(strlen($chuoi)<=$gioihan){
return $chuoi;
} else {
if(strpos($chuoi," ",$gioihan) > $gioihan){
$new_gioihan=strpos($chuoi," ",$gioihan);
$new_chuoi = substr($chuoi,0,$new_gioihan);
return ''.$new_chuoi.'...';}
$new_chuoi = substr($chuoi,0,$gioihan);
return ''.$new_chuoi.'...';
}
}
*/
function convert_char_noki($text) {
$nokia=array(
'á','ả','à' ,'ã','ạ','ắ','ẳ','ằ','ẵ','ặ',
'ấ','ẩ','ầ','ẫ','ậ','é','ẻ','è','ẽ','ẹ',
'ế','ể','ề','ễ','ệ','ó','ỏ','ò','õ','ọ',
'ố','ổ','ồ','ỗ','ộ','ớ','ở','ờ','ỡ','ợ',
'ú','ủ','ù','ũ','ụ','ứ','ử','ừ','ữ','ự',
'ý','ỷ','ỳ','ỹ','ỵ','í','ỉ','ì','ĩ','ị',
'Á','Ả','À','Ã','Ạ','Ắ','Ẳ','Ằ','Ẵ','Ặ',
'Ấ','Ẩ','Ầ','Ẫ','Ậ','É','Ẻ','È','Ẽ','Ẹ',
'Ế','Ể','Ề','Ễ','Ệ','Ó','Ỏ','Ò','Õ','Ọ',
'Ố','Ổ','Ồ','Ỗ','Ộ','Ớ','Ở','Ờ','Ỡ','Ợ',
'Ú','Ủ','Ù','Ũ','Ụ','Ứ','Ử','Ừ','Ữ','Ự',
'Ý','Ỷ','Ỳ','Ỹ','Ỵ','Í','Ỉ','Ì','Ĩ','Ị'
);
$pc=array(
'á','ả','à' ,'ã','ạ','ắ','ẳ','ằ','ẵ','ặ',
'ấ','ẩ','ầ','ẫ','ậ','é','ẻ','è','ẽ','ẹ',
'ế','ể','ề','ễ','ệ','ó','ỏ','ò','õ','ọ',
'ố','ổ','ồ','ỗ','ộ','ớ','ở','ờ','ỡ','ợ',
'ú','ủ','ù','ũ','ụ','ứ','ử','ừ','ữ','ự',
'ý','ỷ','ỳ','ỹ','ỵ','í','ỉ','ì','ĩ','ị',
'Á','Ả','À','Ã','Ạ','Ắ','Ẳ','Ằ','Ẵ','Ặ',
'Ấ','Ẩ','Ầ','Ẫ','Ậ','É','Ẻ','È','Ẽ','Ẹ',
'Ế','Ể','Ề','Ễ','Ệ','Ó','Ỏ','Ò','Õ','Ọ',
'Ố','Ổ','Ồ','Ỗ','Ộ','Ớ','Ở','Ờ','Ỡ','Ợ',
'Ú','Ủ','Ù','Ũ','Ụ','Ứ','Ử','Ừ','Ữ','Ự',
'Ý','Ỷ','Ỳ','Ỹ','Ỵ','Í','Ỉ','Ì','Ĩ','Ị'
);
$text = str_replace($nokia, $pc, $text);
return $text;
}
function curl_get($url){
$data = curl_init();
curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($data, CURLOPT_URL, $url);
$hasil = curl_exec($data);
curl_close($data);
return $hasil;
}
function nick($id, $mod = false) { 
$ban = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" . $id . "' AND `ban_time` > '" . time() . "'"), 0); 
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '" . $id . "'")); 
if($ban > 0) { 
$out .= '<font color="black">'.($mod == 1 ? '<small>' : '<b>').'<s>' . $user['name'] . '</s>'.($mod == 1 ? '</small>' : '</b>').'</font>'; 
} else { 
if($user['rights'] >= 0) { 
if($user['rights'] == 0) {$font = ' <font color="#000000">';} 
if($user['rights'] == 2) {$font = ' <font color="blue">';} 
if($user['rights'] == 3) {$font = ' <font color="green">';} 
if($user['rights'] == 5) {$font = ' <font color="#ff9000">';} 
if($user['rights'] == 8) {$font = ' <font color="#FF66E6">';} 
if($user['rights'] == 6) {$font = ' <font color="#993399">';} 
if($user['rights'] == 7) {$font = ' <font color="red">';} 
if($user['rights'] == 9) {$font = ' <font color="red">';} 
if($user['rights'] == 10) {$font = '<font color="#7000E0">';} 
$out .= ''.$font.'' . $user['name'] . '</font>'; 
} else { 
$out .= '<font color="blue">' . $user['name'] . '</font>'; 
} 
} 
return $out; 
}
// Nick khong mau
function tennick($id, $mod = false) { 
$ban = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" . $id . "' AND `ban_time` > '" . time() . "'"), 0); 
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '" . $id . "'")); 
$out .= $user['name'];  
return $out; 
}
//--- Hàm hiển thị màu topic ---//
function topic($text){
$ret = '';
$color = array("prefix prefixPrimary","prefix prefixSecondary", "prefix prefixRed", "prefix prefixGreen", "prefix prefixOlive", "prefix prefixLightGreen", "prefix prefixBlue", "prefix prefixRoyalBlue", "prefix prefixSkyBlue", "prefix prefixGray", "prefix prefixSilver", "prefix prefixOrange", "prefix prefixYellow");
$ran = rand(0, 12);
$mau=$color[$ran];
$ret = '<span class="'.$mau.'">'.$text.'</span>';
return $ret;
}
///
function rand_color($text) {
$color = array();
$color[] = '<font color="000011">';
$color[] = '<font color="000022">';
$color[] = '<font color="000044">';
$color[] = '<font color="000055">';
$color[] = '<font color="000077">';
$color[] = '<font color="000088">';
$color[] = '<font color="000099">';
$color[] = '<font color="0000AA">';
$color[] = '<font color="0000BB">';
$color[] = '<font color="0000CC">';
$color[] = '<font color="0000DD">';
$color[] = '<font color="0000EE">';
$color[] = '<font color="0000FF">';
$color[] = '<font color="001100">';
$color[] = '<font color="002200">';
$color[] = '<font color="003300">';
$color[] = '<font color="004400">';
$color[] = '<font color="005500">';
$color[] = '<font color="006600">';
$color[] = '<font color="007700">';
$color[] = '<font color="008800">';
$color[] = '<font color="009900">';
$color[] = '<font color="00AA00">';
$color[] = '<font color="00BB00">';
$color[] = '<font color="00CC00">';
$color[] = '<font color="00DD00">';
$color[] = '<font color="00EE00">';
$color[] = '<font color="00FF00">';
$color[] = '<font color="000033">';
$color[] = '<font color="000066">';
$color[] = '<font color="000099">';
$color[] = '<font color="0000CC">';
$color[] = '<font color="0000FF">';
$color[] = '<font color="330000">';
$color[] = '<font color="330033">';
$color[] = '<font color="330066">';
$color[] = '<font color="330099">';
$color[] = '<font color="3300CC">';
$color[] = '<font color="3300FF">';
$color[] = '<font color="660000">';
$color[] = '<font color="660033">';
$color[] = '<font color="660066">';
$color[] = '<font color="660099">';
$color[] = '<font color="6600CC">';
$color[] = '<font color="6600FF">';
$color[] = '<font color="990000">';
$color[] = '<font color="990033">';
$color[] = '<font color="990066">';
$color[] = '<font color="990099">';
$color[] = '<font color="9900CC">';
$color[] = '<font color="9900FF">';
$color[] = '<font color="CC0000">';
$color[] = '<font color="CC0033">';
$color[] = '<font color="CC0066">';
$color[] = '<font color="CC0099">';
$color[] = '<font color="CC00CC">';
$color[] = '<font color="CC00FF">';
$color[] = '<font color="FF0000">';
$color[] = '<font color="FF0033">';
$color[] = '<font color="FF0066">';
$color[] = '<font color="FF0099">';
$color[] = '<font color="FF00CC">';
$color[] = '<font color="FF00FF">';
$color[] = '<font color="003300">';
$color[] = '<font color="003333">';
$color[] = '<font color="003366">';
$color[] = '<font color="003399">';
$color[] = '<font color="0033CC">';
$color[] = '<font color="FF3333">';
$color[] = '<font color="0033FF">';
$color[] = '<font color="333300">';
$color[] = '<font color="333333">';
$color[] = '<font color="333366">';
$color[] = '<font color="333399">';
$color[] = '<font color="3333CC">';
$color[] = '<font color="3333FF">';
$color[] = '<font color="663300">';
$color[] = '<font color="663333">';
$color[] = '<font color="663366">';
$color[] = '<font color="663399">';
$color[] = '<font color="6633CC">';
$color[] = '<font color="6633FF">';
$color[] = '<font color="993300">';
$color[] = '<font color="993333">';
$color[] = '<font color="993366">';
$color[] = '<font color="993399">';
$color[] = '<font color="9933CC">';
$color[] = '<font color="9933FF">';
$color[] = '<font color="CC3300">';
$color[] = '<font color="CC3333">';
$color[] = '<font color="CC3366">';
$color[] = '<font color="CC3399">';
$color[] = '<font color="CC33CC">';
$color[] = '<font color="CC33FF">';
$color[] = '<font color="FF3300">';
$color[] = '<font color="FF3333">';
$color[] = '<font color="FF3366">';
$color[] = '<font color="FF3399">';
$color[] = '<font color="FF33CC">';
$color[] = '<font color="FF33FF">';
$color[] = '<font color="006600">';
$color[] = '<font color="006633">';
$color[] = '<font color="006666">';
$color[] = '<font color="006699">';
$color[] = '<font color="0066CC">';
$color[] = '<font color="0066FF">';
$color[] = '<font color="336600">';
$color[] = '<font color="336633">';
$color[] = '<font color="336666">';
$color[] = '<font color="336699">';
$color[] = '<font color="3366CC">';
$color[] = '<font color="3366FF">';
$color[] = '<font color="666600">';
$color[] = '<font color="666633">';
$color[] = '<font color="666666">';
$color[] = '<font color="666699">';
$color[] = '<font color="6666CC">';
$color[] = '<font color="6666FF">';
$color[] = '<font color="996600">';
$color[] = '<font color="996633">';
$color[] = '<font color="996666">';
$color[] = '<font color="996699">';
$color[] = '<font color="9966CC">';
$color[] = '<font color="9966FF">';
$color[] = '<font color="CC6600">';
$color[] = '<font color="CC6633">';
$color[] = '<font color="CC6666">';
$color[] = '<font color="CC6699">';
$color[] = '<font color="CC66CC">';
$color[] = '<font color="CC66FF">';
$color[] = '<font color="FF6600">';
$color[] = '<font color="FF6633">';
$color[] = '<font color="FF6666">';
$color[] = '<font color="FF6699">';
$color[] = '<font color="FF66CC">';
$color[] = '<font color="FF66FF">';
$color[] = '<font color="009900">';
$color[] = '<font color="009933">';
$color[] = '<font color="009966">';
$color[] = '<font color="009999">';
$color[] = '<font color="0099CC">';
$color[] = '<font color="0099FF">';
$color[] = '<font color="339900">';
$color[] = '<font color="339933">';
$color[] = '<font color="339966">';
$color[] = '<font color="339999">';
$color[] = '<font color="3399CC">';
$color[] = '<font color="3399FF">';
$color[] = '<font color="669900">';
$color[] = '<font color="669933">';
$color[] = '<font color="669966">';
$color[] = '<font color="669999">';
$color[] = '<font color="6699CC">';
$color[] = '<font color="6699FF">';
$color[] = '<font color="999900">';
$color[] = '<font color="999933">';
$color[] = '<font color="999966">';
$color[] = '<font color="999999">';
$color[] = '<font color="9999CC">';
$color[] = '<font color="9999FF">';
$color[] = '<font color="CC9900">';
$color[] = '<font color="CC9933">';
$color[] = '<font color="CC9966">';
$color[] = '<font color="CC9999">';
$color[] = '<font color="CC99CC">';
$color[] = '<font color="CC99FF">';
$color[] = '<font color="FF9900">';
$color[] = '<font color="FF9933">';
$color[] = '<font color="FF9966">';
$color[] = '<font color="FF9999">';
$color[] = '<font color="FF99CC">';
$color[] = '<font color="FF99FF">';
$color[] = '<font color="00CC00">';
$color[] = '<font color="00CC33">';
$color[] = '<font color="00CC66">';
$color[] = '<font color="00CC99">';
$color[] = '<font color="33CC33">';
$color[] = '<font color="33CC66">';
$color[] = '<font color="00CCCC">';
$color[] = '<font color="00CCFF">';
$color[] = '<font color="33CC00">';
$color[] = '<font color="33CC33">';
$color[] = '<font color="33CC66">';
$color[] = '<font color="33CC99">';
$color[] = '<font color="33CCCC">';
$color[] = '<font color="33CCFF">';
$color[] = '<font color="66CC00">';
$color[] = '<font color="66CC33">';
$color[] = '<font color="66CC66">';
$color[] = '<font color="66CC99">';
$color[] = '<font color="66CCCC">';
$color[] = '<font color="66CCFF">';
$color[] = '<font color="99CC00">';
$color[] = '<font color="99CC33">';
$color[] = '<font color="99CC66">';
$color[] = '<font color="99CC99">';
$color[] = '<font color="99CCCC">';
$color[] = '<font color="99CCFF">';
$color[] = '<font color="CCCC00">';
$color[] = '<font color="CCCC33">';
$color[] = '<font color="CCCC66">';
$color[] = '<font color="CCCC99">';
$color[] = '<font color="CCCCCC">';
$color[] = '<font color="CCCCFF">';
$color[] = '<font color="FFCC00">';
$color[] = '<font color="FFCC33">';
$color[] = '<font color="FFCC66">';
$color[] = '<font color="FFCC99">';
$color[] = '<font color="FFCCCC">';
$color[] = '<font color="FFCCFF">';
$color[] = '<font color="00FF00">';
$color[] = '<font color="00FF33">';
$color[] = '<font color="00FF66">';
$color[] = '<font color="00FF99">';
$color[] = '<font color="00FFCC">';
$color[] = '<font color="00FFFF">';
$color[] = '<font color="33FF00">';
$color[] = '<font color="33FF33">';
$color[] = '<font color="33FF66">';
$color[] = '<font color="33FF99">';
$color[] = '<font color="33FFCC">';
$color[] = '<font color="33FFFF">';
$color[] = '<font color="66FF00">';
$color[] = '<font color="66FF33">';
$color[] = '<font color="66FF66">';
$color[] = '<font color="66FF99">';
$color[] = '<font color="66FFCC">';
$color[] = '<font color="66FFFF">';
$color[] = '<font color="99FF00">';
$color[] = '<font color="99FF33">';
$color[] = '<font color="99FF66">';
$color[] = '<font color="99FF99">';
$color[] = '<font color="99FFCC">';
$color[] = '<font color="99FFFF">';
$color[] = '<font color="CCFF00">';
$color[] = '<font color="CCFF33">';
$color[] = '<font color="CCFF66">';
$color[] = '<font color="CCFF99">';
$color[] = '<font color="CCFFCC">';
$color[] = '<font color="CCFFFF">';
$color[] = '<font color="FFFF00">';
$color[] = '<font color="FFFF33">';
$color[] = '<font color="FFFF66">';
$color[] = '<font color="FFFF99">';
$color[] = '<font color="FFFFCC">';
$color[] = '<font color="FFFFFF">';
$color[] = '<font color="110000">';
$color[] = '<font color="220000">';
$color[] = '<font color="330000">';
$color[] = '<font color="440000">';
$color[] = '<font color="550000">';
$color[] = '<font color="660000">';
$color[] = '<font color="770000">';
$color[] = '<font color="880000">';
$color[] = '<font color="990000">';
$color[] = '<font color="AA0000">';
$color[] = '<font color="BB0000">';
$color[] = '<font color="CC0000">';
$color[] = '<font color="DD0000">';
$color[] = '<font color="EE0000">';
$color[] = '<font color="FF0000">';
$color[] = '<font color="111111">';
$color[] = '<font color="222222">';
$color[] = '<font color="333333">';
$color[] = '<font color="444444">';
$color[] = '<font color="555555">';
$color[] = '<font color="666666">';
$color[] = '<font color="777777">';
$color[] = '<font color="888888">';
$color[] = '<font color="999999">';
$color[] = '<font color="AAAAAA">';
$color[] = '<font color="BBBBBB">';
$color[] = '<font color="CCCCCC">';
$color[] = '<font color="DDDDDD">';
$color[] = '<font color="EEEEEE">';
$color[] = '<font color="FFFFFF">';
$out .= '' . $color[rand(0, count($color)-1)] . '' . $text . '</font>';
return $out;
}

function rand_size($text) {
$size = array();
// $size[] = '<font size="+2">';
$size[] = '<font size="+1">';
$size[] = '<font>';
$size[] = '<font size="-1">';
$out .= '' . $size[rand(0, count($size)-1)] . '' . $text . '</font>';
return $out;
}

function rand_face($text) {
$face = array();
$face[] = '<font face="arial">';
$face[] = '<font>';
$face[] = '<font face="tahoma">';
$out .= '' . $face[rand(0, count($face)-1)] . '' . $text . '</font>';
return $out;
}
///
function Anlink($link) {
global $user_id;
if($user_id) {
$url = '<a href="'.$link[1].'">'.$link[2].'</a>';
return $url;
} else {
$url = '<b>Bạn cần <a href="/login.php"><font color="red">[Đăng nhập]</font></a> để thấy link!</b>';
return $url;
}
}
//--- Hiển thị thành viên ---//

function nickname($id, $mod = false) {
$ban = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" . $id . "' AND `ban_time` > '" . time() . "'"), 0);
$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '" . $id . "'"));
if($ban > 0) {
$out .= '<font style="color:black">'.($mod == 1 ? '<small>' : '<b>').'<s>' . $user['name'] . '</s>'.($mod == 1 ? '</small>' : '</b>').'</font>';
} else {
if($user['rights'] > 1) {
$font = '<font style="color:red">';
$out .= ''.$font.'' . $user['name'] . '</font>';
} else {
$out .= '<font style="color:blue"><b>' . $user['name'] . '</b></font>';
}
}
return '<a href="'.$home.'/users/profile.php?user='.$id.'"><b>'.$out.'</b></a>';
}


function view_date($var) {
$date = date("d.m.Y / H:i", $var );
$day = time()-$var;
$h = ceil($day/3600);
$p = ceil($day/60);
$s = $day;
if (date('Y', $var) == date('Y', time())) {
if (date('z', $var ) == date('z', time())) {
$date = $h . ' giờ trước';
if (date('H', $var) == date('H', time())) {
$date = $p.' phút trước';
if (date('i', $var) == date('i', time())) {
$date = $s.' giây trước';
}
}
}
if (date('z', $var) == date('z', time()) - 1) {
$date = core::$lng['yesterday'] . ', ' . date("H:i", $var);
}
}
return $date;
}

function rw($text) {
$text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
$text=str_replace(urldecode('%CC%A3'),"", $text);
$text=str_replace(urldecode('%CC%83'),"", $text);
$text=str_replace(urldecode('%CC%89'),"", $text);
$text=str_replace(urldecode('%CC%80'),"", $text);
$text=str_replace(urldecode('%CC%81'),"", $text);
$text=str_replace("--","-", $text);
$text=str_replace(" ","-", $text);
$text=str_replace("@","-",$text);
$text=str_replace("/","-",$text);
$text=str_replace("\\","-",$text);
$text=str_replace(":","-",$text);
$text=str_replace("\"","-",$text);
$text=str_replace("'","-",$text);
$text=str_replace("<","-",$text);
$text=str_replace(">","-",$text);
$text=str_replace(",","-",$text);
$text=str_replace("?","-",$text);
$text=str_replace("%20","",$text);
$text=str_replace(";","-",$text);
$text=str_replace("[","-",$text);
$text=str_replace("]","-",$text);
$text=str_replace("(","-",$text);
$text=str_replace(")","-",$text);
$text=str_replace("́","-", $text);
$text=str_replace("̀","-", $text);
$text=str_replace("̃","-", $text);
$text=str_replace("̣","-", $text);
$text=str_replace("̉","-", $text);
$text=str_replace("*","-",$text);
$text=str_replace("!","-",$text);
$text=str_replace("$","-",$text);
$text=str_replace("&","-and-",$text);
$text=str_replace("%","-",$text);
$text=str_replace("#","-",$text);
$text=str_replace("^","-",$text);
$text=str_replace("=","-",$text);
$text=str_replace("+","-",$text);
$text=str_replace("~","-",$text);
$text=str_replace("`","-",$text);
$text=str_replace("--","-",$text);
$text=str_replace(".","-",$text);
$text = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $text);
$text = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $text);
$text = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $text);
$text = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $text);
$text = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $text);
$text = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $text);
$text = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $text);
$text = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $text);
$text = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $text);
$text = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $text);
$text = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $text);
$text = preg_replace("/(đ)/", 'd', $text);
$text = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $text);
$text = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $text);
$text = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $text);
$text = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $text);
$text = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $text);
$text = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $text);
$text = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $text);
$text = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $text);
$text = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $text);
$text = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $text);
$text = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $text);
$text = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $text);
$text = preg_replace("/(Đ)/", 'D', $text);
$text = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $text);
$text = preg_replace("/(Đ)/", 'D', $text);

return strtolower($text);
}



function randcolor(){
$ret = '';
$color = array("Maroon","DarkRed", "FireBrick", "Red", "Salmon", "Tomato", "Coral", "OrangeRed", "Chocolate", "SandyBrown");
$ran = rand(0, 10);
$mau=$color[$ran];
$ret = $mau;
return $ret;
}
function randprefix(){
$pr = array("Primary", "Secondary","Red","Olive", "LightGreen","Blue","RoyalBlue","SkyBlue","Gray","Silver","Yellow","Orange");
return $pr[rand(0,11)];
}

function auto_img($url) {
$info = pathinfo($url);
if (isset($info['extension'])) {
$duoi = strtolower($info['extension']);
if (($duoi == 'jpg') || ($duoi == 'jpeg') || ($duoi == 'bmp') || ($duoi == 'gif') || ($duoi == 'png')) {
return '<img src="'.$url.'" alt="'.$url.'"/>';
} else {
return $url;
}
} else {
return $url;
}
}
function check_message($text = ''){
	
	if($text != ''){
		
		$post = explode(' ',$text);
		
		$vanbanfix = '';
		
		foreach($post as $post => $key){
			
			if(strlen($key) < 20){
				
				$vanbanfix .= $key.' ';
				
			}
			
		}
		
	}
	return $vanbanfix;
}

?>