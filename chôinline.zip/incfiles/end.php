<?php
//---MOD-BY-BONGMA007---//
defined('_IN_JOHNCMS') or die('Error: restricted access');

// Рекламный блок сайта
if (!empty($cms_ads[2])) {
    echo '<div class="gmenu">' . $cms_ads[2] . '</div>';
}


/*
-----------------------------------------------------------------
Thống Kê
-----------------------------------------------------------------
*/  



// Счетчики каталогов
functions::display_counters();
echo '<div class="footer-container">
<div class="footer">
<center>
<div class="copyrights" style="width: 100%">© 2015  <a href="/">Mạng xã hội ChoiOnline.Cf</a> 
<br/>Diễn đàn: <a href="https://m2v.me"><b>M2V.ME</b></a><br/>
Phát triển bởi ALL thành viên ChoiOnline
</div></center>
</div>
</div>
</div>
</div>
</div>
';
// Рекламный блок сайта
if (!empty($cms_ads[3])) {
    echo '<br />' . $cms_ads[3];
}
echo '</div></body></html>';