<?php
function chuc($chuc){
$timkiem = mysql_fetch_array(mysql_query("SELECT `rights` from `users` where `id` = '$chuc'"));
if($timkiem[rights] == 9) $chuc_vi = '<span style="color: red;"> - Người Sáng Lập</span>';
if($timkiem[rights] == 8) $chuc_vi = '<span style="color: green;"> - T.MMOD</span>';
if($timkiem[rights] == 7) $chuc_vi = '<span style="color: red;"> - Administrator</span>';
if($timkiem[rights] == 6) $chuc_vi = '<span style="color: #993399;"> - Tổng Quản Lí</span>';
if($timkiem[rights] == 5) $chuc_vi = '<span style="color: #ff9000;"> - MOD</span>';
if($timkiem[rights] == 4) $chuc_vi = '<span style="color: #ad4105;"> - Trung Gian</span>';
if($timkiem[rights] == 3) $chuc_vi = '<span style="color: green;"> - MOD</span>';
if($timkiem[rights] == 2) $chuc_vi = '<span style="color: green;"> - TN.MOD</span>';
if($timkiem[rights] == 1) $chuc_vi = '<span style="color: green;"> - TN.MMOD</span>';
return $chuc_vi;
}
function exp_chinhc($exp_chinh){
		$lerver = '0';
		if($exp_chinh >= 20 && $exp_chinh < 100){
			$lerver = '1';
		}else if($exp_chinh >= 100 && $exp_chinh < 200){
			$lerver = '2';
		}else if($exp_chinh >= 200 && $exp_chinh < 350){
			$lerver = '3';
		}else if($exp_chinh >= 350 && $exp_chinh < 600){
			$lerver = '4';
		}else if($exp_chinh >= 600 && $exp_chinh < 850){
			$lerver = '5';
		}else if($exp_chinh >= 850 && $exp_chinh < 1500){
			$lerver = '6';
		}else if($exp_chinh >= 1500 && $exp_chinh < 3000){
			$lerver = '7';
		}else if($exp_chinh >= 3000 && $exp_chinh < 6000){
			$lerver = '8';
		}else if($exp_chinh >= 6000 && $exp_chinh < 10000){
			$lerver = '9';
		}else if($exp_chinh >= 10000){
			$lerver = '10';
		}
		return $lerver;
}
function timeonline($time){
$ketqua = $time;
$chiangay = ($ketqua / 60 / 60 / 24);
$xuatngay = explode('.', $chiangay);
$ngay = $xuatngay[0]; //so ngay
$sogio = ($ketqua - ($ngay * 60 * 60 * 24)); //con lai so gio(tinh theo giay)
$chiagio = ($sogio / 60 / 60);
$xuatgio = explode('.', $chiagio);
$gio = $xuatgio[0]; //so gio
$sophut = ($sogio - ($gio * 60 * 60)); //con lai so phut (tinh theo giay)
$chiaphut = ($sophut / 60);
$xuatphut = explode('.', $chiaphut);
$phut = $xuatphut[0];
$giay = ($sophut - ($phut * 60));
if($ngay != 0){
$time = $ngay.' ngày, '.$gio.' giờ, '.$phut.' phút';
}elseif($gio != 0){
$time = $gio.' gio, '.$phut.' phút, '.$giay.'  giây';
}elseif($phut != 0){
$time = $phut.' phút, '.$giay.' giây';
}else{ $time = $giay.' giây'; }
return $time; }
$timkiemkitumahoa = array( 
				'.com' => '(choionline.cf)', 
				'.net' => '(choionline.cf)', 
				'.us' => '(choionline.cf)', 
				'.org' => '(choionline.cf)', 
				'.pro' => '(choionline.cf)', 
				'.in' => '(choionline.cf)', 
				'.ws' => '(choionline.cf)', 
				'.info' => '(choionline.cf)', 
				'.vn' => '(choionline.cf)', 
				'.xxx' => '(choionline.cf)', 
				'.ga' => '(choionline.cf)', 
				'.sh' => '(choionline.cf)', 
				'.eu' => '(choionline.cf)',
				'<script>' => '(choionline.cf)', 
				'</script>' => '(choionline.cf)', 
				'.Com' => '(choionline.cf)', 
				'.Net' => '(choionline.cf)', 
				'.Us' => '(choionline.cf)', 
				'.Org' => '(choionline.cf)', 
				'.Pro' => '(choionline.cf)', 
				'.In' => '(choionline.cf)', 
				'.Ws' => '(choionline.cf)', 
				'.Info' => '(choionline.cf)', 
				'.Vn' => '(choionline.cf)', 
				'.Xxx' => '(choionline.cf)', 
				'.Ga' => '(choionline.cf)', 
				'.Sh' => '(choionline.cf)', 
				'365x' => '(choionline.cf)', 
				'365x.us' => '(choionline.cf)', 
				'365x. us' => '(choionline.cf)', 
				'365x . us' => '(choionline.cf)', 
				'. us' => '(choionline.cf)', 
				'.Eu' => '(choionline.cf)', 
				'tuoitre4v' => '(choionline.cf)', 
				'tuoitre4u' => '(choionline.cf)', 
				'tuoitre' => '(choionline.cf)', 
				'tuoi tre 4u' => '(choionline.cf)', 
				'tuoi tre 4v' => '(choionline.cf)', 
				't u o i t r e 4 u' => '(choionline.cf)', 
				't u o i t r e 4 v' => '(choionline.cf)', 
				'4u' => '(choionline.cf)', 
				'4 u' => '(choionline.cf)', 
				'4 v' => '(choionline.cf)', 
				'VNTEAM' => '(choionline.cf)', 
				'Vnteam' => '(choionline.cf)', 
				'VNteam' => '(choionline.cf)', 
				'VNTeam' => '(choionline.cf)', 
				'VNTEam' => '(choionline.cf)', 
				'VNTEAm' => '(choionline.cf)', 
				'VNTEAm' => '(choionline.cf)', 
				'VN TEAM' => '(choionline.cf)', 
				'V N T E A M' => '(choionline.cf)', 
				'vnteam' => '(choionline.cf)', 
				'v n t e a m' => '(choionline.cf)', 
				'vn team' => '(choionline.cf)', 
				'VN team' => '(choionline.cf)', 
				'VN Team' => '(choionline.cf)', 
				'V N team' => '(choionline.cf)', 
				'V N t e a m' => '(choionline.cf)', 
				'V N t e a m' => '(choionline.cf)', 
				'v n T E A M' => '(choionline.cf)', 
				'.M E' => '(choionline.cf)', 
				'.me' => '(choionline.cf)', 
				'.ME' => '(choionline.cf)', 
				'. ME' => '(choionline.cf)', 
				'. M E' => '(choionline.cf)', 
				'. m e' => '(choionline.cf)', 
				'. m E' => '(choionline.cf)', 
				'. M e' => '(choionline.cf)', 
				'.M e' => '(choionline.cf)', 
				'.Me' => '(choionline.cf)', 
				'.m E' => '(choionline.cf)', 
				'.m e' => '(choionline.cf)', 
				'. m e' => '(choionline.cf)', 
				'<script>' => '(choionline.cf) :D',
				'</script>' => '(choionline.cf)',
				'tuoitre4v' => '(choionline.cf)',
				'tuoitre' => '****',
				'buoi' => '****',
				'lon' => '****',
				'địt' => '****',
				'Địt' => '****',
				'dkm' => '****',
				'DKM' => '****',
				'lồn' => '****',
				'buồi' => '****',
				'vina' => '****',
				'.tk' => '***',
				'http://' => '***',
				'm5vn' => '***',
				'M5VN' => '***',
				'M5vn' => '***',
				'm5Vn' => '***',
				'm5vN' => '***',
				'vina4u' => '****',
				'tt4v' => '****',
				'vi na 4u' => '****',
				'Vina4u' => '****',
				'VINA4U' => '****',
				':d:d:d' => '',
				'goc9v' => '',
				'goc 9v' => '',
				'GOC9V' => '',
				'GOC 9V' => '',
				'G O C 9 V' => '',
				'g o c 9 v' => '',
				'buồi' => '',
				'loz' => '',
				'forumchat' => '',
				'FORUMCHAT' => '',
				'Forum Chat' => '',
				'forum chat' => '',
				'.tk' => '',
				'.Tk' => '',
				'.tK' => '',
				'.TK' => '',
				'.T K' => '',
				'. T K' => '',
				'. T k' => '',
				'Vietbook' => '',
				'VIET BOOK' => '',
				'vietbook' => '',
				'V I E T B O O K' => '',
				'.mobi' => '',
				'.Mobi' => '',
				'.MObi' => '',
				'.MOBI' => '',
				'.mOBI' => '',
				'. mobi' => '',
				'. Mobi' => '',
				'. MObi' => '',
				'. MOBI' => '',
				'. mOBI' => '',
				'. MOBi' => '',
				'.MOBI' => '',
				'.M O B I' => '',
				'. M O B I' => '',
				'.M o b i' => '',
				'MOBI' => '',
				'M O B I' => '',
				'M O B I' => '',
				'M o b i' => '',
				'm o b i' => '',
				'. t K' => '',
				'http://choionline.cf' => '',
				'2Vui' => '',
				'2VUi' => '',
				'2vui' => '',
				'2VUI' => '',
				'2 V U I' => '',
				'2 v U I' => '',
				'2 v u I' => '',
				'2 v u i' => '',
				'.cc' => '',
				'cc' => '**',
				'. C C' => '**',
				'CC' => '**',
				'c C' => '**',
				'C c' => '**',
				'cC' => '**',
				'Cc' => '**',
				'.Cc' => '**',
				); 
$timkiem2 = array( 
				':' => '',
				'/-' => '',
				';' => '',
				'-' => '',
				'*' => '',
				'^' => '',
				);
function domacsm($datado,$user){
	$ao = $datado['ao'];
	$toc = $datado['toc'];
	$quan = $datado['quan'];
	$non = $datado['non'];
	$mat = $datado['mat'];
	$matna = $datado['matna'];
	$canh = $datado['canh'];
	$thucung = $datado['thucung'];
	$docamtay = $datado['docamtay'];
	$kinh = $datado['kinh'];
	$haoquang = $datado['haoquang'];
	$sucmanhht = $datado['luutrusm'];
	$sucmanh = 0;
	if($ao != ''){
		$loaisp = 'ao';
		$name = $ao;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($toc != ''){
		$loaisp = 'toc';
		$name = $toc;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($quan != ''){
		$loaisp = 'quan';
		$name = $quan;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($non != ''){
		$loaisp = 'non';
		$name = $non;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($mat != ''){
		$loaisp = 'mat';
		$name = $mat;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($matna != ''){
		$loaisp = 'matna';
		$name = $matna;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($canh != ''){
		$loaisp = 'canh';
		$name = $canh;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($thucung != ''){
		$loaisp = 'thucung';
		$name = $thucung;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($docamtay != ''){
		$loaisp = 'docamtay';
		$name = $docamtay;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($kinh != ''){
		$loaisp = 'kinh';
		$name = $kinh;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($haoquang != ''){
		$loaisp = 'haoquang';
		$name = $haoquang;
		$nameq = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanh += $nameq['sucmanh'];
	}
	if($sucmanhht != $sucmanh){
		mysql_query("UPDATE `users` SET `luutrusm` = '{$sucmanh}' WHERE `id` = '{$user}'");
	}
}
function danhsachdo($datado,$user){
	$ao = $datado['ao'];
	$toc = $datado['toc'];
	$quan = $datado['quan'];
	$non = $datado['non'];
	$mat = $datado['mat'];
	$matna = $datado['matna'];
	$canh = $datado['canh'];
	$thucung = $datado['thucung'];
	$docamtay = $datado['docamtay'];
	$kinh = $datado['kinh'];
	$haoquang = $datado['haoquang'];
	$sucmanhht = $datado['luutrusm'];
	if($ao != ''){
		$loaisp = 'ao';
		$name = $ao;
		$nameq_ao = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['ao'] = $nameq_ao;
	}
	if($toc != ''){
		$loaisp = 'toc';
		$name = $toc;
		$nameq_toc = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['toc'] = $nameq_toc;
	}
	if($quan != ''){
		$loaisp = 'quan';
		$name = $quan;
		$nameqquan = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['quan'] = $nameqquan;
	}
	if($non != ''){
		$loaisp = 'non';
		$name = $non;
		$nameqnon = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['non'] = $nameqnon;
	}
	if($mat != ''){
		$loaisp = 'mat';
		$name = $mat;
		$nameqmat = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['mat'] = $nameqmat;
	}
	if($matna != ''){
		$loaisp = 'matna';
		$name = $matna;
		$nameqmat = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['matna'] = $nameqmat;
	}
	if($canh != ''){
		$loaisp = 'canh';
		$name = $canh;
		$nameqcanh = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['canh'] = $nameqcanh;
	}
	if($thucung != ''){
		$loaisp = 'thucung';
		$name = $thucung;
		$nameqthucung = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['thucung'] = $nameqthucung;
	}
	if($docamtay != ''){
		$loaisp = 'docamtay';
		$name = $docamtay;
		$nameqdocamtay = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['docamtay'] = $nameqdocamtay;
	}
	if($kinh != ''){
		$loaisp = 'kinh';
		$name = $kinh;
		$nameqkinh = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['kinh'] = $nameqkinh;
	}
	if($haoquang != ''){
		$loaisp = 'haoquang';
		$name = $haoquang;
		$nameq_hqhaoquang = mysql_fetch_assoc(mysql_query("SELECT * FROM `khodo` WHERE `name` = '{$name}' AND `id_user` = '{$user}' AND `loaisp` = '{$loaisp}'"));
		$sucmanhrt['haoquang'] = $nameq_hqhaoquang;
	}
	return $sucmanhrt;
}
function xoa_phong_chat(){
	$time_xoa = time()-50000;
	mysql_query("DELETE FROM `guest` WHERE `time` < '{$time_xoa}'");
}
function botchat($text){
	$traloi = '';
	$gialang = '\@(g|G)(i|I)(a|A|\à|\À)(l|L)(a|A|\à|\À)(n|N)(g|G)';
	if(preg_match('/'.$gialang.'/',$text))
	{
		if(
			preg_match('/'.$gialang.' (.+?)(n|N)(g|G)(u|U)(.+?)/',$text) |
			preg_match('/'.$gialang.' (.+?)(\đ|\Đ|d|D)(i|I)(e|\ê|\Ê|E)(n|N)(.+?)/',$text) |
			preg_match('/'.$gialang.' (.+?)(k|K)(h|H)(u|U|Ù|ù})(n|N)(g|G)(.+?)/',$text)
			
		){
			$text_v = "Nói ai đấy bé, cho răng đi đường răng giờ :)) ,Đã ngu còn tỏ ra nguy hiểm à con ,Chắc con còn bị nặng hơn cả ta ý chứ.. :)) ,Nói người ta chẳng qua nói mình. ;p";
			$data	= explode(' ,',$text_v);
			$random = rand(0,3);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (.+?)(m|M)(e|E|ẹ|Ẹ)(.+?)/',$text) |
			preg_match('/'.$gialang.' (.+?)(c|C)(h|H)(a|A)(.+?)/',$text) |
			preg_match('/'.$gialang.' (.+?)(b|B)(o|O|Ố|ố)(.+?)/',$text)
		){
			$text_v = "Nói gì đấy bé, cho răng đi đường răng giờ :)) ,Sao lại lôi bố mẹ ra đây, già vả chết mẹ con giờ :)), Già dạy con nói thế à ,Bé mà to còi cơ :))";
			$data	= explode(' ,',$text_v);
			$random = rand(0,3);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (r|R)(a|A)/',$text)
		){
			$text_v = "Vào đây mà rửa chân cho ta chứ ra đâu ,Ra đâu mà ra vào đây hầu hạ ta đi :v";
			$data	= explode(' ,',$text_v);
			$random = rand(0,1);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (h|H)(o|O|ỏ|Ỏ)(i|I)/',$text)
		){
			$text_v = "Cái này già cũng không biết được ,Sắp rồi đó ,Lúc nào con làm thì hay hỏi câu này nhé :D";
			$data	= explode(' ,',$text_v);
			$random = rand(0,1);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (o|O|ơ|Ơ)(i|I)/',$text) |
			preg_match('/'.$gialang.' (d|D|đ|Đ)(a|A|Â|â)(u|U)/',$text)
		){
			$text_v = "Già làng đây con, Có việc gì cần hỏi ta hả ,Già đây. Già yếu rồi gọi to to lên éo nghe rõ";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (b|B)(i|I|ị|Ị)/',$text)
		){
			$text_v = "Ta lúc nào cũng bị thông minh con à, Con bị ngu à , Có ai cho tên thần kinh ở bên dưới đi trại hộ già với :v";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(preg_match('/'.$gialang.' (s|S)(p|P)(a|A)(m|M)/',$text)){
			$text_v = "Spam cái đầu con ý :tat ,Con có bị thần kinh không mà kêu ta spam";
			$data	= explode(' ,',$text_v);
			$random = rand(0,1);
			$traloi = $data[$random];
		}else if(preg_match('/'.$gialang.' (g|G)(a|A)(y|Y)/',$text)){
			$text_v = "Tý vào nhà nghỉ là biết ngay nhé x-) ,Ta gay này. Con có yêu ta không ,Bây giờ mới biết à nỡm ;p";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(preg_match('/'.$gialang.' (t|T)(h|H)(o|O|ô|Ô)(n|N)(g|G)/',$text)){
			$text_v = "Nghe muốn ói quá :t ,Thông ta đi này b-) ,Giờ già đang nhiều người quá, để lúc khác nghe con";
			$data	= explode(' ,',$text_v);
			$random = rand(0,1);
			$traloi = $data[$random];
		}else if(preg_match('/'.$gialang.' (c|C)(h|H)(u|U|ư|Ư)(a|A)/',$text)){
			$text_v = "Ui giời, xuốt rồi con à, con không biết sao! :D ,Chưa đừng có đoán vớ vẩn ,Con nít chưa được hỏi rõ chưa.. :))";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(preg_match('/'.$gialang.' (.+?)(k|K)(h|H)(o|O|ô|Ô)(n|N)(g|G)(.+?)/',$text)){
			$text_v = "Không, làm sao có chuyện đó được ,Có chứ, có chứ ta thích lắm ,Thế con có không mà hỏi ta.. :))";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(preg_match('/'.$gialang.' (.+?)(c|C)(h|H)(o|O|ố|Ố)(i|I)(.+?)/',$text)){
			$text_v = "Chối làm gì, đúng sự thật mà, thì thì...., Cho phép ta không nói nhé :D";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (y|Y)(ê|Ê|e|E)(u|U)/',$text) |
			preg_match('/'.$gialang.' (i|I)(u|U)/',$text)
		){
			$text_v = "Yêu đấy hehe. :D ,Làm gì có chuyện đó, con chỉ có cái đoán mò p-(";
			$data	= explode(' ,',$text_v);
			$random = rand(0,1);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (t|T)(h|H)()/',$text)
		){
			$text_v = "Yêu đấy hehe. :D ,Làm gì có chuyện đó, con chỉ có cái đoán mò p-(";
			$data	= explode(' ,',$text_v);
			$random = rand(0,1);
			$traloi = $data[$random];
		}else if(preg_match('/'.$gialang.' (.+?)(l|L)(a|A|À|à)(m|M)(.+?)/',$text)){
			$text_v = "Còn lâu ta mới làm nhé đừng có tưởng bở ,Con làm cho ta đi mà bảo thế ,Thế cũng được nhưng mỗi ngày ta sẽ thô** con 1 cái x-)";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (.+?)(đ|Đ|d|D)(ấ|Ấ|a|A)(m|M)(.+?)/',$text) |
			preg_match('/'.$gialang.' (.+?)(t|T)(á|Á|a|A)(t|T)(.+?)/',$text)
		){
			$text_v = "Con ta chấp 1 mắt ,Đồ tiểu nhân tí đòi đấm đá ,Ta già rồi nhưng con thích thì ta chiều";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (.+?)(n|N)(g|G)(u|U|Ứ|ứ)(a|A)(.+?)/',$text)
		){
			$text_v = "Ta đang ngứa đây ,Gãi cho ta với ngứa quá đi , Ôi ngứa quá đi chứ :D";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (.+?)(d|D|Đ|đ)(i|I)(.+?)/',$text)
		){
			$text_v = "Đi đâu ở lại chém gió đã chứ ,Đang chém gió hay đi làm gì ,Ngu quá đang vui mà";
			$data	= explode(' ,',$text_v);
			$random = rand(0,2);
			$traloi = $data[$random];
		}else if(
			preg_match('/'.$gialang.' (f|F)(u|U)(c|C)(k|K)/',$text) |
			preg_match('/'.$gialang.' (d|D|đ|Đ)(i|I|ị|Ị)(t|T)/',$text)
		){
			$text_v = "Con tin dép tổ ông huyền thoại bay vào mồm con không x-) ,Mẹ dạy con nói thế à";
			$data	= explode(' ,',$text_v);
			$random = rand(0,1);
			$traloi = $data[$random];
		}else{
			$text_v = "Ta cho con đi xách dép cho già nhé, hạnh phúc không? ,Con cứ từ từ đâu rồi sẽ có đó ,Thằng dưới già nó có bị động không nhỉ :D ,Chắc là vậy rồi 8-) ,Già cho cái DÉP vào mặt giờ... :)) , Liệu con sẽ còn răng khi nói tiếp câu nữa không ;f ,Con hỏi cái éo gì già này éo hiểu /-no ,Bây giờ thì có, nhưng sau này thì chưa chắc :* ,Bây giờ thì chưa, nhưng cũng sắp sửa :D ,Bây giờ thì chưa, nhưng sau này thì có ,Cái này cũng còn tùy :3 ,Cái này khó à nha. Nhưng 80% là có x-) ,Cẩn thận. Không được đâu /-no ,Có gái không giới thiệu cho già một em rồi tính típ x-) ,Có! ,Có. Nhưng sau này phải cẩn thận. Già nhìn thấy có sự thay đổi ,Con chưa đủ tuổi để hỏi câu hỏi này đâu, đừng liều ,Con đang phê à, hay tính chơi nhau đấy? ,Cũng được đấy nhưng phải cẩn thận ,Cũng được. Nhưng đợi đến tết Công-gô thì mong ước sẽ thành ,Cũng ngang chuẩn quốc tế đấy ,Cute mà sao hỏi khó qua dzậy? ,Chiến hết con ạ! ,Chơi luôn đi tại sao phải xoắn ,Chuẩn không cần chỉnh! ,Dân châu Phi cũng phải mê con ạ ,Đã ngu còn cố tỏ ra nguy hiểm hả con ,Để mai tính ,Đưa ông ít tiền đi rồi ông nói cho nghe ,Hỏi gì mà ngốc thế con? ,Hỏi khó quá coi chừng ra đường chó cắn à nha ,Hỏi thế thì bố ông cũng hem dám trả lời ,Hỏi gì mà khó vậy con ,Khó đó à nha ,Không ,Mi đi chết đi. Dám đánh đố ông à? ,Mọi việc chỉ có 50% như mong muốn thôi ,Nghe muốn ói quá ,Nghĩ sao mà hỏi vậy? Định thử ông à ,Già đang bận quá. Lát ông trả lời ,Nói một cách khiêm tốn ông là người giỏi nhất thế giới rồi ,Ôi giời! Tất nhiên là có ,Sao giống ông dzậy ,Già con mê nữa huống chi ai ,Già đang đông khách quá, để lúc khác ,Già thần thông quảng đại lắm cái gì cũng biết hết ,Theo ông tính là không ,Theo ông thì chắc chắn là không ,Thích thì chiều thôi ,Trả tiền đây đi rồi hỏi tiếp ,Uhm uhm, điều đó chắc chắn sẽ xảy ra ,Tưởng mà dễ ăn à, khó phết đấy con à! ;f ,Yên tâm đi, chắc chắn là có ,Làng choionline toàn người tài giỏi cả ,Cẩn thận coi chừng ông xóa profile đấy ,Không đâu con ạ! ,Chỉ có một chút xíu thôi con ạ ,Không như con nghĩ đâu ,Cái này á, cũng khó nghĩ, nhưng có vẻ là có ,Sẽ ổn con ạ! ,Theo thầy tính thì hết tháng này con ạ ,Không! ,Hỏi thế thì bố ông cũng hem dám giả nhời! ,Tất nhiên là thế, chuẩn không cần chỉnh! ,Chắc cũng có phần nào như thế ,Tùy, thik thì chiều con ạ ,Cũng được, nếu con muốn vậy ,Nói có thì già này áy náy lắm >.< x-) ,Cũng không sớm, nhưng cũng không việc gì phải vội ,Cũng có lẽ là nên thế ,Tầm mấy hôm nữa con ạ, cứ yên tâm ,Con cẩn thận ta vứt cái điện thoại vào mặt cho bây giờ nói sai sự thật ,Chuẩn không cần chỉnh, chỉnh là sai ,Chính xác đấy ,Tháng sau ,Già bấm ra ít lắm con ạ ,Quẻ nói tầm tháng nữa con ạ ,Nếu thích con cứ nhích ,Tùy mới làm được thôi x-) ,Già bấm đốt thì ra tầm dăm hôm nữa con ạ ,Tương lai ta tươi sáng rạng rỡ lắm ,Cái này thì mẹ con biết rõ hơn ông.";
			$data = explode(' ,',$text_v);
			$random = rand(0,80);
			$traloi = $data[$random];
		}
		if(!empty($traloi)){
			$time_giachat = time()+1;
			mysql_query("INSERT INTO `guest` SET
            `adm` = '',
            `time` = '" . $time_giachat . "',
            `user_id` = '2',
            `name` = 'Già Làng',
            `text` = '" . mysql_real_escape_string($traloi) . "',
            `ip` = '1024',
            `browser` = 'PRO'
			");
		}
	}
}
?>
