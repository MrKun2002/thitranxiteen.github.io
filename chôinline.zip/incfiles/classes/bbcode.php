<?php
//---MOD-BY-BONGMA007---//
/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Restricted access');

class bbcode extends core
{
    
	/* 
    ----------------------------------------------------------------- 
    Colors 
    ----------------------------------------------------------------- 
    */ 
    public static function colors($var) 
    { 
        if (!function_exists('process_colors')) { 
            function process_colors($var) 
            { 
$str = $var[1]; 
                $strlen = mb_strlen($str);  
                while ($strlen) { 
                    $arr1[] = mb_substr($str, 0, 1, "UTF-8");  
                    $str = mb_substr($str, 1, $strlen, "UTF-8");  
                    $strlen = mb_strlen($str); } 
                $arr2 = array( '#ff00cc', 
                               '#ff0099', 
                               '#ff0033', 
                               '#ff0000', 
                               '#ff3300', 
                               '#ff6600', 
                               '#ffcc00', 
                               '#ffff00', 
                               '#99ff00', 
                               '#66ff00', 
                               '#33ff00', 
                               '#00ff33', 
                               '#00ff66', 
                               '#00ffcc', 
                               '#00ffff', 
                               '#0099ff', 
                               '#0066ff', 
                               '#0000ff', 
                               '#3300ff', 
                               '#6600ff', 
                               '#9900ff', 
                               '#cc00ff' ); 
                $t = count($arr2); 
                $j = 0; 
                foreach ($arr1 as $value) { 
                        $out .= '<span style="color:' . $arr2[$j] . '">' . $value . '</span>';
                        $j++; 
                    if ($j == $t) $j = 0; 
                } 
                return $out; 
            } 
        } 
        return preg_replace_callback('~\\[colors\\](.+?)\\[/colors\\]~i', 'process_colors', $var); 
    }
	
	
	
	/*
    -----------------------------------------------------------------
    Обработка тэгов и ссылок
    -----------------------------------------------------------------
    */
    public static function tags($var)
    {        
	$var = preg_replace('#@([\w\d]{2,})#si', '@<a>$1</a>', $var);  ///@user
		
        $var = self::parse_time($var);               // Обработка тэга времени
        $var = self::highlight_code($var);           // Подсветка кода
        $var = self::highlight_url($var);            // Обработка ссылок
        $var = self::highlight_bb($var);             // Обработка ссылок
        $var = self::OLD_highlight_url($var);        // Обработка ссылок в BBcode
		$var = self::colors($var); ///--Color
        return $var;
    }

	
	
	
	
	
	
	
    /*
    -----------------------------------------------------------------
    Обработка времени
    -----------------------------------------------------------------
    */
    private static function parse_time($var)
    {
        if (!function_exists('process_time')) {
            function process_time($time)
            {
                $shift = (core::$system_set['timeshift'] + core::$user_set['timeshift']) * 3600;
                if($out = strtotime($time)){
                    return date("d.m.Y / H:i", $out + $shift);
                } else {
                    return false;
                }
            }
        }
        return preg_replace(array('#\[time\](.+?)\[\/time\]#se'), array("''.process_time('$1').''"), $var);
    }

    /*
    -----------------------------------------------------------------
    Парсинг ссылок
    -----------------------------------------------------------------
    За основу взята доработанная функция от форума phpBB 3.x.x
    -----------------------------------------------------------------
    */
    public static function highlight_url($text)
    {
        if (!function_exists('url_callback')) {
            function url_callback($type, $whitespace, $url, $relative_url)
            {
                $orig_url = $url;
                $orig_relative = $relative_url;
                $url = htmlspecialchars_decode($url);
                $relative_url = htmlspecialchars_decode($relative_url);
                $text = '';
                $chars = array('<', '>', '"');
                $split = false;
                foreach ($chars as $char) {
                    $next_split = strpos($url, $char);
                    if ($next_split !== false) {
                        $split = ($split !== false) ? min($split, $next_split) : $next_split;
                    }
                }
                if ($split !== false) {
                    $url = substr($url, 0, $split);
                    $relative_url = '';
                } else if ($relative_url) {
                    $split = false;
                    foreach ($chars as $char) {
                        $next_split = strpos($relative_url, $char);
                        if ($next_split !== false) {
                            $split = ($split !== false) ? min($split, $next_split) : $next_split;
                        }
                    }
                    if ($split !== false) {
                        $relative_url = substr($relative_url, 0, $split);
                    }
                }
                $last_char = ($relative_url) ? $relative_url[strlen($relative_url) - 1] : $url[strlen($url) - 1];
                switch ($last_char)
                {
                    case '.':
                    case '?':
                    case '!':
                    case ':':
                    case ',':
                        $append = $last_char;
                        if ($relative_url) $relative_url = substr($relative_url, 0, -1);
                        else $url = substr($url, 0, -1);
                        break;

                    default:
                        $append = '';
                        break;
                }
                $short_url = (mb_strlen($url) > 40) ? mb_substr($url, 0, 30) . ' ... ' . mb_substr($url, -5) : $url;
                switch ($type)
                {
                    case 1:
                        $relative_url = preg_replace('/[&?]sid=[0-9a-f]{32}$/', '', preg_replace('/([&?])sid=[0-9a-f]{32}&/', '$1', $relative_url));
                        $url = $url . '/' . $relative_url;
                        $text = $relative_url;
                        if (!$relative_url) {
                            return $whitespace . $orig_url . '/' . $orig_relative;
                        }
                        break;

                    case 2:
                        $text = $short_url;
                        if (!isset(core::$user_set['direct_url']) || !core::$user_set['direct_url']) {
                            $url = core::$system_set['homeurl'] . '/go.php?url=' . rawurlencode($url);
                        }
                        break;

                    case 3:
                        $url = 'http://' . $url;
                        $text = $short_url;
                        if (!isset(core::$user_set['direct_url']) || !core::$user_set['direct_url']) {
                            $url = core::$system_set['homeurl'] . '/go.php?url=' . rawurlencode($url);
                        }
                        break;

                    case 4:
                        $text = $short_url;
                        $url = 'mailto:' . $url;
                        break;
                }
                $url = htmlspecialchars($url);
                $text = htmlspecialchars($text);
                $append = htmlspecialchars($append);
                return $whitespace . '<a href="' . $url . '">' . $text . '</a>' . $append;
            }
        }

        static $url_match;
        static $url_replace;

        if (!is_array($url_match)) {
            $url_match = $url_replace = array();

            // Обработка внутренние ссылки
            $url_match[] = '#(^|[\n\t (>.])(' . preg_quote(core::$system_set['homeurl'], '#') . ')/((?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@|]+|%[\dA-F]{2})*(?:/(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@|]+|%[\dA-F]{2})*)*(?:\?(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@/?|]+|%[\dA-F]{2})*)?(?:\#(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@/?|]+|%[\dA-F]{2})*)?)#ieu';
            $url_replace[] = "url_callback(1, '\$1', '\$2', '\$3')";

            // Обработка обычных ссылок типа xxxx://aaaaa.bbb.cccc. ...
            $url_match[] = '#(^|[\n\t (>.])([a-z][a-z\d+]*:/{2}(?:(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@|]+|%[\dA-F]{2})+|[0-9.]+|\[[a-zа-яё0-9.]+:[a-zа-яё0-9.]+:[a-zа-яё0-9.:]+\])(?::\d*)?(?:/(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@|]+|%[\dA-F]{2})*)*(?:\?(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@/?|]+|%[\dA-F]{2})*)?(?:\#(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@/?|]+|%[\dA-F]{2})*)?)#ieu';
            $url_replace[] = "url_callback(2, '\$1', '\$2', '')";

            // Обработка сокращенных ссылок, без указания протокола "www.xxxx.yyyy[/zzzz]"
            $url_match[] = '#(^|[\n\t (>])(www\.(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@|]+|%[\dA-F]{2})+(?::\d*)?(?:/(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@|]+|%[\dA-F]{2})*)*(?:\?(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@/?|]+|%[\dA-F]{2})*)?(?:\#(?:[a-zа-яё0-9\-._~!$&\'(*+,;=:@/?|]+|%[\dA-F]{2})*)?)#ieu';
            $url_replace[] = "url_callback(3, '\$1', '\$2', '')";
        }
        return preg_replace($url_match, $url_replace, $text);
    }

    /*
    -----------------------------------------------------------------
    Удаление bbCode из текста
    -----------------------------------------------------------------
    */
    static function notags($var = '')
    { 	
	
	//--Smile--//
$var = str_replace(':((', '<img src="/images/smileys/user/Zalo/10.gif" alt="hic hic"/>', $var);
$var = str_replace(':tat', '<img src="/images/smileys/user/Zalo/tat.gif" alt="tat"/>', $var);
$var = str_replace(':tho', '<img src="/images/smileys/user/Zalo/tho.gif" alt="thỏ chạy"/>', $var);
$var = str_replace(':doisit', '<img src="/images/smileys/user/Zalo/81.gif" alt="đội sít"/>', $var);
$var = str_replace(':dambay', '<img src="/images/smileys/user/Zalo/dambay.gif" alt="đấm phát bay"/>', $var);
$var = str_replace(':lol', '<img src="/images/smileys/user/Zalo/lol.gif" alt="lol"/>', $var);
$var = str_replace(':tolet', '<img src="/images/smileys/user/Zalo/82.gif" alt="tolet"/>', $var);
$var = str_replace(':embe', '<img src="/images/smileys/user/Zalo/embe.gif" alt="tolet"/>', $var);
$var = str_replace(':3', '<img src="/images/smileys/user/Zalo/curlylips.png" alt="curlylips"/>', $var);
$var = str_replace(':v', '<img src="/images/smileys/user/Zalo/pacman.png" alt="pacman"/>', $var);
$var = str_replace(':))', '<img src="/images/smileys/user/Yahoo/24.gif" alt="hic hic"/>', $var);
$var = str_replace(':-((', '<img src="/images/smileys/user/Zalo/6.gif" alt="khóc thảm"/>', $var);
$var = str_replace(':)', '<img src="/images/smileys/user/Zalo/1.gif" alt="cười mỉm"/>', $var);
$var = str_replace('/-shit', '<img src="/images/smileys/user/Zalo/66.gif" alt="Shit"/>', $var);
$var = str_replace(':~', '<img src="/images/smileys/user/Zalo/2.gif" alt=" lo lắng lo sợ"/>', $var);
$var = str_replace(':B', '<img src="/images/smileys/user/Zalo/3.gif" alt="ngon vãi"/>', $var);
$var = str_replace(':|', '<img src="/images/smileys/user/Zalo/4.gif" alt=" ngạc nhiên chảy máu mũi"/>', $var);
$var = str_replace('8-)', '<img src="/images/smileys/user/Zalo/5.gif" alt="ngầu chưa"/>', $var);
$var = str_replace(':$', '<img src="/images/smileys/user/Zalo/7.gif" alt="e thẹn thẹn thùng"/>', $var);
$var = str_replace(':x', '<img src="/images/smileys/user/Zalo/8.gif" alt="nín luôn im luôn"/>', $var);
$var = str_replace(':z', '<img src="/images/smileys/user/Zalo/9.gif" alt="khò khò ngủ rồi"/>', $var);
$var = str_replace(':-|', '<img src="/images/smileys/user/Zalo/11.gif" alt="đỏ mặt sợ luôn"/>', $var);
$var = str_replace(':-h', '<img src="/images/smileys/user/Zalo/12.gif" alt=" nóng giận"/>', $var);
$var = str_replace(':P', '<img src="/images/smileys/user/Zalo/13.gif" alt=" lêu lêu đá lông nheo"/>', $var);
$var = str_replace(':p', '<img src="/images/smileys/user/Zalo/13.gif" alt=" lêu lêu đá lông nheo"/>', $var);
$var = str_replace(':D', '<img src="/images/smileys/user/Zalo/14.gif" alt=" cười nhe răng"/>', $var);
$var = str_replace(':d', '<img src="/images/smileys/user/Zalo/14.gif" alt=" cười nhe răng"/>', $var);
$var = str_replace(':o', '<img src="/images/smileys/user/Zalo/15.gif" alt="ngạc nhiên  hết hồn"/>', $var);
$var = str_replace(':(', '<img src="/images/smileys/user/Zalo/16.gif" alt=" buồn"/>', $var);
$var = str_replace(':+', '<img src="/images/smileys/user/Zalo/17.gif" alt=" hổ báo"/>', $var);
$var = str_replace('--b', '<img src="/images/smileys/user/Zalo/18.gif" alt=" đổ mồ hôi hột"/>', $var);
$var = str_replace(':q', '<img src="/images/smileys/user/Zalo/19.gif" alt=" bực bội khó chịu"/>', $var);
$var = str_replace(':t', '<img src="/images/smileys/user/Zalo/20.gif" alt=" mắc ói"/>', $var);
$var = str_replace(';p', '<img src="/images/smileys/user/Zalo/21.gif" alt="mắc cười quá"/>', $var);
$var = str_replace(';-d', '<img src="/images/smileys/user/Zalo/22.gif" alt="mắc cỡ"/>', $var);
$var = str_replace(';D', '<img src="/images/smileys/user/Zalo/23.gif" alt="giả điên "/>', $var);
$var = str_replace(';O', '<img src="/images/smileys/user/Zalo/24.gif" alt="sao cũng dc, ngõ lơ. "/>', $var);
$var = str_replace(';G', '<img src="/images/smileys/user/Zalo/25.gif" alt=" thèm quá"/>', $var);
$var = str_replace('|-)', '<img src="/images/smileys/user/Zalo/26.gif" alt="mở mắt hét lên"/>', $var);
$var = str_replace(':!', '<img src="/images/smileys/user/Zalo/27.gif" alt="ghê vậy"/>', $var);
$var = str_replace(':l', '<img src="/images/smileys/user/Zalo/28.gif" alt="mệt mỏi"/>', $var);
$var = str_replace(':&gt;', '<img src="/images/smileys/user/Zalo/29.gif" alt=" cười sảng khoái"/>', $var);
$var = str_replace(':;', '<img src="/images/smileys/user/Zalo/30.gif" alt="giang hồ"/>', $var);
$var = str_replace(';f', '<img src="/images/smileys/user/Zalo/31.gif" alt="cố lên"/>', $var);
$var = str_replace(';-s', '<img src="/images/smileys/user/Zalo/32.gif" alt="chửi xối xả"/>', $var);
$var = str_replace(';?', '<img src="/images/smileys/user/Zalo/33.gif" alt="k hiểu"/>', $var);
$var = str_replace(';-x', '<img src="/images/smileys/user/Zalo/34.gif" alt="im lặng"/>', $var);
$var = str_replace(':-f', '<img src="/images/smileys/user/Zalo/35.gif" alt="hoa mắt,"/>', $var);
$var = str_replace(';8', '<img src="/images/smileys/user/Zalo/36.gif" alt="tức giận"/>', $var);
$var = str_replace(';!', '<img src="/images/smileys/user/Zalo/37.gif" alt="lỡ dại"/>', $var);
$var = str_replace(';-!', '<img src="/images/smileys/user/Zalo/38.gif" alt="đầu lâu"/>', $var);
$var = str_replace(';xx', '<img src="/images/smileys/user/Zalo/39.gif" alt="đập nè, ăn búa"/>', $var);
$var = str_replace(':-bye', '<img src="/images/smileys/user/Zalo/40.gif" alt="bái bai"/>', $var);
$var = str_replace(':wipe', '<img src="/images/smileys/user/Zalo/41.gif" alt="toát mồ hôi"/>', $var);
$var = str_replace(':-dig', '<img src="/images/smileys/user/Zalo/42.gif" alt="móc ngoáy mũi,  "/>', $var);
$var = str_replace(':hanclap', '<img src="/images/smileys/user/Zalo/43.gif" alt="móc ngoáy mũi,  "/>', $var);
$var = str_replace('&amp;-(', '<img src="/images/smileys/user/Zalo/44.gif" alt="hổng biết gì à"/>', $var);
$var = str_replace('b-)', '<img src="/images/smileys/user/Zalo/45.gif" alt="nham hiểm"/>', $var);
$var = str_replace(':-l', '<img src="/images/smileys/user/Zalo/46.gif" alt="thấy gét"/>', $var);
$var = str_replace(':-r', '<img src="/images/smileys/user/Zalo/47.gif" alt="thấy gét"/>', $var);
$var = str_replace(':-o ', '<img src="/images/smileys/user/Zalo/48.gif" alt="hính mũi"/>', $var);
$var = str_replace('v-|', '<img src="/images/smileys/user/Zalo/49.gif" alt="chuyện nhỏ"/>', $var);
$var = str_replace('p-(', '<img src="/images/smileys/user/Zalo/50.gif" alt="khóc"/>', $var);
$var = str_replace(':--|', '<img src="/images/smileys/user/Zalo/51.gif" alt="mếu"/>', $var);
$var = str_replace('x-)', '<img src="/images/smileys/user/Zalo/52.gif" alt="cười nham hiểm"/>', $var);
$var = str_replace(':*', '<img src="/images/smileys/user/Zalo/53.gif" alt="thích thú hun"/>', $var);
$var = str_replace(';-a', '<img src="/images/smileys/user/Zalo/54.gif" alt="ngạc nhiên"/>', $var);
$var = str_replace('8*', '<img src="/images/smileys/user/Zalo/55.gif" alt="tội nghiệp mắt rưng rưng"/>', $var);
$var = str_replace('/-showlove', '<img src="/images/smileys/user/Zalo/56.gif" alt="showlove"/>', $var);
$var = str_replace('/-rose', '<img src="/images/smileys/user/Zalo/57.gif" alt="rose"/>', $var);
$var = str_replace('/-fade', '<img src="/images/smileys/user/Zalo/58.gif" alt="fade"/>', $var);
$var = str_replace('/-heart', '<img src="/images/smileys/user/Zalo/59.gif" alt="heart"/>', $var);
$var = str_replace('/-break', '<img src="/images/smileys/user/Zalo/60.gif" alt="break"/>', $var);
$var = str_replace('/-bd', '<img src="/images/smileys/user/Zalo/65.gif" alt=" phặc phặc chém à"/>', $var);
$var = str_replace('/-coffee', '<img src="/images/smileys/user/Zalo/61.gif" alt="cà phê "/>', $var);
$var = str_replace('/-cake', '<img src="/images/smileys/user/Zalo/62.gif" alt="bánh kem "/>', $var);
$var = str_replace('/-li', '<img src="/images/smileys/user/Zalo/63.gif" alt="sấm sét "/>', $var);
$var = str_replace('/-bome', '<img src="/images/smileys/user/Zalo/64.gif" alt=" nổ boom "/>', $var);
$var = str_replace('/-strong', '<img src="/images/smileys/user/Zalo/67.gif" alt=" số 1 "/>', $var);
$var = str_replace('/-weak', '<img src="/images/smileys/user/Zalo/68.gif" alt="yếu quá "/>', $var);
$var = str_replace('/-share', '<img src="/images/smileys/user/Zalo/69.gif" alt="bắt tay "/>', $var);
$var = str_replace('/-v', '<img src="/images/smileys/user/Zalo/70.gif" alt="chiến thắng "/>', $var);
$var = str_replace('/-thanks', '<img src="/images/smileys/user/Zalo/71.gif" alt="bái phục "/>', $var);
$var = str_replace('/-jj', '<img src="/images/smileys/user/Zalo/72.gif" alt="comemon bấy bì "/>', $var);
$var = str_replace('/-punch', '<img src="/images/smileys/user/Zalo/73.gif" alt="đấm phát chết luôn "/>', $var);
$var = str_replace('/-bad', '<img src="/images/smileys/user/Zalo/74.gif" alt="quá tệ"/>', $var);
$var = str_replace('/-loveu', '<img src="/images/smileys/user/Zalo/75.gif" alt="ai nóp zdu"/>', $var);
$var = str_replace('/-no', '<img src="/images/smileys/user/Zalo/76.gif" alt="ko có cửa"/>', $var);
$var = str_replace('/-ok', '<img src="/images/smileys/user/Zalo/77.gif" alt="ô kê "/>', $var);
$var = str_replace('/-flag', '<img src="/images/smileys/user/Zalo/78.gif" alt="lá cờ việt nam"/>', $var);
$var = str_replace(':bidanh', '<img src="../images/bidanh.png" alt="đang đợi đó"/>', $var);
//--Hết smile--//
		$var = preg_replace('#@([\w\d]{2,})#si', '@<b>$1</b>', $var);  ///@username
		$var = preg_replace('#PBoss ([\w\d]{2,})#si', 'PBoss <a href="/gamemini/boss/phong.php?id=$1">$1</a>', $var);  ///@username
		//$var = preg_replace('#\[img\](.*?)\[/img\]#si', '<img src="$1" border="0" style="max-width: 150px;"/><br /><small><a href="$1" title="Click to view image" target="_blank">[View Images]</a></small>', $var); //Chp ảnh
		$var = preg_replace('#\[c\](.*?)\[/c\]#si', '<span class="quote" style="display:block">$1</span>', $var); //Chp ảnh
		$var = preg_replace('#\[b\](.*?)\[/b\]#si', '<b>$1</b>', $var); //Chp ảnh
        $var = preg_replace('#\[color=(.+?)\](.+?)\[/color]#si', '$2', $var);
        $var = preg_replace('!\[bg=(#[0-9a-f]{3}|#[0-9a-f]{6}|[a-z\-]+)](.+?)\[/bg]!is', '$2', $var);
        $var = preg_replace('#\[spoiler=(.+?)\]#si', '$2', $var);
        $replace = array(
			'[img]' => '', 
			'[/img]' => '', 
			'[d]' => '', 
			'[/d]' => '',
            '[small]' => '',
            '[/small]' => '',
            '[big]' => '',
            '[/big]' => '',
            '[green]' => '',
            '[/green]' => '',
            '[red]' => '',
            '[/red]' => '',
            '[blue]' => '',
            '[/blue]' => '',
            '[b]' => '',
            '[/b]' => '',
			'[text]' => '',
            '[/text]' => '',
            '[i]' => '',
            '[/i]' => '',
            '[u]' => '',
            '[/u]' => '',
            '[s]' => '',
            '[/s]' => '',
            '[quote]' => '',
            '[/quote]' => '',
            '[c]' => '',
            '[/c]' => '',
            '[*]' => '',
            '[/*]' => ''
        );
        return strtr($var, $replace);
    }

    /*
    -----------------------------------------------------------------
    Подсветка кода
    -----------------------------------------------------------------
    */
    private static function highlight_code($var)
    {
        if (!function_exists('process_code')) {
            function process_code($php)
            {
                $php = strtr($php, array('<br />' => '', '\\' => 'slash_JOHNCMS'));
                $php = html_entity_decode(trim($php), ENT_QUOTES, 'UTF-8');
                $php = substr($php, 0, 2) != "<?" ? "<?php\n" . $php . "\n?>" : $php;
                $php = highlight_string(stripslashes($php), true);
                $php = strtr($php, array('slash_JOHNCMS' => '&#92;', ':' => '&#58;', '[' => '&#91;'));
                return '<div class="phpcode">' . $php . '</div>';
            }
        }
        return preg_replace(array('#\[php\](.+?)\[\/php\]#se'), array("''.process_code('$1').''"), str_replace("]\n", "]", $var));
    }

    /*
    -----------------------------------------------------------------
    Обработка URL в тэгах BBcode
    -----------------------------------------------------------------
    */
    private static function OLD_highlight_url($var)
    {
        if (!function_exists('process_url')) {
            function process_url($url)
            {
                $home = parse_url(core::$system_set['homeurl']);
                $tmp = parse_url($url[1]);
                    if ($home['host'] == $tmp['host'] || isset(core::$user_set['direct_url']) && core::$user_set['direct_url']) {
                        return '<a href="' . $url[1] . '">' . $url[2] . '</a>';
                    } else {
                        return '<a href="' . core::$system_set['homeurl'] . '/go.php?url=' . urlencode(htmlspecialchars_decode($url[1])) . '">' . $url[2] . '</a>';
                    }
            }
        }
        return preg_replace_callback('~\\[url=(https?://.+?)\\](.+?)\\[/url\\]~', 'process_url', $var);
    }

    /*
    -----------------------------------------------------------------
    Обработка bbCode
    -----------------------------------------------------------------
    */
    private static function highlight_bb($var)
    {
        // Список поиска
        $search = array(
			//'#\[img](.+?)\[/img]#is', // images 
			'#\[d](.+?)\[/d]#is', // link download
            '#\[b](.+?)\[/b]#is', // Жирный
            '#\[text](.+?)\[/text]#is', // Жирный
            '#\[c](.+?)\[/c]#is', // Жирный
            '#\[nick](.+?)\[/nick]#is', // Жирный
            '#\[i](.+?)\[/i]#is', // Курсив
            '#\[u](.+?)\[/u]#is', // Подчеркнутый
            '#\[s](.+?)\[/s]#is', // Зачеркнутый
            '#\[small](.+?)\[/small]#is', // Маленький шрифт
            '#\[big](.+?)\[/big]#is', // Большой шрифт
            '#\[red](.+?)\[/red]#is', // Красный
            '#\[green](.+?)\[/green]#is', // Зеленый
            '#\[blue](.+?)\[/blue]#is', // Синий
            '!\[color=(#[0-9a-f]{3}|#[0-9a-f]{6}|[a-z\-]+)](.+?)\[/color]!is', // Цвет шрифта
            '!\[bg=(#[0-9a-f]{3}|#[0-9a-f]{6}|[a-z\-]+)](.+?)\[/bg]!is', // Цвет фона
            '#\[(quote|c)](.+?)\[/(quote|c)]#is', // Цитата
            '#\[\*](.+?)\[/\*]#is', // Список
            '#\[url=(.+?)](.+?)\[/url]#is' // Спойлер
        );
        // Список замены
        $replace = array(
			//'<img src="$1" border="0" style="max-width: 150px;"/><br /><small><a href="$1" title="Click to view image" target="_blank">[View Images]</a></small>', //images 
			'<img src="'.self::$system_set['homeurl'].'/images/bb/download.gif" border="0"><a href="$1" title="Click to download">[Download]</a>',// link download

            '<span style="font-weight: bold">$1</span>', // Жирный
            '<textarea rows="2" cols="30">$1</textarea>', // Жирный
            '<div class="quote">$1</div>', // Жирный
            '<img src="/avatar/$1.png"/>', // Жирный
            '<span style="font-style:italic">$1</span>', // Курсив
            '<span style="text-decoration:underline">$1</span>', // Подчеркнутый
            '$1', // Зачеркнутый
            '<span style="font-size:x-small">$1</span>', // Маленький шрифт
            '<span style="font-size:large">$1</span>', // Большой шрифт
            '<span style="color:black">$1</span>', // Красный
            '<span style="color:black">$1</span>', // Зеленый
            '<span style="color:black">$1</span>', // Синий
            '<span style="color:$1">$2</span>', // Цвет шрифта
           '<span style="background-color: black">$2</span>', // Цвет фона
            '<span class="quote" style="display:block">$2</span>', // Цитата
            '<span class="bblist">$1</span>', // Список
            '<img src="'.self::$system_set['homeurl'].'/images/bb/download.gif" border="0" alt="download"/><a href="$1" title="Click để vào">$2</a>' // Спойлер
        );
        return preg_replace($search, $replace, $var);
    }

    /*
    -----------------------------------------------------------------
    Панель кнопок bbCode (для компьютеров)
    -----------------------------------------------------------------
    */
    public static function auto_bb($form, $field)
    {
        $colors = array(
            'ffffff', 'bcbcbc', '708090', '6c6c6c', '454545',
            'fcc9c9', 'fe8c8c', 'fe5e5e', 'fd5b36', 'f82e00',
            'ffe1c6', 'ffc998', 'fcad66', 'ff9331', 'ff810f',
            'd8ffe0', '92f9a7', '34ff5d', 'b2fb82', '89f641',
            'b7e9ec', '56e5ed', '21cad3', '03939b', '039b80',
            'cac8e9', '9690ea', '6a60ec', '4866e7', '173bd3',
            'f3cafb', 'e287f4', 'c238dd', 'a476af', 'b53dd2'
        );
        $i = 1;
        $font_color = '';
        $bg_color = '';
        foreach ($colors as $value) {
            $font_color .= '<a href="javascript:tag(\' [color=#' . $value . ']\', \'[/color]\'); show_hide(\'color\');" style="background-color:#' . $value . ';"></a>';
            $bg_color .= '<a href="javascript:tag(\' [bg=#' . $value . ']\', \'[/bg]\'); show_hide(\'bg\');" style="background-color:#' . $value . ';"></a>';
        }
        $smileys = !empty(self::$user_data['smileys']) ? unserialize(self::$user_data['smileys']) : '';
		$cacicon = '<div id="emoticons" class="collapse in" style="height: auto;">
					<a href="javascript:tag(\' :)\', \'\'); show_hide(\'sm\');"><img alt=":)" border="0" src="/images/smileys/user/Zalo/1.gif"></s>
					<a href="javascript:tag(\' :~\', \'\'); show_hide(\'sm\');"><img alt=":~" border="0" src="/images/smileys/user/Zalo/2.gif"></s>
					<a href="javascript:tag(\' :B\', \'\'); show_hide(\'sm\');"><img alt=":B" border="0" src="/images/smileys/user/Zalo/3.gif"></s>
					<a href="javascript:tag(\' :|\', \'\'); show_hide(\'sm\');"><img alt=":|" border="0" src="/images/smileys/user/Zalo/4.gif"></s>
					<a href="javascript:tag(\' 8-)\', \'\'); show_hide(\'sm\');"><img alt="8-)" border="0" src="/images/smileys/user/Zalo/5.gif"></s>
					<a href="javascript:tag(\' :-((\', \'\'); show_hide(\'sm\');"><img alt=":-((" border="0" src="/images/smileys/user/Zalo/6.gif"></s>
					<a href="javascript:tag(\' :$\', \'\'); show_hide(\'sm\');"><img alt=":$" border="0" src="/images/smileys/user/Zalo/7.gif"></s>
					<a href="javascript:tag(\' :x\', \'\'); show_hide(\'sm\');"><img alt=":x" border="0" src="/images/smileys/user/Zalo/8.gif"></s>
					<a href="javascript:tag(\' :z\', \'\'); show_hide(\'sm\');"><img alt=":z" border="0" src="/images/smileys/user/Zalo/9.gif"></s>
					<a href="javascript:tag(\' :((\', \'\'); show_hide(\'sm\');"><img alt=":((" border="0" src="/images/smileys/user/Zalo/10.gif"></s>
					<a href="javascript:tag(\' :-|\', \'\'); show_hide(\'sm\');"><img alt=":-|" border="0" src="/images/smileys/user/Zalo/11.gif"></s>
					<a href="javascript:tag(\' :-h\', \'\'); show_hide(\'sm\');"><img alt=":-h" border="0" src="/images/smileys/user/Zalo/12.gif"></s>
					<a href="javascript:tag(\' :p\', \'\'); show_hide(\'sm\');"><img alt=":p" border="0" src="/images/smileys/user/Zalo/13.gif"></s>
					<a href="javascript:tag(\' :d\', \'\'); show_hide(\'sm\');"><img alt=":d" border="0" src="/images/smileys/user/Zalo/14.gif"></s>
					<a href="javascript:tag(\' :o\', \'\'); show_hide(\'sm\');"><img alt=":o" border="0" src="/images/smileys/user/Zalo/15.gif"></s>
					<a href="javascript:tag(\' :(\', \'\'); show_hide(\'sm\');"><img alt=":(" border="0" src="/images/smileys/user/Zalo/16.gif"></s>
					<a href="javascript:tag(\' :+\', \'\'); show_hide(\'sm\');"><img alt=":+" border="0" src="/images/smileys/user/Zalo/17.gif"></s>
					<a href="javascript:tag(\' --b\', \'\'); show_hide(\'sm\');"><img alt="--b" border="0" src="/images/smileys/user/Zalo/18.gif"></s>
					<a href="javascript:tag(\' :q\', \'\'); show_hide(\'sm\');"><img alt=":q" border="0" src="/images/smileys/user/Zalo/19.gif"></s>
					<a href="javascript:tag(\' :t\', \'\'); show_hide(\'sm\');"><img alt=":t" border="0" src="/images/smileys/user/Zalo/20.gif"></s>
					<a href="javascript:tag(\' ;p\', \'\'); show_hide(\'sm\');"><img alt=";p" border="0" src="/images/smileys/user/Zalo/21.gif"></s>
					<a href="javascript:tag(\' ;-d\', \'\'); show_hide(\'sm\');"><img alt=";-d" border="0" src="/images/smileys/user/Zalo/22.gif"></s>
					<a href="javascript:tag(\' ;D\', \'\'); show_hide(\'sm\');"><img alt=";D" border="0" src="/images/smileys/user/Zalo/23.gif"></s>
					<a href="javascript:tag(\' ;O\', \'\'); show_hide(\'sm\');"><img alt=";O" border="0" src="/images/smileys/user/Zalo/24.gif"></s>
					<a href="javascript:tag(\' ;G\', \'\'); show_hide(\'sm\');"><img alt=";G" border="0" src="/images/smileys/user/Zalo/25.gif"></s>
					<a href="javascript:tag(\' |-)\', \'\'); show_hide(\'sm\');"><img alt="|-)" border="0" src="/images/smileys/user/Zalo/26.gif"></s>
					<a href="javascript:tag(\' :!\', \'\'); show_hide(\'sm\');"><img alt=":!" border="0" src="/images/smileys/user/Zalo/27.gif"></s>
					<a href="javascript:tag(\' :l\', \'\'); show_hide(\'sm\');"><img alt=":l" border="0" src="/images/smileys/user/Zalo/28.gif"></s>
					<a href="javascript:tag(\' :>\', \'\'); show_hide(\'sm\');"><img alt=":>" border="0" src="/images/smileys/user/Zalo/29.gif"></s>
					<a href="javascript:tag(\' :;\', \'\'); show_hide(\'sm\');"><img alt=":;" border="0" src="/images/smileys/user/Zalo/30.gif"></s>
					<a href="javascript:tag(\' ;f\', \'\'); show_hide(\'sm\');"><img alt=";f" border="0" src="/images/smileys/user/Zalo/31.gif"></s>
					<a href="javascript:tag(\' ;-s\', \'\'); show_hide(\'sm\');"><img alt=";-s" border="0" src="/images/smileys/user/Zalo/32.gif"></s>
					<a href="javascript:tag(\' ;?\', \'\'); show_hide(\'sm\');"><img alt=";?" border="0" src="/images/smileys/user/Zalo/33.gif"></s>
					<a href="javascript:tag(\' ;-x\', \'\'); show_hide(\'sm\');"><img alt=";-x" border="0" src="/images/smileys/user/Zalo/34.gif"></s>
					<a href="javascript:tag(\' :-f\', \'\'); show_hide(\'sm\');"><img alt=":-f" border="0" src="/images/smileys/user/Zalo/35.gif"></s>
					<a href="javascript:tag(\' ;8\', \'\'); show_hide(\'sm\');"><img alt=";8" border="0" src="/images/smileys/user/Zalo/36.gif"></s>
					<a href="javascript:tag(\' ;!\', \'\'); show_hide(\'sm\');"><img alt=";!" border="0" src="/images/smileys/user/Zalo/37.gif"></s>
					<a href="javascript:tag(\' ;-!\', \'\'); show_hide(\'sm\');"><img alt=";-!" border="0" src="/images/smileys/user/Zalo/38.gif"></s>
					<a href="javascript:tag(\' ;xx\', \'\'); show_hide(\'sm\');"><img alt=";xx" border="0" src="/images/smileys/user/Zalo/39.gif"></s>
					<a href="javascript:tag(\' :-bye\', \'\'); show_hide(\'sm\');"><img alt=":-bye" border="0" src="/images/smileys/user/Zalo/40.gif"></s>
					<a href="javascript:tag(\' :wipe\', \'\'); show_hide(\'sm\');"><img alt=":wipe" border="0" src="/images/smileys/user/Zalo/41.gif"></s>
					<a href="javascript:tag(\' :-dig\', \'\'); show_hide(\'sm\');"><img alt=":-dig" border="0" src="/images/smileys/user/Zalo/42.gif"></s>
					<a href="javascript:tag(\' :hanclap\', \'\'); show_hide(\'sm\');"><img alt=":hanclap" border="0" src="/images/smileys/user/Zalo/43.gif"></s>
					<a href="javascript:tag(\' &amp;-(\', \'\'); show_hide(\'sm\');"><img alt="&amp;-(" border="0" src="/images/smileys/user/Zalo/44.gif"></s>
					<a href="javascript:tag(\' b-)\', \'\'); show_hide(\'sm\');"><img alt="b-)" border="0" src="/images/smileys/user/Zalo/45.gif"></s>
					<a href="javascript:tag(\' :-l\', \'\'); show_hide(\'sm\');"><img alt=":-l" border="0" src="/images/smileys/user/Zalo/46.gif"></s>
					<a href="javascript:tag(\' :-r\', \'\'); show_hide(\'sm\');"><img alt=":-r" border="0" src="/images/smileys/user/Zalo/47.gif"></s>
					<a href="javascript:tag(\' :-o\', \'\'); show_hide(\'sm\');"><img alt=":-o" border="0" src="/images/smileys/user/Zalo/48.gif"></s>
					<a href="javascript:tag(\' v-|\', \'\'); show_hide(\'sm\');"><img alt="v-|" border="0" src="/images/smileys/user/Zalo/49.gif"></s>
					<a href="javascript:tag(\' p-(\', \'\'); show_hide(\'sm\');"><img alt="p-(" border="0" src="/images/smileys/user/Zalo/50.gif"></s>
					<a href="javascript:tag(\' :--|\', \'\'); show_hide(\'sm\');"><img alt=":--|" border="0" src="/images/smileys/user/Zalo/51.gif"></s>
					<a href="javascript:tag(\' x-)\', \'\'); show_hide(\'sm\');"><img alt="x-)" border="0" src="/images/smileys/user/Zalo/52.gif"></s>
					<a href="javascript:tag(\' :*\', \'\'); show_hide(\'sm\');"><img alt=":*" border="0" src="/images/smileys/user/Zalo/53.gif"></s>
					<a href="javascript:tag(\' ;-a\', \'\'); show_hide(\'sm\');"><img alt=";-a" border="0" src="/images/smileys/user/Zalo/54.gif"></s>
					<a href="javascript:tag(\' 8*\', \'\'); show_hide(\'sm\');"><img alt="8*" border="0" src="/images/smileys/user/Zalo/55.gif"></s>
					<a href="javascript:tag(\' /-showlove\', \'\'); show_hide(\'sm\');"><img alt="/-showlove" border="0" src="/images/smileys/user/Zalo/56.gif"></s>
					<a href="javascript:tag(\' /-rose\', \'\'); show_hide(\'sm\');"><img alt="/-rose" border="0" src="/images/smileys/user/Zalo/57.gif"></s>
					<a href="javascript:tag(\' /-fade\', \'\'); show_hide(\'sm\');"><img alt="/-fade" border="0" src="/images/smileys/user/Zalo/58.gif"></s>
					<a href="javascript:tag(\' /-heart\', \'\'); show_hide(\'sm\');"><img alt="/-heart" border="0" src="/images/smileys/user/Zalo/59.gif"></s>
					<a href="javascript:tag(\' /-break\', \'\'); show_hide(\'sm\');"><img alt="/-break" border="0" src="/images/smileys/user/Zalo/60.gif"></s>
					<a href="javascript:tag(\' /-coffee\', \'\'); show_hide(\'sm\');"><img alt="/-coffee" border="0" src="/images/smileys/user/Zalo/61.gif"></s>
					<a href="javascript:tag(\' /-cake\', \'\'); show_hide(\'sm\');"><img alt="/-cake" border="0" src="/images/smileys/user/Zalo/62.gif"></s>
					<a href="javascript:tag(\' /-li\', \'\'); show_hide(\'sm\');"><img alt="/-li" border="0" src="/images/smileys/user/Zalo/63.gif"></s>
					<a href="javascript:tag(\' /-bome\', \'\'); show_hide(\'sm\');"><img alt="/-bome" border="0" src="/images/smileys/user/Zalo/64.gif"></s>
					<a href="javascript:tag(\' /-bd\', \'\'); show_hide(\'sm\');"><img alt="/-bd" border="0" src="/images/smileys/user/Zalo/65.gif"></s>
					<a href="javascript:tag(\' /-shit\', \'\'); show_hide(\'sm\');"><img alt="/-shit" border="0" src="/images/smileys/user/Zalo/66.gif"></s>
					<a href="javascript:tag(\' /-strong\', \'\'); show_hide(\'sm\');"><img alt="/-strong" border="0" src="/images/smileys/user/Zalo/67.gif"></s>
					<a href="javascript:tag(\' /-weak\', \'\'); show_hide(\'sm\');"><img alt="/-weak" border="0" src="/images/smileys/user/Zalo/68.gif"></s>
					<a href="javascript:tag(\' /-share\', \'\'); show_hide(\'sm\');"><img alt="/-share" border="0" src="/images/smileys/user/Zalo/69.gif"></s>
					<a href="javascript:tag(\' /-v\', \'\'); show_hide(\'sm\');"><img alt="/-v" border="0" src="/images/smileys/user/Zalo/70.gif"></s>
					<a href="javascript:tag(\' /-thanks\', \'\'); show_hide(\'sm\');"><img alt="/-thanks" border="0" src="/images/smileys/user/Zalo/71.gif"></s>
					<a href="javascript:tag(\' /-jj\', \'\'); show_hide(\'sm\');"><img alt="/-jj" border="0" src="/images/smileys/user/Zalo/72.gif"></s>
					<a href="javascript:tag(\' /-punch\', \'\'); show_hide(\'sm\');"><img alt="/-punch" border="0" src="/images/smileys/user/Zalo/73.gif"></s>
					<a href="javascript:tag(\' /-bad\', \'\'); show_hide(\'sm\');"><img alt="/-bad" border="0" src="/images/smileys/user/Zalo/74.gif"></s>
					<a href="javascript:tag(\' /-loveu\', \'\'); show_hide(\'sm\');"><img alt="/-loveu" border="0" src="/images/smileys/user/Zalo/75.gif"></s>
					<a href="javascript:tag(\' /-no\', \'\'); show_hide(\'sm\');"><img alt="/-no" border="0" src="/images/smileys/user/Zalo/76.gif"></s>
					<a href="javascript:tag(\' /-ok\', \'\'); show_hide(\'sm\');"><img alt="/-ok" border="0" src="/images/smileys/user/Zalo/77.gif"></s>
					<a href="javascript:tag(\' /-flag\', \'\'); show_hide(\'sm\');"><img alt="/-flag" border="0" src="/images/smileys/user/Zalo/78.gif"></s>
					<a href="javascript:tag(\' :3\', \'\'); show_hide(\'sm\');"><img alt=":3" border="0" src="/images/smileys/user/Zalo/curlylips.png"></s>
					<a href="javascript:tag(\' :v\', \'\'); show_hide(\'sm\');"><img alt=":v" border="0" src="/images/smileys/user/Zalo/pacman.png"></s></div>';
        if (!empty($smileys)) {

            $bb_smileys = $cacicon;
        } else {
             $bb_smileys = $cacicon;
        }
        $out = '<style>.color a {float:left; display: block; width: 10px; height: 10px; margin: 1px; border: 1px solid black;}</style>
            <script language="JavaScript" type="text/javascript">
            function tag(text1, text2) {
              if ((document.selection)) {
                document.' . $form . '.' . $field . '.focus();
                document.' . $form . '.document.selection.createRange().text = text1+document.' . $form . '.document.selection.createRange().text+text2;
              } else if(document.forms[\'' . $form . '\'].elements[\'' . $field . '\'].selectionStart!=undefined) {
                var element = document.forms[\'' . $form . '\'].elements[\'' . $field . '\'];
                var str = element.value;
                var start = element.selectionStart;
                var length = element.selectionEnd - element.selectionStart;
                element.value = str.substr(0, start) + text1 + str.substr(start, length) + text2 + str.substr(start + length);
              } else {
                document.' . $form . '.' . $field . '.value += text1+text2;
              }
            }
            function show_hide(elem) {
              obj = document.getElementById(elem);
              if( obj.style.display == "none" ) {
                obj.style.display = "block";
              } else {
                obj.style.display = "none";
              }
            }
            </script>
            
           ';
        
        if (self::$user_id) {
            $out .= ' 
			<span class="smile_text">
			<a href="javascript:show_hide(\'sm\');">
			<span style="font-size: 10px">Hiện/Ẩn Icon Chat</span>
			</span>
                <table id="sm" style="display:none"><tr><td>' . $bb_smileys . '</td></tr></table>
                <div id="sm" style="display:none">'.$bb_smileys.'</div>';
        }else $out .= '<br />';
        $out .= '<div id="color" class="bbpopup" style="display:none;">Màu chữ: '.$font_color.'</div>'.
            '<div id="bg" class="bbpopup" style="display:none">Màu nền: '.$bg_color.'</div>';
        return $out;
    }
}