<?php
echo '<div class="footer-container">
<div class="footer">
<center>
<div class="copyrights" style="width: 100%">© 2015  <a href="/">Mạng xã hội ChoiOnline.Cf</a> 
<br/>Diễn đàn: <a href="https://m2v.me"><b>M2V.ME</b></a><br/>
Phát triển bởi ALL thành viên ChoiOnline
</div></center>
</div>
</div>
</div>
</div>
</div>';
?>