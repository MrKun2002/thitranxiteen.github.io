<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');



/*
-----------------------------------------------------------------
Выводим HTML заголовки страницы, подключаем CSS файл
-----------------------------------------------------------------
*/

header("Expires: " . date("r",  time() + 60));
echo '<?xml version="1.0" encoding="utf-8"?>' . "\n" .
"\n" . '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">' .
"\n" . '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">' .
"\n" . '<head>' .
"\n" . '<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>' .
"\n" . '<meta http-equiv="Content-Style-Type" content="text/css" />' .
"\n" . '<meta name="Generator" content="JohnCMS, http://m2v.me" />' . // ВНИМАНИЕ!!! Данный копирайт удалять нельзя
(!empty($set['meta_key']) ? "\n" . '<meta name="keywords" content="' . $set['meta_key'] . '" />' : '') .
(!empty($set['meta_desc']) ? "\n" . '<meta name="description" content="' . $set['meta_desc'] . '" />' : '') .
"\n" . '<link rel="stylesheet" href="http://m2v.me/theme/wapvina/style.css" type="text/css" />' .
"\n" . '<link rel="shortcut icon" href="' . $set['homeurl'] . '/favicon.ico" />' .
"\n" . '<link rel="alternate" type="application/rss+xml" title="RSS | ' . $lng['site_news'] . '" href="' . $set['homeurl'] . '/rss/rss.php" />' .
"\n" . '<title>' . $textl . '</title>' .
"\n" . '<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.3.min.js"></script><script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>'.
"\n" . '</head><body>' . core::display_core_errors();
//--- Mod Chatbox v3 ---//
echo "<script>
$(document).ready(function(){
$(\"#datachat1\").load(\"chemgio1.php\");
var refreshId = setInterval(function() {
$(\"#datachat1\").load('$home/chemgio1.php');
$(\"#datachat1\").slideDown(\"slow\");
}, 5000);
$(\"#shoutbox\").validate({
debug: false,
submitHandler: function(form) {
$.post('$home/chemgio1.php', $(\"#shoutbox\").serialize(),function(chatoutput) {
$(\"#datachat1\").html(chatoutput);
});
$(\"#msg\").val(\"\");
}
});
});
</script>";
/*



-----------------------------------------------------------------
Рекламный модуль
-----------------------------------------------------------------
*/

$cms_ads = array();
if (!isset($_GET['err']) && $act != '404' && $headmod != 'admin') {
$view = $user_id ? 2 : 1;
$layout = ($headmod == 'mainpage' && !$act) ? 1 : 2;
$req = mysql_query("SELECT * FROM `cms_ads` WHERE `to` = '0' AND (`layout` = '$layout' or `layout` = '0') AND (`view` = '$view' or `view` = '0') ORDER BY  `mesto` ASC");
if (mysql_num_rows($req)) {
while (($res = mysql_fetch_assoc($req)) !== false) {
$name = explode("|", $res['name']);
$name = htmlentities($name[mt_rand(0, (count($name) - 1))], ENT_QUOTES, 'UTF-8');
if (!empty($res['color'])) $name = '<span style="color:#' . $res['color'] . '">' . $name . '</span>';
// Если было задано начертание шрифта, то применяем
$font = $res['bold'] ? 'font-weight: bold;' : false;
$font .= $res['italic'] ? ' font-style:italic;' : false;
$font .= $res['underline'] ? ' text-decoration:underline;' : false;
if ($font) $name = '<span style="' . $font . '">' . $name . '</span>';
@$cms_ads[$res['type']] .= '<a href="' . ($res['show'] ? functions::checkout($res['link']) : $set['homeurl'] . '/go.php?id=' . $res['id']) . '">' . $name . '</a><br/>';
if (($res['day'] != 0 && time() >= ($res['time'] + $res['day'] * 3600 * 24)) || ($res['count_link'] != 0 && $res['count'] >= $res['count_link']))
mysql_query("UPDATE `cms_ads` SET `to` = '1'  WHERE `id` = '" . $res['id'] . "'");
}
}
}

/*

-----------------------------------------------------------------
Рекламный блок сайта
-----------------------------------------------------------------
*/
if (isset($cms_ads[0])) echo $cms_ads[0];

/*
-----------------------------------------------------------------
Выводим логотип и переключатель языков
-----------------------------------------------------------------
*/
if ($user_id){
if (!empty($cms_ads[1])) echo '<div class="mainblok">' . $cms_ads[1] . '</div>';
{$tinnhan = mysql_fetch_assoc(mysql_query("select * from `privat` where `user`='" . $login . "' and `type`='in' and `chit`='no' ORDER BY RAND() DESC"));
$idtin = '' .$tinnhan['id']. '';
$tinnhan1 = mysql_fetch_assoc(mysql_query("select * from `privat` where `user`='" . $login . "' and `type`='in' and `chit`='no' and `id`='" . $idtin . "';"));
$allprivat = mysql_fetch_assoc(mysql_query("SELECT `id` FROM `privat` ORDER BY `id` DESC LIMIT 1"));
$idtinout = '' .$allprivat['id']. '';
$idtr = $idtinout+1;
$lista = array();
//itcongnghe.tk//
$new_maila = mysql_result(mysql_query("SELECT COUNT(*) FROM `privat` WHERE `user` = '$login' AND `type` = 'in' AND `chit` = 'no'"), 0);
$textm = $tinnhan1['text'];
$textm = bbcode::tags($textm);
if ($set_user['smileys'])
//itcongnghe.tk//
if ($new_maila) $lista[] = '<b>'.$tinnhan1[author].'</b> : ' . $textm . '<br/><form name="guitinnhanh" action="' . $set['homeurl'] . '/users/pradd.php?act=send" method="post"><input type="hidden" name="foruser" value=" ' . $tinnhan1[author] . ' "/><input type="hidden" name="tem" value="Xin chào"/><textarea rows="1" name="msg"></textarea><input type="hidden" name="idm" value="' .$idtr. '"/><input type="submit" value="Gửi"/></form>';echo'</div>';
}
}
else{
echo '<div class="tmn"><a href="/login.php">Đăng nhập</a>|<a href="/registration.php">Đăng Ký</a>|<a href="/soo">Bang hội</a>|<a href="/soo/?id=1">Kênh M2V</a></div><div class="maintxt"><div itemscope itemtype="http://schema.org/Article" class="mainblok"><a href="/"><h2><b style="text-decoration: bolder;color : #417394;text-shadow: 0 0 6px #666;"><font color="brow">M</font><font color="red">2</font><font color="yellow">V</font>.ME</b></h2></a><p><b>Cộng đồng giải trí!</b></p></div>';
}
if ($user_id){

if ($user_id)



echo '<div class="tmn"><small> ';
echo ' <a href= "' . $set[ 'homeurl' ] . '/" > <img src= "http://m2v.me/images/home.gif" /> </a>'; echo ' <a href=/users/cont.php>Bạn bè</a> | <a href= "/soo" >Bang Hội</b></font></a>| ';echo '<a href= "' . $set[ 'homeurl' ] . '/soo/?id=1" > Kênh M2V</a>';
//$android = mysql_result(mysql_query("SELECT COUNT(*) FROM `soo_forum` WHERE `time` > '".(time() - 2000)."' AND `type` = 't' and kedit='0' AND `close`!='2315' AND `refid`='2316' OR `refid`='2313' OR `refid`='2310' OR `refid`='2306' OR `refid`='2305' OR `refid`='2281' OR `refid`='2280' OR `refid`='2279' OR `refid`='2277' OR `refid`='2271' OR `refid`='2268' OR `refid`='2266' OR `refid`='2264' OR `refid`='2261' OR `refid`='2258'"), 0);
//echo '<a href="/banghoi/47.html"><b>Mua Bán</b>'.($android > 0 ? '<span style="color:red; font-weight:bold;">['.$android.']</span>':'').'</a>  ';
//echo '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?act=office">Cá nhân</a> | ';
//$thongbao=mysql_result(mysql_query("select count(*) from `thongbao` where `id_to`='{$user_id}' and `type`='f'"),0);

//echo'<a href="'.$home.'/users/thongbao.php">Tường</a>';
//if($thongbao >0){echo'(<b><font color=red>'.$thongbao.'</font></b>)';}
$tbao = mysql_result(mysql_query("SELECT COUNT(*) FROM `hoatdong` WHERE `user_id_to`='{$user_id}' AND `type`='0'"), 0);

echo ' | <a href="/users/hoatdong.php?mod=fme">'.($tbao == 0 ? 'Hoạt động' : 'Hoạt động&#160;(<span style="color: red; font-weight: bold;">'.$tbao.'</span>)').'</a>';

///////////////

if ($user_id) {
$reqs = mysql_query("SELECT * FROM `soo_users` WHERE `user_id` = '" . $datauser['id'] . "' ORDER BY `id` DESC LIMIT 10");
$i = 1;
while ($res = mysql_fetch_assoc($reqs)) {

$ress = mysql_fetch_array(mysql_query("SELECT * FROM `soo` WHERE `id` = '". $res['sid'] ."'"));
$android1 = mysql_result(mysql_query("SELECT COUNT(*) FROM `soo_forum` WHERE `time` > '".(time() - 600)."' AND `sid` = '".$res['sid']."' AND `type` = 't' "), 0);

echo ' | ';
echo '<a href="../soo/?act=soo&amp;id='. $res['sid'] .'">' . functions::checkout($ress['name']) . ''.($android1 > 0 ? '(<span style="color:red; font-weight:bold;">'.$android1.'</span>)':'').'</a>';
}


echo ' <a href="' . $set['homeurl'] . '/exit.php"><img src="' . $set['homeurl'] . '/images/exit.png" alt="Thoát"></a></small>';

echo ' </div> </td> </tr> </table> </p>  ';

if (!empty($lista))
echo '<div style="color: #333333;
border: 1px solid #a1a1a1;
background-color: #fff5bc;
margin: 3px 0px 0px 0px;
padding: 2px 4px 2px 4px;">' . functions::display_menu($lista, ', ') . '</div>';
mysql_query("update `privat` set `chit`='yes' where `id`='" . $idtin . "';");
}

//--Thông tin User--//

echo'<div class="maintxt"><div itemscope itemtype="http://schema.org/Article" class="mainblok">';
//-Avatar-//

echo '<table cellpadding="1" cellspacing="0" width="100%"><tbody><tr><td align="left" width="32">';
if (!file_exists(($rootpath . 'files/users/avatar/' . $user_id . '.png')))

echo '<a href= "' .$set[ 'homeurl' ] . '/users/profile.php?act=office" ><img src="../images/empty.png" width="45" height="45" alt="' . $res['from'] . '" />&#160;</a></td><td>';
else

echo '<a href= "' .$set[ 'homeurl' ] . '/users/profile.php?act=office" ><img src="../files/users/avatar/' . $datauser['id'] . '.png" width="45" height="45" alt="' . $res['from'] . '" />&#160;</a></td><td>';



if (file_exists(('../files/users/avatar/' . $user_id . '.png')))
{

}

echo '<small>';
if ($datauser['sex'])
echo '<img src="http://m2v.me/theme/wapvina/images/' . ($datauser['sex'] == 'm' ? 'm' : 'w') . ($datauser['datereg'] > time() - 86400 ? '_new' : '') . '.png" width="16" height="16" align="middle" /><b> ' . $login . '
ID: ' . $user_id . '</b>';
$sdtmem = mysql_fetch_assoc(mysql_query("select `mibiles` from `users` where `id`='".$user_id."';"));
echo ' SĐT: <b>' . $sdtmem['mibiles'] . '</b> $:<b>  '.$datauser['vndtien'].' VNĐ</b> Xu:<b>  '.$datauser['xule'].' $</b><br/>';
if($datauser['vipmem'] == 1){ echo' <b><font color="red"><img src="http://m2v.me/theme/wapvina/images/star.gif">[Vip]</font></b>'; }
$req_mem = mysql_query("SELECT * FROM `users` WHERE `id` = '$user_id' LIMIT 1");
$res_mem = mysql_fetch_array($req_mem);
$slduocthank = $res_mem['explike'];
if ($slduocthank < 1)
{
$sotraitim = '';
}
if ($slduocthank >= 5)
{
$sotraitim = '<font color="#ff0000">♥</font>';
}
if ($slduocthank >= 20)
{
$sotraitim = '<font color="#ff0000">♥♥</font>';
}
if ($slduocthank >= 200)
{
$sotraitim = '<font color="#ff0000">♥♥♥</font>';
}
if ($slduocthank >= 700)
{
$sotraitim = '<font color="#ff0000">♥♥♥♥</font>';
}
if ($slduocthank >= 1100)
{
$sotraitim = '<font color="#ff0000">♥♥♥♥♥</font>';
}
if ($slduocthank >= 1700)
{
$sotraitim = '<font color="#ff0000">♥♥♥♥♥♥</font>';
}
if ($slduocthank >= 4000)
{
$sotraitim = '<font color="#ff0000">♥♥♥♥♥♥♥</font>';
}
if ($slduocthank >= 8000)
{
$sotraitim = '<font color="#ff0000">♥♥♥♥♥♥♥♥</font>';
}
if ($slduocthank >= 15000)
{
$sotraitim = '<font color="#ff0000">♥♥♥♥♥♥♥♥♥</font>';
}
if ($slduocthank >= 30000)
{
$sotraitim = '<font color="#ff0000">♥♥♥♥♥♥♥♥♥♥</font>';
}
if ($slduocthank >= 0)
{
echo ''.$sotraitim.'';
}
echo ' ' . $chucdanh . '';
if(!empty($datauser['danhhieu'])){ echo'<b><font color="#860086">['.$datauser['danhhieu'].']</font></b>'; }
$sao = $res_mem['sao']*1;
if($sao == 1) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="black"><b>[Vương Gia]</b></small></font><br><img src="http://m2v.me/img/sao.png"></br>';
}
if($sao == 2) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="black"><b>[Anh Hùng]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}
if($sao == 3) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="black"><b>[Hảo Hán]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}
if($sao == 4) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="blue"><b>[Tướng Quân]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}
if($sao == 5) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="blue"><b>[Ngũ Hổ Tướng]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}if($sao == 6) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="blue"><b>[Cao Thủ Võ Lâm]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}if($sao == 7) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="green"><b>[Thiên Hạ Đệ Nhất]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}if($sao == 8) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="green"><b>[Uy Trấn Giang Hồ]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}if($sao == 9) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="green"><b>[Vang Danh Thiên Hạ]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}
if($sao == 10) {
echo '<br><img src="http://m2v.me/theme/wapvina/images/star.gif"><font color="red"><b>[Võ lâm Chí Tôn]</b></small></font><br><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"><img src="http://m2v.me/img/sao.png"></br>';
}
echo '<div class="status">';
echo'<img src="../theme/' . $set_user['skin'] . '/images/label.png" align="middle" />&#160;';
echo '<font color="#CD853F"> '.$datauser['chuki'].'</font>';
echo '<br>';
//--Tâm Trạng--//

echo '<form action="/users/profile.php?act=office&user=' . $datauser['id'] . '" method="post">
<img src="/images/activity.gif"/>Share status <img src="/images/photo.gif"/><a href="/users/album.php?act=list" title="Chia sẻ hình ảnh">Chia sẻ hình ảnh</a>
<br><input type="text" value="" name="comments">
<input class="button_head" type="submit" value="Lưu" name="submit"></form>';
echo '<td align="right" width="auto" valign="top">';
//--Kết Thúc--//
echo '</small>';

echo '</div></td></tr></table></p></div>';


}
if($datauser['kichhoat'] == 1){
if ( $user_id && $datauser['dayb'] =='0'
||$user_id && $datauser['monthb'] =='0'
||$user_id && $datauser['yearofbirth']=='0'
||$user_id && $datauser['mail'] ==''
||$user_id && $datauser['about'] ==''
||$user_id && $datauser['skype'] ==''
||$user_id && $datauser['jabber'] ==''
||$user_id && $datauser['live'] ==''
||$user_id && $datauser['mibiles'] =='')
{
echo '<div class="rmenu" style="color:red">bạn  chưa điền đầy đủ thông tin cá nhân. <a href="'.$home.'/users/profile.php?act=edit" title="c?p nh?t thông tin">Click vào đây để cập nhật</a></div>';
}
echo '<div class="mainblok">';
//echo '<a href=http://m2v.me/banghoi/5-25405_p1.html><b>[Thông báo] Chúc mừng năm mới diễn đàn M2V</b></a></br>';

//echo '<div class="mainblok"><a href=http://m2v.me/banghoi/5-18979_p1.html><b>[Thông Báo] Tuyển Mod cho M2V đợt II</b></a></br>';
echo '<a href=http://taigame0d.com/><span style="color:#0000FF">[QC] taigame0d.com - wap tải game miễn phí - uy tín số một wap việt</span></br>';//xanh
echo '<a href=http://hostingervn.wap.sh><span style="color:#B8005C">[QC] Dịch Vụ làm WAP - Web - Forum Theo mọi demo - Bán hostinger giá rẻ cho HS - SV</span></a></br>'; //do
echo '<a href=http://FreeWeb5s.Com>[QC] FreeWeb5s - Domain, hostting giá rẻ, uy tín</a></br>';
echo'</div>';


}

/*
-----------------------------------------------------------------
Рекламный блок сайта
-----------------------------------------------------------------
*/
if ($user_id) {
}
else{
echo '<div class="mainblok">';
echo '<a href=http://taigame0d.com/><span style="color:#0000FF">[QC] taigame0d.com - wap tải game miễn phí - uy tín số một wap việt</span></br>';//xanh
echo '<a href=http://hostingervn.wap.sh><span style="color:#B8005C">[QC] Dịch Vụ làm WAP - Web - Forum Theo mọi demo - Bán hostinger giá rẻ cho HS - SV</span></a></br>'; //do
echo '<a href=http://FreeWeb5s.Com>[QC] FreeWeb5s - Domain, hostting giá rẻ, uy tín</a></br>';
echo'</div>';
if (!empty($cms_ads[1])) echo '<div class="mainblok">' . $cms_ads[1] . '</div>';
}
/*
-----------------------------------------------------------------
Фиксация местоположений посетителей
-----------------------------------------------------------------
*/
$sql = '';
$set_karma = unserialize($set['karma']);
if ($user_id) {
// Фиксируем местоположение авторизованных
if (!$datauser['karma_off'] && $set_karma['on'] && $datauser['karma_time'] <= (time() - 86400)) {
$sql = "`karma_time` = '" . time() . "', ";
}
$movings = $datauser['movings'];
if ($datauser['lastdate'] < (time() - 300)) {
$movings = 0;
$sql .= "`sestime` = '" . time() . "',";
}
if ($datauser['place'] != $headmod) {
++$movings;
$sql .= "`place` = '$headmod',";
}
if ($datauser['browser'] != $agn)
$sql .= "`browser` = '" . mysql_real_escape_string($agn) . "',";
$totalonsite = $datauser['total_on_site'];
if ($datauser['lastdate'] > (time() - 300))
$totalonsite = $totalonsite + time() - $datauser['lastdate'];
mysql_query("UPDATE `users` SET $sql
`movings` = '$movings',
`total_on_site` = '$totalonsite',
`lastdate` = '" . time() . "'
WHERE `id` = '$user_id'
");
} else {
// Фиксируем местоположение гостей
$movings = 0;
$session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
$req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '$session' LIMIT 1");
if (mysql_num_rows($req)) {
// Если есть в базе, то обновляем данные
$res = mysql_fetch_assoc($req);
$movings = $res['movings'];
if ($res['sestime'] < (time() - 300)) {
$movings = 0;
$sql .= "`sestime` = '" . time() . "', `movings` = '0'";
}
if ($res['place'] != $headmod) {
++$movings;
$sql .= "`place` = '$headmod',";
}
mysql_query("UPDATE `cms_sessions` SET $sql
`movings` = '$movings',
`lastdate` = '" .time()  . "'
WHERE `session_id` = '$session'
");
} else {
// Если еще небыло в базе, то добавляем запись
mysql_query("INSERT INTO `cms_sessions` SET
`session_id` = '" . $session . "',
`ip` = '" . core::$ip . "',
`ip_via_proxy` = '" . core::$ip_via_proxy . "',
`browser` = '" . mysql_real_escape_string($agn) . "',
`lastdate` = '" . time() . "',
`sestime` = '" . time() . "',
`place` = '$headmod'
");
}
}

/*
-----------------------------------------------------------------
Выводим сообщение о Бане
-----------------------------------------------------------------
*/
if (!empty($ban)) {
$a = mysql_query("SELECT * FROM `cms_ban_users` WHERE `user_id` =' " . $datauser['id'] . " ' ");
$b = mysql_fetch_assoc($a);
echo'<div class="phdr"><b>VI PHẠM CỦA BẠN TẠI m2v.me</b></div>';


$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '" . $user['id'] . "'"), 0);
if ($total) {
$req = mysql_query("SELECT * FROM `cms_ban_users` WHERE `user_id` = '" . $user['id'] . "' ORDER BY `ban_time` DESC LIMIT 1");
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
$remain = $res['ban_time'] - time();
$period = $res['ban_time'] - $res['ban_while'];
echo '<div class="bbcode_container"><div class="bbcode_quote"><div class="quote_container"><div class="bbcode_quote_container"></div><span style="font-weight: bold;"><div class=rmenu><b>Tài khoản của bạn đã bị cấm bởi BQT m2v.me</b>';
echo'<br>• <font color="red">Người khóa:</font> <b>'.$b['ban_who'].'</b><br/>• <font color="red">Vào ngày</font>:<b>'.date('d').' tháng '.date('m').'</b>
';
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '• <font color="red">Lý do</font>:' .

'<b> ' . functions::checkout($res['ban_reason']) .
'</b>';
if ($capql > 0)
echo '<span class="gray">' . $lng_ban['ban_who'] . ':</span> ' . $res['ban_who'] . '<br />';
echo '<br/>•<font color="red"> Thời hạn</font>:<b> ' . ($period < 86400000
? functions::timecount($period) : $lng_ban['ban_time_before_cancel']);
if ($remain > 0)
echo '</b><br /><span class="gray">• <font color="red">Vẫn còn</font>:<b></span> ' . functions::timecount($remain);
echo '</b></span></span></div></div></div></div>';
// Меню отдельного бана
$menu = array();
if ($capql >= 7 && $remain > 0)
$menu[] = '<a href="profile.php?act=ban&amp;mod=cancel&amp;user=' . $user['id'] . '&amp;ban=' . $res['id'] . '">' . $lng_ban['ban_cancel_do'] . '</a>';
if ($capql == 9)
$menu[] = '<a href="profile.php?act=ban&amp;mod=delete&amp;user=' . $user['id'] . '&amp;ban=' . $res['id'] . '">' . $lng_ban['ban_delete_do'] . '</a>';
if (!empty($menu))
echo '<div>' . functions::display_menu($menu) . '</div>';
echo '</div>';
++$i;
}
} else {
echo '<div class="bbcode_container"><div class="bbcode_quote"><div class="quote_container"><div class="bbcode_quote_container"></div><div class=rmenu><span style="font-weight: bold;"><span style="color:red"><b>Tài khoản của bạn đã bị cấm</b></span></span>';
echo'<a href="http://m2v.me/users/profile.php?act=ban"> [Chi tiết]</a></span></div></div></div></div></div>

';

} 
include'end.php';
exit;
}
/*

-----------------------------------------------------------------
Ссылки на непрочитанное
-----------------------------------------------------------------
*/
if ($user_id) {
$list = array();
$new_sys_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `read`='0' AND `sys`='1' AND `delete`!='$user_id';"), 0);
if($new_sys_mail)
echo '<br><div class=rmenu><a href="' . $home . '/mail/index.php?act=systems">Bạn có <b><font color="red">' . $new_sys_mail . '</font></b> lời mời kết bạn</a></div>';
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id' WHERE `cms_mail`.`from_id`='$user_id' AND `cms_mail`.`sys`='0' AND `cms_mail`.`read`='0' AND `cms_mail`.`delete`!='$user_id' AND `cms_contact`.`ban`!='1' AND `cms_mail`.`spam`='0'"), 0);
if($new_mail)
echo '<br><div class=rmenu><a href="' . $set['homeurl'] . '/mail/index.php?act=new">Bạn có <b><font color="red">' . $new_mail . '</font></b> tin nhắn mới</a></div>';


$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
if($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm">' . $lng['albums_comments'] . '</a>';
if (!empty($list)) echo '<div class="rmenu">' . $lng['unread'] . ': ' . functions::display_menu($list, ', ') . '</div>';
}
mysql_query ( "UPDATE `users` SET $sql `total_on_site` = ' $totalonsite ', `lastdate` = " . time () . " WHERE `id` = '2'" );
 $time=date("H:i");
if($time>="20:00" && $time<="21:59"){
echo '<div class="rmenu"><a href="http://m2v.me/mod/nap.php" title="KM nạp xu"><font color="red"><img src="http://my.teamobi.com/images/hot.gif">[HOT] Ưu đãi giờ vàng từ 20h-22h</font></a></div>';
}
else {
echo '';

}


?>
