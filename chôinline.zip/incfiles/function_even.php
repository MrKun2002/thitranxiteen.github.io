<?php
// Chèn vào phần chat box
function noel_chat_box($data,$users){
	// $user = $users['id'];
	// date_default_timezone_set('Asia/Ho_Chi_Minh');
	// $time = date("d");
	// $time_ht = time()+1;
	// $text = '';
	// if($data == 'Giáng sinh an lành' || $data == 'Giang sinh an lanh' || $data == 'giang sinh an lanh'){
		// $msg = 'Ta đã tặng cho con một chiếc kẹo nhân dịp sự kiện giáng sinh này... :D';
		// if($users['time_qua_even'] != $time){
			// mysql_query("INSERT INTO `guest` SET
            // `adm` = '',
            // `time` = '" . $time_ht . "',
            // `user_id` = '4783',
            // `name` = 'Noel',
            // `text` = '" . mysql_real_escape_string($msg) . "',
            // `ip` = '1024',
            // `browser` = 'PRO'
			// ");
			// mysql_query("UPDATE `users` SET `time_qua_even` = '{$time}' WHERE `id` = '{$user}'");
			// mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`, `thongtin`) 
			// VALUES  ('4', 'vatpham', '".$user."' , '0','0', 'Kẹo Noel', 'Dùng cho sự kiện')
			// ");
		// }
	// }
}
// Chèn vào nông trại phần thu hoạch
function even_sk($users){
	$so = 1;
	$rand = rand(1,6);
	if($so == $rand && $users == 1){
		mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`, `thongtin`) 
		VALUES  ('4', 'vatpham', '".$users."' , '0','0', 'Kẹo Noel', 'Dùng cho sự kiện')
		");
		$text = '&mn';
	}else{
		$text = '';
	}
	return $text;
}
// Chèn ở auto farm
function even_sk_auto_farm($users){
	// $so = 1;
	// $rand = rand(1,7);
	// if($so == $rand){
		// mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`, `thongtin`) 
		// VALUES  ('4', 'vatpham', '".$users."' , '0','0', 'Kẹo Noel', 'Dùng cho sự kiện')
		// ");
		// $text = 1;
	// }else{
		// $text = 0;
	// }
	$text = 0;
	return $text;
}

?>