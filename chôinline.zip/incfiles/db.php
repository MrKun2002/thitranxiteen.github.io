<?php

defined('_IN_JOHNCMS') or die ('Error: restricted access');
date_default_timezone_set('Asia/Ho_Chi_Minh');

$db_host = 'localhost';
$db_name = 'sacmau_demo';
$db_user = 'sacmau_demo';
$db_pass = 'Anhthuan12';
?>