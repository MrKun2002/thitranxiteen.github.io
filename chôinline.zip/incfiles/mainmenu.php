Incfiles/mainmenu

$req=mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type` = 'f' AND `refid` != '2098' ORDER BY `realid`");
while($res=mysql_fetch_array($req)) {
echo'<div class="fmenu">';
echo'<b>'.$res['text'] .'</b>';
echo'<div class="sub" />';
$cat=$res['id'];
$req1=mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type` = 'r' AND `refid` = '$cat' ORDER BY `realid`");
while($res1=mysql_fetch_assoc($req1)) {
$totaltopic=mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `refid` = '".$res1['id'] ."'"),0);
echo'<div>» <a href="/forum/'.functions::rewrite($res1["text"]).'_'.$res1['id'] .'.html" title="'.$res1['text'].'">'.$res1['text'] .'</a><span style="float:right">['.$totaltopic.']</span></div>';
$i;
}
$i;
}
echo'</div></div>';