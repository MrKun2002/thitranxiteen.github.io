<?php
//---MOD-BY-BONGMA007---//
defined('_IN_JOHNCMS') or die('Error: restricted access');
$headmod = isset($headmod) ? mysql_real_escape_string($headmod) : '';
$textl = isset($textl) ? $textl : $set['copyright'];
if (stristr(core::$user_agent, "msie") && stristr(core::$user_agent, "windows")) {
    // Выдаем заголовки для Internet Explorer
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header('Content-type: text/html; charset=UTF-8');
} else {
    // Выдаем заголовки для остальных браузеров
    header("Cache-Control: public");
    
}
header("Expires: " . date("r", time() + 60));
echo'<?xml version="1.0" encoding="utf-8"?>' . "\n" .
    "\n" . '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">' .
    "\n" . '<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" /><meta name="MobileOptimized" content="100" />' .
    "\n" . '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="vn"  lang="vn">' .
    "\n" . '<head>' .
    "\n" . '<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8"/>' .
    "\n" . '<meta http-equiv="Content-Style-Type" content="text/css" />' .
    "\n" . '<meta name="geo.region" content="vn" />' .
    "\n" . '<meta name="robots" content="index,follow" />' .
    (!empty($set['meta_key']) ? "\n" . '<meta name="keywords" content="' . $set['meta_key'] . '" />' : '') .
    (!empty($set['meta_desc']) ? "\n" . '<meta name="description" content="' . $set['meta_desc'] . '" />' : '') .
    "\n" . '<link rel="shortcut icon" href="' . $set['homeurl'] . '/favicon.ico" />' .
     "\n" . '<title>' . $textl . '</title>' .
	"\n" . '<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.3.min.js"></script><script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>'.
	"\n" . '' . core::display_core_errors();
echo '<link rel="stylesheet" href="' . $set['homeurl'] . '/Style/choionline/style.css" type="text/css" />';

?>
<script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-46711751-7', 'auto');
  ga('send', 'pageview');

</script>
<?php
echo '</head><body>
<div class="backgr">
';
	//--- Mod Chatbox v3 ---//
	echo '<div class="main">';

echo '
<div class="main_body">
<div class="st_toplogo">
<div style="text-align: center"><a href="/"><img src="/icon/logo.png" alt="wap game avata online" title="mang xa hoi choi game avata online" /></a>
</div></div>
';

//--Dành Cho Khách
if(!$user_id) {
//echo '<div class="rmenu"><marquee><font><b>AE tiến hành đăng nhập lại nick nhé, không phải là do mất nick đâu, do một số kẻ lợi dụng mấy cái thủ thuật nhỏ để phá thôi</b></font></marquee></div>';

}else{
if($datauser['giaodien'] == 1){
 //echo '<script type="text/javascript" src="/Style/tuyet.js"></script>';
}
echo '<div class="phdr"><small>';
  $tbao = mysql_result(mysql_query("SELECT COUNT(*) FROM `hoatdong` WHERE `user_id`='{$user_id}' AND `view`='0' AND `type` != 'e'"), 0);
if ($datauser['comm_count'] > $datauser['comm_old']) {
}else{
}
echo '<a href="/thongbaofr/">'.($tbao == 0 ? 'Thông báo</a>' : 'Thông báo&#160;</a>(<span style="color: red; font-weight: bold;">'.$tbao.'</span>)').'  | ';
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id' WHERE `cms_mail`.`from_id`='$user_id' AND `cms_mail`.`sys`='0' AND `cms_mail`.`read`='0' AND `cms_mail`.`delete`!='$user_id' AND `cms_contact`.`ban`!='1' AND `cms_mail`.`spam`='0'"), 0);
if ($new_mail) {
}else{ 
}
echo '<a href="/ruong/">Rương</a>  |';
echo ' <a style="color: red" href="/bxh.html"><b>TOP</b></a>  |';
echo ' <span class="red"><a href="/exit.php">Thoát</a></span> </small></div>';
echo '
</div>
<div class="user_profile">
<table cellpadding="1" cellspacing="0" width="100%"><tbody><tr><td align="left" width="32">
<a href="http://choionline.cf/users/profile.php?user='.$datauser[id].'"><img src="/avatar/'.$datauser['id'].'.png" alt="'.$datauser['name'].'"></a> </td><td><small>
<img src="/images/'.$datauser['sex'].'.png" alt="" class="icon-inline"><b> '.$datauser['name'].'</b> ID: '.$datauser['id'].' SĐT: '.$datauser['mibile'].' 
</br><img src="/images/star.gif">Xu: '.$datauser['balans'].' - Lượng: '.$datauser['luong'].'</br><img src="/images/star.gif">';

if(exp_chinhc($datauser[exp_chinh]) != "") echo ' Cấp: <span style="color: #1f812d">'.exp_chinhc($datauser[exp_chinh]).' </span> ('.$datauser[exp_chinh].' EXP)';
echo '</small>';

echo '</div></td></tr></table></p></div>';
//-- Dành Cho Member
$thongbaoforum = mysql_fetch_array(mysql_query("SELECT * FROM `thongbao` ORDER BY `id` DESC LIMIT 1"));
$tinhtimeht = time() - $thongbaoforum['time'];
if($tinhtimeht <= 180){
echo '<div class="rmenu"><marquee><font><b>'.$thongbaoforum['text'].'</b></font></marquee></div>';
}else{
	//echo '<div class="rmenu"><marquee><font><b>Tiến hành bảo trì nâng cấp máy chủ gấp vào tầm 15-20p nữa. AE tạm dừng các hoạt động để tránh việc mất mát dữ liệu. AD không chịu trách nhiệm nhé :) !</b></font></marquee></div>';
}
}
//--END Header

echo '<div class="maintxt">';
if (!empty($cms_ads[1])) echo '<div class="list1"><img src="/images/new.gif"> ' . $cms_ads[1] . '</div>';
$sql = '';
$set_karma = unserialize($set['karma']);
if ($user_id) {
    // Фиксируем местоположение авторизованных
    if (!$datauser['karma_off'] && $set_karma['on'] && $datauser['karma_time'] <= (time() - 86400)) {
        $sql .= " `karma_time` = '" . time() . "', ";
    }
    $movings = $datauser['movings'];
    if ($datauser['lastdate'] < (time() - 300)) {
        $movings = 0;
        $sql .= " `sestime` = '" . time() . "', ";
    }
    if ($datauser['place'] != $headmod) {
        ++$movings;
        $sql .= " `place` = '" . mysql_real_escape_string($headmod) . "', ";
    }
    if ($datauser['browser'] != $agn)
        $sql .= " `browser` = '" . mysql_real_escape_string($agn) . "', ";
    $totalonsite = $datauser['total_on_site'];
    if ($datauser['lastdate'] > (time() - 300))
        $totalonsite = $totalonsite + time() - $datauser['lastdate'];
    mysql_query("UPDATE `users` SET $sql
        `movings` = '$movings',
        `total_on_site` = '$totalonsite',
        `lastdate` = '" . time() . "'
        WHERE `id` = '$user_id'
    ");
} else {
    // Фиксируем местоположение гостей
    $movings = 0;
    $session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
    $req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '$session' LIMIT 1");
    if (mysql_num_rows($req)) {
        // Если есть в базе, то обновляем данные
        $res = mysql_fetch_assoc($req);
        $movings = ++$res['movings'];
        if ($res['sestime'] < (time() - 300)) {
            $movings = 1;
            $sql .= " `sestime` = '" . time() . "', ";
        }
        if ($res['place'] != $headmod) {
            $sql .= " `place` = '" . mysql_real_escape_string($headmod) . "', ";
        }
        mysql_query("UPDATE `cms_sessions` SET $sql
            `movings` = '$movings',
            `lastdate` = '" . time() . "'
            WHERE `session_id` = '$session'
        ");
    } else {
        // Если еще небыло в базе, то добавляем запись
        mysql_query("INSERT INTO `cms_sessions` SET
            `session_id` = '" . $session . "',
            `ip` = '" . core::$ip . "',
            `ip_via_proxy` = '" . core::$ip_via_proxy . "',
            `browser` = '" . mysql_real_escape_string($agn) . "',
            `lastdate` = '" . time() . "',
            `sestime` = '" . time() . "',
            `place` = '" . mysql_real_escape_string($headmod) . "'
        ");
    }
}

/*
-----------------------------------------------------------------
Выводим сообщение о Бане
-----------------------------------------------------------------
*/
//Mod cap dat nong trai//
if($datauser['phongthu'] == 1){
	mysql_query("INSERT INTO `fermer_gr` (`semen`, `id_user`) VALUES  ( '0', '".$datauser["id"]."') ");
	mysql_query("INSERT INTO `fermer_gr` (`semen`, `id_user`) VALUES  ( '0', '".$datauser["id"]."') ");
	mysql_query("INSERT INTO `fermer_gr` (`semen`, `id_user`) VALUES  ( '0', '".$datauser["id"]."') ");
	mysql_query("INSERT INTO `fermer_gr` (`semen`, `id_user`) VALUES  ( '0', '".$datauser["id"]."') ");
	mysql_query("INSERT INTO `fermer_gr` (`semen`, `id_user`) VALUES  ( '0', '".$datauser["id"]."') ");
	mysql_query("INSERT INTO `fermer_gr` (`semen`, `id_user`) VALUES  ( '0', '".$datauser["id"]."') ");
	mysql_query("UPDATE `users` SET `phongthu`= 0 WHERE `id`='".$datauser["id"]."'");
}
if($datauser['farm_vatnuoi'] == 0){
	mysql_query("UPDATE `users` SET `farm_vatnuoi`= '3' WHERE `id`='".$datauser["id"]."'");
}
if (!empty($ban)) 
{
echo '<div class="alarm">' . $lng['ban'] . '&#160;<a href="' . $set['homeurl'] . '/users/profile.php?act=ban">' . $lng['in_detail'] . '</a></div>';
$bantv = mysql_query("SELECT * FROM `cms_ban_users` WHERE `user_id` = '".$datauser["id"]."'");
while($timkiemban = mysql_fetch_array($bantv)){
if($timkiemban['wap'] == 1){
header('Location: /ban.php');
}
}
}
//---bot online---//
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '1'");

///--Kết Thúc--//
//if ($user_id) {
  //  $list = array();
    //$new_sys_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `read`='0' AND `sys`='1' AND `delete`!='$user_id';"), 0);
	//if ($new_sys_mail) $list[] = '<a href="' . $home . '/mail/index.php?act=systems">Hệ thống</a> (+' . $new_sys_mail . ')';
	//$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id' WHERE `cms_mail`.`from_id`='$user_id' AND `cms_mail`.`sys`='0' AND `cms_mail`.`read`='0' AND `cms_mail`.`delete`!='$user_id' AND `cms_contact`.`ban`!='1' AND `cms_mail`.`spam`='0'"), 0);
	//if ($new_mail) $list[] = '<a href="' . $home . '/mail/index.php?act=new">' . $lng['mail'] . '</a> (+' . $new_mail . ')';
    //if ($datauser['comm_count'] > $datauser['comm_old']) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/profile.php?act=guestbook&amp;user=' . $user_id . '">' . $lng['guestbook'] . '</a> (' . ($datauser['comm_count'] - $datauser['comm_old']) . ')';
    //$new_album_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . core::$user_id . "' AND `unread_comments` = 1"), 0);
    //if ($new_album_comm) $list[] = '<a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top&amp;mod=my_new_comm">' . $lng['albums_comments'] . '</a>';

    //if (!empty($list)) echo '<div class="rmenu">' . $lng['unread'] . ': ' . functions::display_menu($list, ', ') . '</div>';
//}
////////////Mod chan le
$ql3 = mysql_query("SELECT * FROM `chanle` WHERE `to_id`='".$user_id."' OR `from_id`='".$user_id."'");

///////
$ql3fet = mysql_fetch_assoc($ql3);
$ktott3  =  mysql_result(mysql_query("SELECT COUNT(`to_id`)FROM `chanle` WHERE `to_id`='".$ql3fet['to_id']."' OR `from_id`='".$ql3fet['from_id']."'"), 0);
if($ktott3 != 0) {
if(time() > $ql3fet['time'] + 300) {
mysql_query("UPDATE `users` SET
`balans`=`balans` + ".$ql3fet['coin']." WHERE `id`='".$ql3fet['to_id']."'");
$q="UPDATE `users` SET
`balans`=`balans` + ".$ql3fet['coin']." WHERE `id`='".$ql3fet['to_id']."'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','',./incfiles/head.php'".date('d-m-Y  h:i:s A')."')");
$ql3user = mysql_query("SELECT `name` FROM `users` WHERE `id`='".$ql3fet['from_id']."'");
$ql3user_fet = mysql_fetch_array($ql3user);
$ql3user3 = mysql_query("SELECT `name` FROM `users` WHERE `id`='".$ql3fet['to_id']."'");
$ql3user_fet3 = mysql_fetch_array($ql3user3);
$text = 'Thông báo kết quả sóc đĩa';
$noidung = 'Đã qua 5 phút mà bạn '.$ql3user_fet['name'].' không trả lời thư mời chơi chẵn lẻ của bạn. Hệ thống sẽ tự động hoàn tiền cho bạn!';
mysql_query("INSERT INTO `hoatdong` SET
`time` = '".time()."',
`fr_user` = '0',
`tiencuoc` = '".$datcuoc."',
`loinhan` = '" .mysql_real_escape_string($noidung). "',
`type` = 'x',
`user_id` = '" .$ql3fet["to_id"]. "';");
mysql_query("DELETE FROM `chanle` WHERE `to_id`='".$ql3fet['to_id']."' OR `from_id`='".$ql3fet['from_id']."'");
}
}
//ket thuc
// mod kiem tra online, offline //

//ket thuc
// mod link giớii thiệu//
if($user_id){
$datado['ao'] = $datauser['ao'];
$datado['toc'] = $datauser['toc'];
$datado['quan'] = $datauser['quan'];
$datado['non'] = $datauser['non'];
$datado['mat'] = $datauser['mat'];
$datado['matna'] = $datauser['matna'];
$datado['canh'] = $datauser['canh'];
$datado['thucung'] = $datauser['thucung'];
$datado['docamtay'] = $datauser['docamtay'];
$datado['kinh'] = $datauser['kinh'];
$datado['haoquang'] = $datauser['haoquang'];
$datado['luutrusm'] = $datauser['luutrusm'];
domacsm($datado,$user_id);
//mod thong tin users
if ($datauser['comm_count'] > $datauser['comm_old']) {
echo '<div class="rmenu" style="font-size: 14px"> ';

echo '<a href="/users/profile.php?act=guestbook&user='.$datauser[id].'.html">Tường nhà</a> (<span style="color: red; font-weight: bold;">' . ($datauser['comm_count'] - $datauser['comm_old']) . '</span>) · ';
echo'</div>';
}else{
}

$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id' WHERE `cms_mail`.`from_id`='$user_id' AND `cms_mail`.`sys`='0' AND `cms_mail`.`read`='0' AND `cms_mail`.`delete`!='$user_id' AND `cms_contact`.`ban`!='1' AND `cms_mail`.`spam`='0'"), 0);
if ($new_mail) {
echo '<div class="rmenu" style="font-size: 14px"> ';

echo '<a href="' . $home . '/mail/index.php?act=new">Thư</a> (<span style="color: red; font-weight: bold;">' . $new_mail . '</span>) · ';
echo'</div>';
}else{ 
}

if($datauser['mail'] == "" || $datauser['mibile'] == ""){
echo '<br/> Bạn chưa cập nhật ';
if($datauser['mail'] == ""){
	echo '<b>Email</b>';
}
if($datauser['mibile'] == ""){
	echo ' <b>SĐT</b>';
}
echo '. Hãy vào <a href="http://choionline.cf/users/profile.php?act=edit"><b style="color: red;">ĐÂY</b></a> để cập nhật nhé!';
}
echo '</td></tr></tbody></table></div>
</div>
';
// Mod luu tru suc manh
if($datauser[sucmanh] < $datauser[luutrusm]){

	$timehientai = time();
	$tinhtime = $datauser[luutrusmtime]+1600;
	if($timehientai >= $tinhtime){
		mysql_query("UPDATE `users` SET `luutrusmtime` = '".time()."' WHERE `id`='{$user_id}'");
		mysql_query("UPDATE `users` SET `sucmanh` = $datauser[luutrusm] WHERE `id`='{$user_id}'");
		echo '<div class="list1"><img src="/images/dongho.png"> Sức mạnh của bạn đã được phục hồi!</div>';
	}else{
		$timeht = time();
		$tinhtime2 = $tinhtime - $timeht;
		$tinhphut2 = $tinhtime2 / 60;
		$tinhphut = (int)$tinhphut2;
		echo '<div class="list1"><img src="/images/dongho.png"> Sức mạnh của bạn sẽ phục hồi trong vòng '.$tinhphut.' phút nữa!</div>';
	}
}else{
mysql_query("UPDATE `users` SET `sucmanh` = $datauser[luutrusm] WHERE `id`='{$user_id}'");
}
if($datauser[sucmanh2] < $datauser[luutrusm]){
	$kiemtrachuphong = mysql_result(mysql_query("SELECT COUNT(*) FROM `gamemini_boss_phong` WHERE `chuphong` = '$user_id'"), 0);
	$kiemnguoichoi1 = mysql_result(mysql_query("SELECT COUNT(*) FROM `gamemini_boss_phong` WHERE `nguoichoi1` = '$user_id'"), 0);
	$kiemnguoichoi2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `gamemini_boss_phong` WHERE `nguoichoi2` = '$user_id'"), 0);
	$kiemnguoichoi3 = mysql_result(mysql_query("SELECT COUNT(*) FROM `gamemini_boss_phong` WHERE `nguoichoi3` = '$user_id'"), 0);
	if($kiemtrachuphong == 0 && $kiemnguoichoi1 == 0 && $kiemnguoichoi2 == 0 && $kiemnguoichoi3 == 0){
	$timehientai = time();
	$tinhtime = $datauser[luutrusmtime2]+1600;
	if($timehientai >= $tinhtime){
		mysql_query("UPDATE `users` SET `luutrusmtime2` = '".time()."' WHERE `id`='{$user_id}'");
		mysql_query("UPDATE `users` SET `sucmanh2` = $datauser[luutrusm] WHERE `id`='{$user_id}'");
		echo '<div class="list1"><img src="/images/dongho.png"> Sức mạnh chiến đấu của bạn đã được phục hồi!</div>';
	}else{
		$timeht = time();
		$tinhtime2 = $tinhtime - $timeht;
		$tinhphut2 = $tinhtime2 / 60;
		$tinhphut = (int)$tinhphut2;
		echo '<div class="list1"><img src="/images/dongho.png"> Sức mạnh chiến đấu của bạn sẽ phục hồi trong vòng '.$tinhphut.' phút nữa!</div>';
	}
	}
}else{
mysql_query("UPDATE `users` SET `sucmanh2` = $datauser[luutrusm] WHERE `id`='{$user_id}'");
}
//--Game Show -- //
if(time() > $datauser['tgiannhanqua'] + 3600 * 24){
	echo '<div class="list1"><img src="/images/hopqua.png" alt="Nhận quà"/> <a href="/tangqua/"><b>Bạn nhận được quà tặng từ hệ thống</a></b></div>';
}
$timenhanquatess = time() - $datauser['lastdate'];
if($datauser['lastdate'] > (time() - 300)){
mysql_query("UPDATE `users` SET `online` = `online`+'$timenhanquatess' WHERE `id` = '$user_id'"); 
mysql_query("UPDATE `users` SET `thoigianon` = `thoigianon`+'$timenhanquatess' WHERE `id` = '$user_id'"); 
}
if($datauser['thoigianon'] >= 3600){
	echo '<div class="list1"><img src="/images/hopqua.png" alt="Nhận quà"/> <a href="/tangqua/nhanon.php"><b>Bạn nhận được quà online hàng giờ</b></a></div>';
}
//Mod hien thi ban co trong
$sql='SELECT c.*, x.name AS xname, x.rights AS xrights, o.name AS oname, o.rights AS orights, x.lastdate AS xlvs FROM carodata c LEFT JOIN users x ON c.px = x.id LEFT JOIN users o ON c.po = o.id WHERE `turn` = 0 AND `po` = 0 AND `winner`=0 ORDER BY c.id DESC LIMIT 10';
$result=mysql_query($sql);
if(mysql_numrows($result)>0){
echo '';
$a=0;
while($a<mysql_numrows($result)){
echo '';
if (time()-mysql_result($result,$a,"xlvs")>300){echo '';}
else {echo '';}
echo '<div class="list1"><img src="/images/new.gif"> <a href="/gamemini/caroonline/?id='.mysql_result($result,$a,'id').'"><b>Đang có một bàn cờ trống chờ bạn tham gia</b></a> ';
echo '</div>';
$a++;
}
}
$sql='SELECT c.*, x.name AS xname, x.rights AS xrights, o.name AS oname, o.rights AS orights, x.lastdate AS xlvs FROM carodata c LEFT JOIN users x ON c.px=x.id LEFT JOIN users o ON c.po=o.id WHERE `turn` = 0 AND `po` = '.$datauser['id'].' AND `winner`=0 ORDER BY c.id DESC LIMIT 10';
$result=mysql_query($sql);
if(mysql_numrows($result)>0){
$a=0;
while($a<mysql_numrows($result)){
echo '<div class="list1">';
if (time()-mysql_result($result,$a,"xlvs")>300){echo '<img src="/images/new.gif"> ';}
else {echo '<img src="/images/new.gif"> ';}
echo '
<a href="/gamemini/caroonline/?id='.mysql_result($result,$a,'id').'"><b>Bạn đang có một lời thách đấu đánh caro bởi <span style="color: red">'.mysql_result($result,$a,"xname").'</span>, vào tiếp chiến</b></a>';
echo '</div>';
$a++;
}
}
//hien thi thong bao ban co cua bạn
$sql='SELECT c.*, x.name AS xname, x.rights AS xrights, o.name AS oname, o.rights AS orights FROM carodata c LEFT JOIN users x ON c.px = x.id LEFT JOIN users o ON c.po = o.id WHERE `turn` = '.$datauser['id'].' AND `winner`=0 ORDER BY c.id DESC LIMIT 10';
$result=mysql_query($sql);
if(mysql_numrows($result)>0){
$a=0;
while($a<mysql_numrows($result)){
if(mysql_result($result,$a,'px')==$datauser['id']){$o='o';} elseif(mysql_result($result,$a,'po')==$datauser['id']){$o='x';}
if(((time()-mysql_result($result,$a,'lastturn'))/60)>mysql_result($result,$a,'waittime')){$sp1='<div class="list1">';$sp2='</div>';}
echo '<div class="list1">';
echo $sp1.'<img src="/images/new.gif"> <a href="/gamemini/caroonline/?id='.mysql_result($result,$a,'id').'"><b>Hãy vào mà đánh caro lượt của bạn đi kìa, đối thủ đang chờ</b></a>'.$sp2;
echo '</div>';
$a++;
}
}
// mod phuc hoi suc luc dao vang
$dv = mysql_fetch_array(mysql_query("SELECT * FROM `daovang` WHERE `user_id`='{$user_id}'"));
if($dv['doben'] <= 0){
if($dv['time'] == 0){
	mysql_query("UPDATE `daovang` SET `time`='".time()."' WHERE `user_id`= $user_id ");
}else{
	if(($dv['time'] + 28800) <= time()){
		mysql_query("UPDATE `daovang` SET `doben`='100', `time`='0' WHERE `user_id`='{$user_id}'");
	}
}
}
$tong_kiemduyet = mysql_result(mysql_query("SELECT COUNT(*) FROM `community_baiviet` WHERE `kiem_duyet` = '0' AND `xoa` = '0'"), 0);
if($datauser[rights] >= 6){
if($tong_kiemduyet > 0){
	echo '<div class="list5"><a href="http://choionline.cf/community/kiem_duyet.php">Đang có <b style="color: red">'.$tong_kiemduyet.'</b> bài viết cần được kiểm duyệt ra trang chủ</a></div>';
}
}
}