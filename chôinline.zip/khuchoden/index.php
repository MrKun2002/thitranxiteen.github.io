<?php

define('_IN_JOHNCMS', 1);
$textl = ' Khu Chợ Đen ChoiOnline ';
$headmod = 'nick';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

echo '<div class="main"><div class="phdr"><b>Khu Chợ Đen ChoiOnline</b> </div>';
echo 'Khu chợ đen chuyên mua bán, rao vặt đang trong thời gian xây dựng và hoàn thiện<br>

</div>';




echo'</div>';

echo'</div>';




require_once ("../incfiles/end.php");
?>
