<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Kho đồ của tôi!';
require('../incfiles/head.php');
include('function.php');
if($user_id){
if(isset($_GET['sell_ok'])){
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bán đồ thành công</div>';
}
$sql_shop_do = "SELECT * FROM `khodo` WHERE `name` = 5 AND `loaisp` = 'da' AND `id_user` = '{$user_id}'";
$dem_do = mysql_num_rows(mysql_query($sql_shop_do));
if(isset($_GET['id'])){

$int=intval($_GET['id']);
$kiemtrado = mysql_fetch_array(mysql_query("SELECT * FROM `khodo` WHERE `id_user` = '".$datauser["id"]."' AND `id` = '".$int."'"));
if($kiemtrado['id'] == $int){
$post = mysql_fetch_array(mysql_query("select * from `khodo` WHERE `id`= '$int' LIMIT 1"));
$tien = $post['giaban'];
$tienm = $post['giamua'];
$loaisp = $post['loaisp'];
$name = $post['name'];
$sucmanh = $post['sucmanh'];
$thoigian = $post['time'];
if(isset($_GET['hoiban'])){
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn có muốn bán đồ này không <a href="/ruong/?id='.$_GET[id].'&sell"><b>Có</b></a> | <a href="/ruong/?id='.$_GET[id].'"><b>Không</b></a>!
	
	</div>';
}
if(isset($_GET['sell']) && $loaisp != 'da')
{
$kt1 = mysql_fetch_array(mysql_query("select * from `users` WHERE `id`= '$user_id' LIMIT 1"));
if($kt1[$loaisp] != $name){
mysql_query("UPDATE `users` SET `balans` = `balans` + $tien WHERE `id` = $user_id LIMIT 1");
$q="UPDATE `users` SET `balans` = `balans` + $tien WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./shop/khodo.php','".date('d-m-Y  h:i:s A')."')");
mysql_query("DELETE FROM `khodo` WHERE `id` = $_GET[id] ");
	header('Location: ?sell_ok');
}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đang mặc đồ này mà không thể bán!</div>';

}
}elseif($loaisp == 'da'){

if($kt1[$loaisp] != $name){
mysql_query("UPDATE `users` SET `luong` = `luong` + $tien WHERE `id` = $user_id LIMIT 1");
mysql_query("DELETE FROM `khodo` WHERE `id` = $_GET[id] ");
	header('Location: ?sell_ok');
}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đang mặc đồ này mà không thể bán!</div>';

}
}
if(isset($_GET['mac']) && $kiemtrado['id'] == $int && $loaisp != 'da')
{
$kt1 = mysql_fetch_array(mysql_query("select * from `users` WHERE `id`= '$user_id' LIMIT 1"));
if($kt1[$loaisp] == "") { 
mysql_query("UPDATE `users` SET `$loaisp` = $name  WHERE `id` = $user_id LIMIT 1");
mysql_query("UPDATE `users` SET `luutrusm` = `luutrusm` + $sucmanh  WHERE `id` = $user_id LIMIT 1");
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Mặc đồ thành công</div>';
} else{
	$timkiemdo = mysql_fetch_array(mysql_query("SELECT * FROM `khodo` WHERE `id_user` = '".$datauser["id"]."' AND `loaisp` = '".$loaisp."' AND `name` = '".$datauser[$loaisp]."' LIMIT 1"));
	if($datauser['luutrusm'] >= $timkiemdo['sucmanh']){
		mysql_query("UPDATE `users` SET `luutrusm` = `luutrusm` - '".$timkiemdo["sucmanh"]."'  WHERE `id` = $user_id LIMIT 1");
		mysql_query("UPDATE `users` SET `$loaisp` = $name  WHERE `id` = $user_id LIMIT 1");
		mysql_query("UPDATE `users` SET `luutrusm` = `luutrusm` + $sucmanh  WHERE `id` = $user_id LIMIT 1");
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Mặc đồ thành công</div>';
		
	}else{
		mysql_query("UPDATE `users` SET `luutrusm` = '0'  WHERE `id` = $user_id LIMIT 1");
		mysql_query("UPDATE `users` SET `$loaisp` = $name  WHERE `id` = $user_id LIMIT 1");
		mysql_query("UPDATE `users` SET `luutrusm` = `luutrusm` + $sucmanh  WHERE `id` = $user_id LIMIT 1");
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Mặc đồ thành công</div>';
	}
}
}
if($post['loaisp'] != 'da' && $post['loaisp'] != 'vatpham'){
	$kiemtradomac = mysql_fetch_array(mysql_query("SELECT `$loaisp` as loaisp_back from `users` where `id` = $user_id"));
}
if(isset($_GET['thao']) && $kiemtrado['id'] == $int && $loaisp != 'da' && $kiemtradomac[loaisp_back] == $name)
{
if($datauser[luutrusm] >= $post[sucmanh]){
	mysql_query("UPDATE `users` SET `$loaisp` = ''  WHERE `id` = $user_id LIMIT 1");
	mysql_query("UPDATE `users` SET `luutrusm` = `luutrusm` - $sucmanh  WHERE `id` = $user_id LIMIT 1");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Tháo đồ thành công</div>';
}
else{
	mysql_query("UPDATE `users` SET `$loaisp` = ''  WHERE `id` = $user_id LIMIT 1");
	mysql_query("UPDATE `users` SET `luutrusm` = '0'  WHERE `id` = $user_id LIMIT 1");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Tháo đồ thành công</div>';
}
}
if(isset($_GET['nangcap']) && $kiemtrado['id'] == $int && $loaisp != 'da' && $kiemtradomac[loaisp_back] != $name)
{
if(($datauser[balans] > $tienm && $post[sucmanh]  <= 5000) || ($dem_do > 0 && $datauser[balans] > $tienm && $post[sucmanh]  <= 10000)) { 
mysql_query("UPDATE `khodo` SET `sucmanh` = `sucmanh` +  $sucmanh  WHERE `id` = $_GET[id] LIMIT 1");
mysql_query("UPDATE `khodo` SET `giamua` = `giamua` +  $tienm  WHERE `id` = $_GET[id] LIMIT 1");
mysql_query("UPDATE `users` SET `balans` = `balans`- ($tienm+100) WHERE `id` = $user_id LIMIT 1");
if($post[sucmanh] > 5000){
mysql_query("DELETE FROM `khodo` WHERE `name` = 5 AND `loaisp` = 'da' AND `id_user` = '{$user_id}' LIMIT 1");
}
$q="UPDATE `users` SET `balans` = `balans`- ($tienm+100) WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./shop/khodo.php','".date('d-m-Y  h:i:s A')."')");
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Nâng cấp đồ thành công! Bạn bị trừ thêm 100 Xu tiền bồi dưỡng cho nhân vật</div>';
} else if($datauser[balans] < $tienm){
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Xu của bạn còn quá ít để nâng cấp. Bạn có thể kiếm xu bằng cách vào <a href="/nongtrai/">Nông trại</a> trông cây!</div>';
}
}
if(isset($_GET['chuyenhoa']) && $kiemtrado['id'] == $int && $loaisp != 'da' && $kiemtradomac[loaisp_back] != $name)
{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">';
	echo save_do($kiemtrado);
	echo '</div>';
}
// Hien thi thong tin do
if($kiemtrado['id'] == $int && $post['loaisp'] != 'vatpham' && $post['loaisp'] != 'da'){
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
echo "<div class='main-xmenu'><div class='danhmuc'><b>Kho đồ dùng</b></div>";
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" />
</td><td width="auto" valign="top">';
if($loaisp != 'da'){
echo ' Giá tiền: '.$post['giamua'].' Xu<br/>';
echo ' Tăng: '.$post['sucmanh'].' SM<br/>';
echo ' Giá tiền bán lại: '.$post['giaban'].' Xu
</td></tr></tbody></table></div>';
}else{
$thongtinda = mysql_fetch_array(mysql_query("SELECT * FROM `shop` WHERE `name` = '".$post["name"]."' AND `loaisp` = '".$loaisp."'"));
echo ' Giá: '.$post['giamua'].' Lượng<br/>';
echo ' '.$thongtinda['thongtin'].'<br/>';
echo ' Giá bán: '.$post['giaban'].' Lượng
</td></tr></tbody></table></div>';
}

}
// Mod do can cau //
else{
	
	echo "<div class='main-xmenu'><div class='danhmuc'><b>Kho đồ dùng</b></div>";
	echo '<div class="menu list-top">
	<table cellpadding="0" cellspacing="0" width="100%">
	<tbody><tr><td width="50">
	<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" />
	</td><td width="auto">';
	$tinhthoigian = $post['time'] - time();
	$tinhgio = $tinhthoigian/3600;
	$tinhgiotron = (int)$tinhgio;
	if($post['name'] == 16268){
		echo 'Tên: <b>Cần câu làm bằng tre</b>';
		echo '<br/>- Cần được một cậu bé ADMIN :D nghèo làm nên, chỉ có thể dùng câu <b>Cá rô</b> thôi!';
	}
	if($post['name'] == 16269){
		echo 'Tên: <b>Cần câu làm bằng sắt</b>';
		echo '<br/>- Cần được một anh gia công lò rèn làm nên, và làm riêng biệt để câu <b>Cá lòng thong</b> thôi!';
	}
	if($post['name'] == 16270){
		echo 'Tên: <b>Cần câu cá hoàng gia</b>';
		echo '<br/>- Cần được một chính vua thời napoleon đính thân làm, và làm riêng biệt để câu <b>Cá mập</b>(Ông này chắc không bình thường)!';
	}
	if($tinhgiotron >= 0){
	echo '<br/>Thời gian còn lại: '.$tinhgiotron.' Tiếng<br/>';
	}else{
		echo '<br/>Cần hỏng hết rồi còn đâu, không câu được nữa bán đi rồi mua cần mới nhé<br/>';
	}
	echo ' Giá tiền: '.$post['giamua'].' Xu<br/>';
	echo ' Giá tiền bán lại: '.$post['giaban'].' Xu
	
	</td></tr></tbody></table></div>';
	
}
// ket thuc //
if($loaisp != 'da' && $loaisp != 'vatpham'){
echo '<div class="menu list-top">';
$kt = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `id` = '$user_id' AND `$loaisp` = '".$post['name']."'"),0);
if($kt == 0) { 
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
echo '<a href="?id='.$post['id'].'&amp;hoiban">Bán lại</a> | ';
}else{
	echo '<a href="?id='.$post['id'].'&amp;hoiban">Bán cần câu</a> | ';
}
}
if($kt == 0) { 
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
echo '<a href="?id='.$post['id'].'&amp;mac">Mặc vào</a>';
}else{
echo '<a href="?id='.$post['id'].'&amp;mac">Đeo cần câu</a>';
}
}else{
echo '<a href="?id='.$post['id'].'&amp;thao">Tháo ra</a>';
}
if(($kt == 0 && $post[sucmanh]  <= 5000) || ($dem_do > 0 && $kt == 0 && $post[sucmanh]  <= 10000)) { 
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
echo ' | <a href="?id='.$post['id'].'&amp;nangcap">Nâng cấp ('.$post['giamua'].' Xu )</a>';
}
}else echo ' | <span style="color: red"><b>FULL Nâng Cấp</b></span>';
}
if($kt == 0){
	echo ' | <a href="?id='.$post['id'].'&amp;chuyenhoa">Chuyển hóa SM (150.000 Xu + 1 đá CHSM )</a>';
}
//ket thuc thong tin do
}else{
	echo '<div class="list1">Bạn làm gì có đồ này hoặc đồ này không được phép xem thông tin!</div>';
}
}else{
	echo '<div class="list1">Bạn làm gì có đồ này!</div>';
}}else{
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `id_user` = '$user_id'"),0);
echo "<div class='main-xmenu'><div class='danhmuc'><b>Kho đồ dùng</b></div>";
if($k==0){
echo "<div class='menu list-top'>Chưa Có Sản phẩm nào</div>";
}
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` != ''"), 0);

$res = mysql_query("select * from `khodo` WHERE `id_user` = '$user_id' AND `loaisp` != '' LIMIT $start, $kmess;");
echo '<div class="menu">Bạn đang có '.$tong.' món đồ !</div>';
echo '<div class="menu">Danh sách đồ trên người: <br/>';
$thongtincacdo = danhsachdo($datado,$user_id);
if(!empty($thongtincacdo)){
	foreach($thongtincacdo as $thongtindo => $itemdo){
		if($thongtindo == 'ao'){
			$do = 'Áo';
		}elseif($thongtindo == 'toc'){
			$do = 'Tóc';
		}elseif($thongtindo == 'quan'){
			$do = 'Quần';
		}elseif($thongtindo == 'non'){
			$do = 'Nón';
		}elseif($thongtindo == 'mat'){
			$do = 'Mắt';
		}elseif($thongtindo == 'matna'){
			$do = 'Mặt Nạ';
		}elseif($thongtindo == 'canh'){
			$do = 'Cánh';
		}elseif($thongtindo == 'thucung'){
			$do = 'Thú Cưng';
		}elseif($thongtindo == 'docamtay'){
			$do = 'Đồ cầm tay';
		}elseif($thongtindo == 'kinh'){
			$do = 'Kính';
		}elseif($thongtindo == 'haoquang'){
			$do = 'Hào Quang';
		}
		echo '<b>'.$do.'</b> : '.$itemdo['sucmanh'].' Sức mạnh [<a href="/ruong/?id='.$itemdo['id'].'"> <b>Xem</b> </a>]<br/>';
	}
}
echo '</div>';
while ($post = mysql_fetch_array($res)){
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
$sm= 'Tăng: '.$post['sucmanh'].' SM';
$gia = 'Giá bán: '.$post['giaban'].' Xu';
$kiemtrado = mysql_fetch_array(mysql_query("SELECT * FROM `shop` WHERE `name` = '".$post["name"]."' AND `loaisp` = '".$post["loaisp"]."'"));
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != "" && $kiemtrado['tenvatpham'] == ""){
echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}
if($kiemtrado['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$kiemtrado['tenvatpham'].'</span> ]</b></br>';
}
	if($post['loaisp'] != 'da' && $post['loaisp'] != 'vatpham'){
	echo '
	'.$sm.'<br/>
	'.$gia.'<br/>
	<b>[ <a href="/ruong/?id='.$post['id'].'">Thông Tin</a> ]</b><br/>
	</td></tr></tbody></table>
	</div>';
	}elseif($post['loaisp'] == 'da'){
	$thongtinda = mysql_fetch_array(mysql_query("SELECT * FROM `shop` WHERE `name` = '".$post["name"]."' AND `loaisp` = '".$post["loaisp"]."'"));
	echo ' Giá: '.$post['giamua'].' Lượng<br/>';
	echo ' '.$thongtinda['thongtin'].'<br/>';
	echo ' Giá bán: '.$post['giaban'].' Lượng<br/>
	<b>[ <a href="/ruong/?id='.$post['id'].'&sell">Bán</a> ]</b><br/>
	</td></tr></tbody></table></div>';
	}elseif($post['loaisp'] == 'vatpham'){
	echo ' '.$post['thongtin'].'<br/>';
	echo '<b>[ <a href="/ruong/?id='.$post['id'].'&hoiban">Bán</a> ]</b><br/></td></tr></tbody></table></div>';
	}
}else{
	$gia = 'Giá bán: '.$post['giaban'].' Xu';
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td>';

echo '<td width="auto" valign="top">';
if($post['name'] == 16268){
		echo 'Tên: <b>Cần câu làm bằng tre</b>';
		echo '<br/>- Cần được một cậu bé ADMIN :D nghèo làm nên, chỉ có thể dùng câu <b>Cá rô</b> thôi!';
	}
	if($post['name'] == 16269){
		echo 'Tên: <b>Cần câu làm bằng sắt</b>';
		echo '<br/>- Cần được một anh gia công lò rèn làm nên, và làm riêng biệt để câu <b>Cá lòng thong</b> thôi!';
	}
	if($post['name'] == 16270){
		echo 'Tên: <b>Cần câu cá hoàng gia</b>';
		echo '<br/>- Cần được một chính vua thời napoleon đính thân làm, và làm riêng biệt để câu <b>Cá mập</b>(Ông này chắc không bình thường)!';
	}
echo '
<br/>'.$gia.'<br/>
<b>[<a href="/ruong/?id='.$post['id'].'">Thông Tin</a>]</b><br/>
</td></tr></tbody></table>
</div>';
}
}
}
if ($tong > $kmess){
echo '<div class="topmenu">' . functions::display_pagination('/ruong/?', $start, $tong, $kmess) . '</div>';
}
echo "<div class='menu list-top'>";
if(isset($_GET['id']))
echo "&laquo; <a href='/ruong/'>Kho đồ</a>";

else
echo "&laquo; <a href='/shop/'>Shop</a>";
echo "</div></div>";
}else{
echo 'Bạn cần đăng nhập để sử dụng chức năng này';
}
require('../incfiles/end.php');
?>
