<?php
define('_IN_JOHNCMS', 1);

require_once('../incfiles/core.php');
$textl = 'Cửa hàng';
require('../incfiles/head.php');
if($user_id){
if(isset($_GET['buy_ok']))msg('Mua!');
if(isset($_GET['buy_no']))msg("Không đủ tiền!");
if(isset($_GET['id'])){
include 'shop_info.php';
}else{
switch($act){
case 1:
include 'shop_nu.php';
break;
case 2:
include 'shop_nam.php';
break;
default:
include 'shop_index.php';
}
}

echo "<div class='menu list-top'>";
if(isset($_GET['id']))
echo "&laquo; <a href='/shop/'>Cửa hàng</a> | <a href='/ruong/'>Vào Kho Đồ</a> »";
echo "</div></div>";
}else{
msg('Vui lòng đăng nhập!');
}
if($user_id) {
// Mod online trong shop //
mysql_query("UPDATE `users` SET `can-cau` = '5' WHERE `id` = '".$datauser['id']."' LIMIT 1");
// ket thuc
require('menu.php');
}
require('../incfiles/end.php');
?>