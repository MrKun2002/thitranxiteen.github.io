<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Cửa hàng';
require('../incfiles/head.php');
if($user_id){
switch($act){
default:
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop` WHERE  `loaisp` ='non'"), 0);
$res = mysql_query("SELECT * FROM `shop` WHERE  `loaisp` ='non' ORDER BY `id` DESC LIMIT $start, $kmess");
echo "<div class='main-xmenu'><div class='danhmuc'><b>Cửa hàng nón</b></div>";
echo '<table width="100%"><tr><td width="50%"><a href="?act=1"><center class="list3">SHOP NỮ</center></a></td><td width="50%"><a href="?act=2"><center class="list3">SHOP NAM</center></a></td></tr>
</table>';
echo '<div class="menu">Hệ thống cập nhật '.$tong.' món đồ !</div>';
while ($post = mysql_fetch_array($res)){
$sm= 'Tăng: '.$post['sucmanh'].' SM';
$gia = 'Giá tiền: '.$post['giamua'].' Xu';
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}
echo '
Tăng: '.$post['sucmanh'].' SM<br/>
Giá tiền: '.$post['giamua'].' Xu<br/>
Giá bán: '.$post['giaban'].' Xu<br/>
<b>[ <a href="/shop/muasam/?id='.$post['id'].'">Mua</a> ]</b>
</td></tr></tbody></table>
</div>';
}
if ($tong > $kmess){ //Phân Trang
echo '<div class="trang">' . functions::display_pagination('non.html?', $start, $tong, $kmess) . '</div>';
}
echo "<div class='menu list-top'>";
if(isset($_GET['id']))
echo "&laquo; <a href='non.html'>Cửa hàng</a>";
echo "</div></div>";
break;
case 1:
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop` WHERE  `loaisp` ='non' AND `sex` != 'nam'"), 0);
$res = mysql_query("SELECT * FROM `shop` WHERE  `loaisp` ='non' AND `sex` != 'nam' ORDER BY `id` DESC LIMIT $start, $kmess");
echo "<div class='main-xmenu'><div class='danhmuc'><b>Cửa hàng nón</b></div>";
echo '<table width="100%"><tr><td width="50%"><center>SHOP NỮ</center></td><td width="50%"><a href="?act=2"><center class="list3">SHOP NAM</center></a></td></tr>
</table>';
echo '<div class="menu">Hệ thống cập nhật '.$tong.' món đồ !</div>';
while ($post = mysql_fetch_array($res)){
$sm= 'Tăng: '.$post['sucmanh'].' SM';
$gia = 'Giá tiền: '.$post['giamua'].' Xu';
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}
echo '
Tăng: '.$post['sucmanh'].' SM<br/>
Giá tiền: '.$post['giamua'].' Xu<br/>
Giá bán: '.$post['giaban'].' Xu<br/>
<b>[ <a href="/shop/muasam/?id='.$post['id'].'">Mua</a> ]</b>
</td></tr></tbody></table>
</div>';
}
if ($tong > $kmess){ //Phân Trang
echo '<div class="trang">' . functions::display_pagination('non.html?act=1&', $start, $tong, $kmess) . '</div>';
}
echo "<div class='menu list-top'>";
if(isset($_GET['id']))
echo "&laquo; <a href='non.html'>Cửa hàng</a>";
echo "</div></div>";
break;
case 2:
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop` WHERE  `loaisp` ='non' AND `sex` != 'nu'"), 0);
$res = mysql_query("SELECT * FROM `shop` WHERE  `loaisp` ='non' AND `sex` != 'nu' ORDER BY `id` DESC LIMIT $start, $kmess");
echo "<div class='main-xmenu'><div class='danhmuc'><b>Cửa hàng nón</b></div>";
echo '<table width="100%"><tr><td width="50%"><a href="?act=1"><center class="list3">SHOP NỮ</center></a></td><td width="50%"><center>SHOP NAM</center></td></tr>
</table>';
echo '<div class="menu">Hệ thống cập nhật '.$tong.' món đồ !</div>';
while ($post = mysql_fetch_array($res)){
$sm= 'Tăng: '.$post['sucmanh'].' SM';
$gia = 'Giá tiền: '.$post['giamua'].' Xu';
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}
echo '
Tăng: '.$post['sucmanh'].' SM<br/>
Giá tiền: '.$post['giamua'].' Xu<br/>
Giá bán: '.$post['giaban'].' Xu<br/>
<b>[ <a href="/shop/muasam/?id='.$post['id'].'">Mua</a> ]</b>
</td></tr></tbody></table>
</div>';
}
if ($tong > $kmess){ //Phân Trang
echo '<div class="trang">' . functions::display_pagination('non.html?act=2&', $start, $tong, $kmess) . '</div>';
}
echo "<div class='menu list-top'>";
if(isset($_GET['id']))
echo "&laquo; <a href='non.html'>Cửa hàng</a>";
echo "</div></div>";
break;
}
}else{
msg('Vui lòng đăng nhập!');
}
if($user_id) {
require('menu.php');
}
require('../incfiles/end.php');
?>