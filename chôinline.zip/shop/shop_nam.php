 <?php
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop`"), 0);
// Mod online trong shop //
mysql_query("UPDATE `users` SET `can-cau` = '5' WHERE `id` = '".$datauser['id']."' LIMIT 1");
// ket thuc
$res = mysql_query("SELECT * FROM `shop` WHERE `loaisp` != 'da' AND `sex` != 'nu' ORDER BY `id` DESC LIMIT 6");
echo "<div class='main-xmenu'><div class='danhmuc'><b>Đồ Mới Nhất</b></div>";
echo '<table width="100%"><tr><td width="50%"><a href="?act=1"><center class="list3">SHOP NỮ</center></a></td><td width="50%"><center>SHOP NAM</center></td></tr>
</table>';
echo '<div class="menu">Cửa hàng đang có '.$tong.' món đồ !</div>';
while ($post = mysql_fetch_array($res)){
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}
echo '
Tăng: '.$post['sucmanh'].' SM<br/>
Giá tiền: '.$post['giamua'].' Xu<br/>
Giá bán: '.$post['giaban'].' Xu<br/>
<b>[ <a href="/shop/?id='.$post['id'].'">Mua</a> ]</b>
</td></tr></tbody></table>
</div>';
}
?>
