<?php
define('_IN_JOHNCMS', 1);

require_once('../incfiles/core.php');
$textl = 'Thêm tiền';
require('../incfiles/head.php');

if($datauser['rights'] >= 9) : ?>
	<?php if(isset($_GET['id'])) : ?>
		<?php
			$id = $_GET['id'];
			$sql = "SELECT * FROM `users` WHERE `id` = '{$id}'";
			$query = mysql_query($sql);
			$dulieu = mysql_fetch_assoc($query);
		?>
		<div class="phdr">Xử Lý Tiền Thành Viên</div>
		<div class="list4">
		<?php if(isset($_POST['submit'])) : ?>
			<?php
				$sotien = $_POST['sotien'];
				$sql = "UPDATE `users` SET `balans` = `balans` + '{$sotien}' WHERE `id` = '{$id}'";
				if(mysql_query($sql) == TRUE){
					
					?>
						Xử lý tiền thành công
					<?php
					
				}else{
					
					?>
						Xử lý tiền không được
					<?php
					
				}
			?>
			
		<?php else : ?>
		Bạn muốn cộng tiền cho thành viên <b><?php echo $dulieu['name']; ?></b><br/>
		<form method="post">
			<input type="sotien" name="sotien" style="width: 100px; height: 20px;"/>
			<input type="submit" name="submit" value="Cộng Tiền"/>
		</form>
		
		<?php endif; ?>
	<?php endif; ?>
	</div>
<?php
endif;
require('../incfiles/end.php');
?>