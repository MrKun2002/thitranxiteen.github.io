<?php
define('_IN_JOHNCMS', 1);

require_once('../incfiles/core.php');
echo '<div class="main-xmenu">
<div class="danhmuc">Danh Sách Đồ</div>
<div class="menu list-top">
<img src="/iconvip/accept.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/da.html"><b>Vật Phẩm</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/toc.html"><b>Mua Tóc</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/ao.html"><b>Mua Áo</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/quan.html"><b>Mua Quần</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/non.html"><b>Mua Nón</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/kinh.html"><b>Mua Kính</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/mat.html"><b>Mua Mắt</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/matna.html"><b>Mua Mặt Nạ</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/haoquang.html"><b>Mua Hào Quang</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/canh.html"><b>Mua Cánh</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/thucung.html"><b>Mua Thú Cứng</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/docamtay.html"><b>Mua Đồ Cầm Tay</b></a></div></div>
';
?>