 <?php
$int=intval($_GET['id']);
$sql=mysql_query("SELECT `id` FROM `shop` WHERE `id`='$int' ");
$row=mysql_fetch_assoc($sql);
// Mod online trong shop //
mysql_query("UPDATE `users` SET `can-cau` = '5' WHERE `id` = '".$datauser['id']."' LIMIT 1");
// ket thuc
$post = mysql_fetch_array(mysql_query("select * from `shop` WHERE  `id` = '$int'  LIMIT 1"));


$kt = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `id_user` = '$user_id' AND `name` = '".$post['name']."' AND `loaisp` = '".$post['loaisp']."'"),0);
if($post['gialuong'] == '0'){
$tien = $post['giamua'];
if($datauser['balans'] >= $tien && $kt == 0) { 
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `giamua`, `giaban`, `sucmanh`) VALUES  ('".$post['name']."', '".$post['loaisp']."', '".$user_id."', '".$post['giamua']."','".$post['giaban']."','".$post['sucmanh']."') ");
}else{
	$timedo = time()+86400;
	mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `giamua`, `giaban`, `time`) VALUES  ('".$post['name']."', '".$post['loaisp']."', '".$user_id."', '".$post['giamua']."','".$post['giaban']."','".$timedo."') ");
	}
mysql_query("UPDATE `users` SET `balans` = `balans`- $tien WHERE `id` = $user_id LIMIT 1");
$q="UPDATE `users` SET `balans` = `balans`- $tien WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./shop/shop_info.php','".date('d-m-Y  h:i:s A')."')");
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Mua Hàng Thành công</b></div>';
echo '<div class="menu list-top"><img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" /></div>';
echo '<div class="menu list-top"> Giá tiền: '.$post['giamua'].' Xu</div>';
echo '<div class="menu list-top"> Tăng: '.$post['sucmanh'].' SM</div>';
echo '<div class="menu list-top"> Giá tiền bán lại: '.$post['giaban'].' Xu</div>';
}else{
// tinh time cho can cau ca
$tinhtimeconlai = $kt['time']+86400-time();
$tinhtimegio = $tinhtimeconlai/3600;
$tinhtimegion = (int)$tinhtimegio;
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Mua Cần Câu Thành công</b></div>';
echo '<div class="menu list-top"><img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" /></div>';
echo '<div class="menu list-top"> Giá tiền: '.$post['giamua'].' Xu</div>';
echo '<div class="menu list-top"> Thời gian: 24 Giờ</div>';
echo '<div class="menu list-top"> Giá tiền bán lại: '.$post['giaban'].' Xu</div>';
echo '<div class="menu list-top"><b>[<a href="/cauca/cuahang.html">Vào Cửa Hàng Mua Mồi Câu</a>]</b>';
}
}else if($datauser['balans'] < $tien) { 
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Lỗi Mua Hàng Không Thành công</b></div>';
echo '<div class="menu list-top">Tiền của bạn hết rồi, không đủ để mua hàng này !</div>';
} 
else { 
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Lỗi Mua Hàng Không Thành công</b></div>';
echo '<div class="menu list-top">Có rồi mua chi nữa !</div>';
}
}else{
$tien = $post['gialuong'];
if($datauser['luong'] >= $tien) { 
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `giamua`, `giaban`, `sucmanh`) VALUES  ('".$post['name']."', '".$post['loaisp']."', '".$user_id."', '".$post['gialuong']."','".$post['giaban']."','".$post['sucmanh']."') ");
}else{
	$timedo = time()+86400;
	mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `giamua`, `giaban`, `time`) VALUES  ('".$post['name']."', '".$post['loaisp']."', '".$user_id."', '".$post['gialuong']."','".$post['giaban']."','".$timedo."') ");
	}
mysql_query("UPDATE `users` SET `luong` = `luong`- $tien WHERE `id` = $user_id LIMIT 1");
if($post['name'] != 16268 && $post['name'] != 16269 && $post['name'] != 16270){
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Mua Hàng Thành công</b></div>';
echo '<div class="menu list-top"><img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" /></div>';
echo '<div class="menu list-top"> Giá tiền: '.$post['gialuong'].' Lượng</div>';
if($post['loaisp'] != 'da'){
echo '<div class="menu list-top"> Tăng: '.$post['sucmanh'].' SM</div>';
}else{
echo '<div class="menu list-top">'.$post['thongtin'].'</div>';
}
echo '<div class="menu list-top"> Giá tiền bán lại: '.$post['giaban'].' Lượng</div>';
}
}else if($datauser['luong'] < $tien) { 
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Lỗi Mua Hàng Không Thành công</b></div>';
echo '<div class="menu list-top">Lượng trong túi của bạn hết rồi, không đủ để mua hàng này !</div>';
} 

}
?>
