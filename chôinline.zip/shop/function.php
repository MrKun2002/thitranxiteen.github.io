<?php
	function save_do($thongTindo){
		session_start();
		$id = $thongTindo['id'];
		$name = $thongTindo['name'];
		$loaisp = $thongTindo['loaisp'];
		$sucmanh = $thongTindo['sucmanh'];
		$text = 'Thêm vào thành công <a href="/shop/chuyenhoa.php">Vào chỗ chuyển hóa</a>';
		if(($name & $loaisp & $sucmanh) != '' && $sucmanh <= 40000){
			if(empty($_SESSION['sanpham']['id']) || empty($_SESSION['sanpham1']['id'])){
				if(!empty($_SESSION['sanpham']['id'])){
					if($_SESSION['sanpham']['id'] != $id){
						if($_SESSION['sanpham']['loaisp'] == $loaisp){
							$_SESSION['sanpham1']['id'] 		= $id;
							$_SESSION['sanpham1']['name'] 		= $name;
							$_SESSION['sanpham1']['loaisp'] 	= $loaisp;
							$_SESSION['sanpham1']['sucmanh']	= $sucmanh;
						}else{
							$text = 'Không thể chuyển hóa cùng 1 sản phẩm <a href="/shop/chuyenhoa.php">Vào chỗ chuyển hóa</a>';
						}
					}else{
						$text = 'Không cùng chung loại sản phẩm không thể chuyển hóa <a href="/shop/chuyenhoa.php">Vào chỗ chuyển hóa</a>';
					}
				}else{
					$_SESSION['sanpham']['id'] 		= $id;
					$_SESSION['sanpham']['name'] 	= $name;
					$_SESSION['sanpham']['loaisp'] 	= $loaisp;
					$_SESSION['sanpham']['sucmanh'] = $sucmanh;
				}
			}else{
				$text = 'Đã full trong khu vực nâng cấp <a href="/shop/chuyenhoa.php">Vào chỗ chuyển hóa</a>';
			}
		}elseif($sucmanh > 40000){
			$text = 'Lỗi!! đồ mang sức mạnh quá cao không thể chuyển hóa <a href="/shop/chuyenhoa.php">Vào chỗ chuyển hóa</a>';
		}else{
			$text = 'Lỗi!! có vẻ có sự nhầm lẫn nào ở đây <a href="/shop/chuyenhoa.php">Vào chỗ chuyển hóa</a>';
		}
		return $text;
	}
	function chuyenhoa($user){
		session_start();
		$text = "";
		if($user['balans'] >= 150000){
			$sql1 = "UPDATE `khodo` SET `sucmanh` = '".$_SESSION['sanpham1']['sucmanh']."' WHERE `id` = '".$_SESSION['sanpham']['id']."'"; 
			$sql2 = "UPDATE `khodo` SET `sucmanh` = '".$_SESSION['sanpham']['sucmanh']."' WHERE `id` = '".$_SESSION['sanpham1']['id']."'"; 
			$sql3 = "SELECT * FROM `khodo` WHERE `id_user` = '".$user['id']."' AND `loaisp` = 'da' AND `name` = '7'";
			$thongtin = mysql_num_rows(mysql_query($sql3));
			if($thongtin > 0){
				if((mysql_query($sql1) & mysql_query($sql2)) == TRUE){
					$_SESSION['sanpham'] = '';
					$_SESSION['sanpham1'] = '';
					$sql4 = "DELETE FROM `khodo` WHERE `id_user` = '".$user['id']."' AND `name` = 7 AND `loaisp` = 'da' LIMIT 1";
					$sql5 = "UPDATE `users` SET `balans` = `balans`-150000 WHERE `id` = '".$user['id']."'";
					$text = "Chuyển hóa đồ thành công";
					mysql_query($sql4);
					mysql_query($sql5);
					
				}else{
					$text = "Chuyển hóa đồ thất bại.";
				}
			}else{
				$text = "Bạn không đủ đá để sử dụng";
			}
		}else{
			$text = "Bạn không đủ tiền để ép món đồ này";
		}
		return $text;
	}
?>