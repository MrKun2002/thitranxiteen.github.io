<?php
define('_IN_JOHNCMS', 0);
require_once('../incfiles/core.php');
$textl = 'Cửa hàng';
require('../incfiles/head.php');
if(isset($_GET['id'])){
$int = intval($_GET['id']);
if($datauser['rights'] == 9){
$timeval = 111111111111111;
	mysql_query("INSERT INTO `cms_ban_users` SET
                        `user_id` = '" .$int. "',
                        `ban_time` = '" . (time() + $timeval) . "',
                        `ban_while` = '" . time() . "',
                        `ban_type` = '$term',
                        `ban_who` = 'BOT',
                        `ban_reason` = 'Ban V...V Quảng Cáo WAP',
						`wap` = '1'
                    ");
	mysql_query("DELETE FROM `cms_mail` WHERE `user_id` = '" .$int. "'");
	mysql_query("DELETE FROM `cms_users_guestbook` WHERE `user_id` = '" .$int. "'");
	mysql_query("DELETE FROM `guest` WHERE `user_id` = '" .$int. "'");
				echo 'Ban Thành công rồi nhé. Quay lại <a href="quanli-mail.php">Quản Lí</a>';
}
}
require('../incfiles/end.php');
?>
