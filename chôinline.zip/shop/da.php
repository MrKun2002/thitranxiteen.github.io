<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Cửa hàng';
require('../incfiles/head.php');
if($user_id){
// Mod online trong shop //
mysql_query("UPDATE `users` SET `can-cau` = '5' WHERE `id` = '".$datauser['id']."' LIMIT 1");
// ket thuc
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop` WHERE  `loaisp` ='da'"), 0);
$res = mysql_query("SELECT * FROM `shop` WHERE  `loaisp` ='da' ORDER BY `id` DESC LIMIT $start, $kmess");
echo "<div class='main-xmenu'><div class='danhmuc'><b>Cửa hàng vật phẩm</b></div>";
echo '<div class="menu">Hệ thống cập nhật '.$tong.' món đồ !</div>';
while ($post = mysql_fetch_array($res)){
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}
echo '
Giá tiền: '.$post['gialuong'].' Lượng<br/>
- '.$post['thongtin'].'<br/>
<b>[ <a href="/shop/muasam/?id='.$post['id'].'">Mua</a> ]</b>
</td></tr></tbody></table>
</div>';
if ($tong > $kmess){ //Phân Trang
echo '<div class="trang">' . functions::display_pagination('da.html?', $start, $tong, $kmess) . '</div>';
}
}
echo "<div class='menu list-top'>";
if(isset($_GET['id']))
echo "&laquo; <a href='da.html'>Cửa hàng</a>";
echo "</div></div>";
}else{
msg('Vui lòng đăng nhập!');
}
if($user_id) {
require('menu.php');
}
require('../incfiles/end.php');
?>