<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Cửa hàng';
require('../incfiles/head.php');
if($user_id){
// Mod online trong shop //
mysql_query("UPDATE `users` SET `can-cau` = '5' WHERE `id` = '".$datauser['id']."' LIMIT 1");
// ket thuc
if(isset($_GET['buy_ok']))msg('Mua!');
if(isset($_GET['buy_no']))msg("Không đủ tiền mua!");
if(isset($_GET['id'])){
$int=intval($_GET['id']);
$sql=mysql_query("SELECT `id` FROM `shop` WHERE `id`='$int' ");
$row=mysql_fetch_assoc($sql);

$post = mysql_fetch_array(mysql_query("select * from `shop` WHERE  `id` = '$int'  LIMIT 1"));

$tien = $post['giamua'];
$kt = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `id_user` = '$user_id' AND `name` = '".$post['name']."' AND `loaisp` = '".$post['loaisp']."'"),0);

if($datauser['balans'] >= $tien && $kt == 0) { 
mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `giamua`, `giaban`, `sucmanh`) VALUES  ('".$post['name']."', '".$post['loaisp']."', '".$user_id."', '".$post['giamua']."','".$post['giaban']."','".$post['sucmanh']."') ");
mysql_query("UPDATE `users` SET `balans` = `balans`- $tien WHERE `id` = $user_id LIMIT 1");
$q="UPDATE `users` SET `balans` = `balans`- $tien WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./shop/kinh.php','".date('d-m-Y  h:i:s A')."')");
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Mua Hàng Thành công</b></div>';
echo '<div class="menu list-top"><img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" /></div>';
echo '<div class="menu list-top"> Giá tiền: '.$post['giamua'].' Xu</div>';
echo '<div class="menu list-top"> Tăng: '.$post['sucmanh'].' SM</div>';
echo '<div class="menu list-top"> Giá tiền bán lại: '.$post['giaban'].' Xu</div>';
} else { 
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Lỗi Mua Hàng Không Thành công</b></div>';
echo '<div class="menu list-top">Có rồi mua chi nữa !</div>';
}
}else{
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop` WHERE  `loaisp` ='kinh'"), 0);
$res = mysql_query("SELECT * FROM `shop` WHERE  `loaisp` ='kinh' ORDER BY `id` DESC LIMIT $start, $kmess");
echo "<div class='main-xmenu'><div class='danhmuc'><b>Cửa hàng Kính</b></div>";
echo '<div class="menu">Hệ thống cập nhật '.$tong.' món đồ !</div>';
while ($post = mysql_fetch_array($res)){
$sm= 'Tăng: '.$post['sucmanh'].' SM';
$gia = 'Giá tiền: '.$post['giamua'].' Xu';
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}
echo '
Tăng: '.$post['sucmanh'].' SM<br/>
Giá tiền: '.$post['giamua'].' Xu<br/>
Giá bán: '.$post['giaban'].' Xu<br/>
<b>[ <a href="/shop/muasam/?id='.$post['id'].'">Mua</a> ]</b>
</td></tr></tbody></table>
</div>';
}
if ($tong > $kmess){ //Phân Trang
echo '<div class="trang">' . functions::display_pagination('kinh.html?', $start, $tong, $kmess) . '</div>';
}
}
echo "<div class='menu list-top'>";
if(isset($_GET['id']))
echo "&laquo; <a href='/shop/'>Cửa hàng</a>";
echo "</div></div>";
}else{
msg('Vui lòng đăng nhập!');
}
if($user_id) {
require('menu.php');
}
require('../incfiles/end.php');
?>