<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Danh sách đồ chuyển hóa!';
require('../incfiles/head.php');
include('function.php');
if($user_id){
	if(isset($_GET['ok']) && !empty($_SESSION['sanpham']) && !empty($_SESSION['sanpham1'])){
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">';
		echo chuyenhoa($datauser);
		echo '</div>';
	}else if(isset($_GET['xoa'])){
		if($_GET['xoa'] == 1){
			$_SESSION['sanpham'] = '';
		}else{
			$_SESSION['sanpham1'] = '';
		}
	}
?>
	<div class="phdr">Chuyển hóa đồ</div>
	<?php if(!empty($_SESSION['sanpham'])){ ?>
		<?php
			echo '<div class="menu list-top">
			<table cellpadding="0" cellspacing="0" width="100%">
			<tbody><tr><td width="50">
			<img src="/images/'.$_SESSION['sanpham']['loaisp'].'/'.$_SESSION['sanpham']['name'].'.png" alt="*" />
			</td><td width="auto" valign="top">';
			if($_SESSION['sanpham']['loaisp'] != 'da'){
				echo ' Tăng: '.$_SESSION['sanpham']['sucmanh'].' SM<br/>';
				echo '<a style="color: red" href="?xoa=1">Hủy chuyển hóa đồ này</a>';
				echo '</td></tr></tbody></table></div>';
			}
		?>
	<?php
		}else{
			echo '<div class="menu list-top">Chưa có sản phẩm 1</div>';
		}
		if(!empty($_SESSION['sanpham1'])){ ?>
		<?php
			echo '<div class="menu list-top">
			<table cellpadding="0" cellspacing="0" width="100%">
			<tbody><tr><td width="50">
			<img src="/images/'.$_SESSION['sanpham1']['loaisp'].'/'.$_SESSION['sanpham1']['name'].'.png" alt="*" />
			</td><td width="auto" valign="top">';
			if($_SESSION['sanpham1']['loaisp'] != 'da'){
				echo ' Tăng: '.$_SESSION['sanpham1']['sucmanh'].' SM<br/>';
				echo '<a style="color: red" href="?xoa=2">Hủy chuyển hóa đồ này</a>';
				echo '</td></tr></tbody></table></div>';
			}
		?>
		<?php	}else{
			echo '<div class="menu list-top">Chưa có sản phẩm 2</div>';
		} 
		if(!empty($_SESSION['sanpham1']) && !empty($_SESSION['sanpham'])){
			?>
				<div class="list2">
				<a id="submit" href="?ok">Chuyển hóa đồ</a>
				</div>
			<?php
		}
		?>
		
		<a href="/ruong/">Quay lại kho đồ</a>
<?php
}else{
echo 'Bạn cần đăng nhập để sử dụng chức năng này';
}
require('../incfiles/end.php');
?>
