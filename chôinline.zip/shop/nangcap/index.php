<?php
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
$textl = 'Cửa hàng';
require('../../incfiles/head.php');
if($user_id){
// Mod online trong shop //
mysql_query("UPDATE `users` SET `can-cau` = '5' WHERE `id` = '".$datauser['id']."' LIMIT 1");
// ket thuc
if(isset($_GET['id'])){
$int = intval($_GET['id']);
$timkiemsp = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `id` = '$int'"), 0);
if($timkiemsp >= 1){
$post = mysql_fetch_array(mysql_query("SELECT * FROM `shop_nangcap` WHERE `id` = '$int'"));
echo '<div class="phdr">Nâng Cấp '.$post['tenvatpham'].'</div>';
// Hàm viết tìm đá và tìm đồ trong dương
$timda1 = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `loaisp` = 'da' AND `id_user` = '$user_id' AND `name` = '1'"), 0);
$timda2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `loaisp` = 'da' AND `id_user` = '$user_id' AND `name` = '2'"), 0);
$timda3 = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `loaisp` = 'da' AND `id_user` = '$user_id' AND `name` = '3'"), 0);
$timda4 = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `loaisp` = 'da' AND `id_user` = '$user_id' AND `name` = '4'"), 0);
$kiemtrado = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `loaisp` = '$post[loaisp]' AND `id_user` = '$user_id' AND `name` = '$post[name]'"), 0);
$kiemtradomac = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '$user_id' LIMIT 1"));
if($post[vat_nangcap] != 0){
$timdo = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `loaisp` = '$post[loaisp]' AND `id_user` = '$user_id' AND `name` = '$post[vat_nangcap]'"), 0);
}else{
$timdo = 1;
}
$sanpham = $post[loaisp];
// Hàm code truy xuất database
if(isset($_GET['nangcap'])){
// Hàm nâng cấp không dùng đá hi vọng
if($kiemtradomac[$sanpham] != $post[vat_nangcap]){
if($datauser['balans'] >= $post[tien_nangcap]){
if($timda1 >= $post['da1'] && $timda3 >= $post['da3'] && $timda4 >= $post['da4'] && $kiemtrado == 0 && $timdo == 1){
mysql_query("UPDATE `users` SET `balans` = `balans` - '$post[tien_nangcap]' WHERE `id` = '$user_id'");
$q="UPDATE `users` SET `balans` = `balans` - '$post[tien_nangcap]' WHERE `id` = '$user_id'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./shop/nangcap/index.php','".date('d-m-Y  h:i:s A')."')");
mysql_query("DELETE FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` = 'da' AND `name` = '1' LIMIT $post[da1]");
mysql_query("DELETE FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` = 'da' AND `name` = '3' LIMIT $post[da3]");
mysql_query("DELETE FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` = 'da' AND `name` = '4' LIMIT $post[da4]");
$rand = rand(1,5);
if($post[vat_nangcap] != 0){
	if($rand == 4){
	mysql_query("UPDATE `khodo` SET `name` = '$post[name]', `tenvatpham` = '$post[tenvatpham]', `sucmanh` = '$post[sucmanh]' WHERE `loaisp` = '$post[loaisp]' AND `id_user` = '$user_id' AND `name` = '$post[vat_nangcap]'");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Xin chúc mừng bạn đã ép lên được '.$post[tenvatpham].'!</div>';
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">ÉP đồ thất bại</div>';
	}
}else{
	if($rand == 4){
	mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`) VALUES  ('$post[name]', '$post[loaisp]', '".$user_id."' , '$post[sucmanh]','$post[giaban]', '$post[tenvatpham]') ");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Xin chúc mừng bạn đã ép lên được '.$post[tenvatpham].'!</div>';
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">ÉP đồ thất bại</div>';
	}
}
// Kết thúc hàm
}elseif($kiemtrado == 1){
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã có đồ này rồi không cần phải ép nữa đâu :D</div>';
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Hãy kiểm tra lại bạn thiếu thành phần để có thể ép lên đồ này!</div>';
}
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ tiền để lên đồ này!</div>';
}
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đang mặc đồ cần ép hãy tháo ra để ép nhé!</div>';
}
}
if(isset($_GET['nangcaphv'])){
// Hàm sử dụng đá hi vọng
if($kiemtradomac[$sanpham] != $post[vat_nangcap]){
if($datauser['balans'] >= $post[tien_nangcap]){
if($timda1 >= $post['da1'] && $timda3 >= $post['da3'] && $timda2 >= $post['da2'] && $timda4 >= $post['da4'] && $kiemtrado == 0 && $timdo == 1){
mysql_query("UPDATE `users` SET `balans` = `balans` - '$post[tien_nangcap]' WHERE `id` = '$user_id'");
$q="UPDATE `users` SET `balans` = `balans` - '$post[tien_nangcap]' WHERE `id` = '$user_id'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./shop/nangcap/index.php','".date('d-m-Y  h:i:s A')."')");
mysql_query("DELETE FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` = 'da' AND `name` = '1' LIMIT $post[da1]");
mysql_query("DELETE FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` = 'da' AND `name` = '2' LIMIT $post[da2]");
mysql_query("DELETE FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` = 'da' AND `name` = '3' LIMIT $post[da3]");
mysql_query("DELETE FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` = 'da' AND `name` = '4' LIMIT $post[da4]");
$rand = rand(1,3);
if($post[vat_nangcap] != 0){
	echo 'Kiem tra';
	if($rand == 2){
	mysql_query("UPDATE `khodo` SET `name` = '$post[name]', `tenvatpham` = '$post[tenvatpham]', `sucmanh` = '$post[sucmanh]' WHERE `loaisp` = '$post[loaisp]' AND `id_user` = '$user_id' AND `name` = '$post[vat_nangcap]'");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Xin chúc mừng bạn đã ép lên được '.$post[tenvatpham].'!</div>';
	mysql_query("DELETE FROM `khodo` WHERE `id_user` = '$user_id' AND `loaisp` = 'da' AND `name` = '2' LIMIT $post[da2]");
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">ÉP đồ thất bại</div>';
	}
}else{
	if($rand == 2){
	mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`) VALUES  ('$post[name]', '$post[loaisp]', '".$user_id."' , '$post[sucmanh]','$post[giaban]', '$post[tenvatpham]') ");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Xin chúc mừng bạn đã ép lên được '.$post[tenvatpham].'!</div>';
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">ÉP đồ thất bại</div>';
	}
}
// Kết thúc hàm
}elseif($kiemtrado == 1){
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã có đồ này rồi không cần phải ép nữa đâu :D</div>';
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Hãy kiểm tra lại bạn thiếu thành phần để có thể ép lên đồ này!</div>';
}
// Kết thúc hàm
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ tiền để lên đồ này!</div>';

}
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đang mặc đồ cần ép hãy tháo ra để ép nhé!</div>';
}
}
// Kết thúc hàm
// Viết hàm code xem và nâng cấp vật phẩm
echo '<div class="list1">';
echo '<table><tr><td>
<img src="/images/'.$post[loaisp].'/'.$post[name].'.png"/></td><td>
<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b><br/>
<b>Nâng cấp cần:</b><br/>';
if($post['da1'] >= 1){
echo 'Kim cương xanh: '.$post['da1'].' Viên';
if($timda1 >= $post['da1'] && $post['da1'] >= 1){
	echo '<span style="color: #0A8B33;">(Đã đủ)</span><br>';
}else{
	echo '<span style="color: red;">(Chưa đủ)</span><br/>';
}
}
if($post['da3'] >= 1){
echo 'Ngọc huyền bí: '.$post['da3'].' Viên';
if($timda3 >= $post['da3']){
	echo '<span style="color: #0A8B33;">(Đã đủ)</span><br>';
}else{
	echo '<span style="color: red;">(Chưa đủ)</span><br/>';
}
}
if($post['da4'] >= 1){
echo 'Kim cương tím: '.$post['da4'].' Viên';
if($timda4 >= $post['da4']){
	echo '<span style="color: #0A8B33;">(Đã đủ)</span><br>';
}else{
	echo '<span style="color: red;">(Chưa đủ)</span><br/>';
}
}
if($post['vat_nangcap'] >= 1){
echo 'Cần: '.$post['tenvat_nangcap'].'';
if($timdo == 1){
	echo '<span style="color: #0A8B33;">(Đã đủ)</span><br>';
}else{
	echo '<span style="color: red;">(Chưa đủ)</span><br/>';
}
}
if($post['tien_nangcap'] >= 1){
echo 'Phí nâng cấp: '.$post['tien_nangcap'].' Xu';
if($datauser['balans'] >= $post['tien_nangcap']){
	echo '<span style="color: #0A8B33;">(Đã đủ)</span><br>';
}else{
	echo '<span style="color: red;">(Chưa đủ)</span><br/>';
}
}
if($post['da2'] >= 1){
echo 'Kim cương hi vọng: '.$post['da2'].' Viên <b>+ 25%</b> Tỉ Lệ';
if($timda2 >= $post['da2']){
	echo '<span style="color: #0A8B33;">(Đã đủ)</span><br>';
}else{
	echo '<span style="color: red;">(Chưa đủ)</span><br/>';
}
}
echo '<b>[<a href="'.$int.'&nangcap">Ép Đồ Này</a>] (Xác xuất 25% thành công)</b>';

echo '<br/><b>[<a href="'.$int.'&nangcaphv">Ép Đồ + Kim Cương Hi Vọng</a>] (Tăng thêm +25% thành công)</b>';
echo '</td></tr>
</table>
</div>
';

// kết thúc
}else{
echo '<div class="list1">Hiện chưa có sản phẩm nào để nâng cấp nhé</div>';
}
}

if(isset($_GET['sp'])){
$int = addslashes($_GET['sp']);
$timkiemsp = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = '$int'"), 0);
if($timkiemsp >= 1){
// Code hiển thị đồ gì

if($int == 'toc'){
 $vatpham = 'Tóc';
}
if($int == 'ao'){
  $vatpham = 'Áo';
}
if($int == 'quan'){
  $vatpham = 'Quần';
}
if($int == 'non'){
  $vatpham = 'Nón';
}
if($int == 'kinh'){
  $vatpham = 'Kính';
}
if($int == 'mat'){
  $vatpham = 'Mắt';
}
if($int == 'matna'){
  $vatpham = 'Mặt Nạ';
}
if($int == 'canh'){
  $vatpham = 'Cánh';
}
if($int == 'thucung'){
  $vatpham = 'Thú Cưng';
}
if($int == 'docamtay'){
  $vatpham = 'Đồ Cầm Tay';
}
echo '<div class="phdr">Nâng cấp '.$vatpham.'';
echo '</div><div class="gmenu">';
// Viết code hiển thị đoạn nâng cấp sản phẩm
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = '$int'"), 0);
echo '<div class="list1">Có tổng '.$tong.' '.$vatpham.' nâng cấp có thể nâng cấp</div>';
$res = mysql_query("SELECT * FROM `shop_nangcap` WHERE `loaisp` = '$int' ORDER BY `id` DESC LIMIT $start, $kmess");
while($post = mysql_fetch_array($res)){
$sm= 'Tăng: '.$post['sucmanh'].' SM';
$gia = 'Giá tiền: '.$post['tien_nangcap'].' Xu';
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}

echo '<b>Nâng cấp cần:</b><br/>';
if($post[da1] != 0){
echo 'Kim cương xanh: '.$post['da1'].' viên<br/>';
}
if($post[da3] != 0){
echo 'Ngọc huyền bí: '.$post['da3'].' viên<br/>';
}
if($post[da4] != 0){
echo 'Kim cương tím: '.$post['da4'].' viên<br/>';
}
if($post[tenvat_nangcap] != ""){
echo ''.$post[tenvat_nangcap].'<br/>';
}
echo '<b>[ <a href="/shop/nangcap/nc/'.$post['id'].'">Nâng Cấp Đồ Này</a> ]</b>
</td></tr></tbody></table>
</div>';
}
if ($tong > $kmess){ //Phân Trang
echo '<div class="trang">' . functions::display_pagination('/shop/nangcap/sp/'.$int.'&', $start, $tong, $kmess) . '</div>';
}
// kêt thúc
}else{
echo '<div class="list1">Hiện chưa có sản phẩm nào để nâng cấp nhé</div>';
}
}
if(isset($_GET['shop'])){
echo '
<div class="main-xmenu">
<div class="phdr">Danh Sách Đồ Nâng Cấp Mới Nhất</div>';
$res = mysql_query("SELECT * FROM `shop_nangcap` WHERE `id` ORDER BY `id` DESC LIMIT 5");
while($post = mysql_fetch_array($res)){
$sm= 'Tăng: '.$post['sucmanh'].' SM';
$gia = 'Giá tiền: '.$post['tien_nangcap'].' Xu';
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
if($post['tenvatpham'] != ""){
	echo '<b>[ <span style="color: green">'.$post['tenvatpham'].'</span> ]</b></br>';
}

echo '<b>Nâng cấp cần:</b><br/>';
if($post[da1] != 0){
echo 'Kim cương xanh: '.$post['da1'].' viên<br/>';
}
if($post[da3] != 0){
echo 'Ngọc huyền bí: '.$post['da3'].' viên<br/>';
}
if($post[da4] != 0){
echo 'Kim cương tím: '.$post['da4'].' viên<br/>';
}
if($post[tenvat_nangcap] != ""){
echo ''.$post[tenvat_nangcap].'<br/>';
}
echo '<b>[ <a href="/shop/nangcap/nc/'.$post['id'].'">Nâng Cấp Đồ Này</a> ]</b>
</td></tr></tbody></table>
</div>';
}
}
echo '</div>
<div class="main-xmenu">
<div class="phdr">Thợ Kim Hoàn</div>
<div class="menu list-top">
<img src="/iconvip/accept.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/muasam/da.html"><b>Chợ Mua Đá</b></a></div>
<div class="menu list-top">
<img src="/iconvip/accept.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/new/"><b>Vật Phẩm Nâng Cấp Mới Cập Nhật</b></a></div>
';
$da = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'da'"), 0);
if($da >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/da"><b>Nâng Cấp Đá, Vật Phẩm</b></a></div>
';
}
$ao = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'ao'"), 0);
if($ao >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/ao"><b>Nâng Cấp Áo</b></a></div>
';
}
$quan = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'quan'"), 0);
if($quan >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/quan"><b>Nâng Cấp Quần</b></a></div>
';
}
$toc = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'toc'"), 0);
if($toc >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/toc"><b>Nâng Cấp Tóc</b></a></div>
';
}
$non = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'non'"), 0);
if($non >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/non"><b>Nâng Cấp Nón</b></a></div>
';
}
$kinh = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'kinh'"), 0);
if($kinh >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/kinh"><b>Nâng Cấp Kính</b></a></div>
';
}
$mat = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'mat'"), 0);
if($mat >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/mat"><b>Nâng Cấp Mắt</b></a></div>
';
}
$matna = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'matna'"), 0);
if($matna >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/matna"><b>Nâng Cấp Mặt Nạ</b></a></div>
';
}
$canh = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'canh'"), 0);
if($canh >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/canh"><b>Nâng Cấp Cánh</b></a></div>
';
}
$thucung = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'thucung'"), 0);
if($thucung >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/thucung"><b>Nâng Cấp Thú Cứng</b></a></div>
';
}
$docamtay = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'docamtay'"), 0);
if($docamtay >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/docamtay"><b>Nâng Cấp Đồ Cầm Tay</b></a></div>
';
}
$haoquang = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_nangcap` WHERE `loaisp` = 'haoquang'"), 0);
if($haoquang >= 1){
echo '<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="/shop/nangcap/sp/haoquang"><b>Nâng Cấp Hào Quang</b></a></div>
';
}
echo '</div>';
echo '<div class="list1"><center></center><b></b></div>';
}else{
echo '<div class="list1">Bạn vui lòng đăng nhập để sử dụng chức năng này nhé!</div>';
}
echo '
';
require('../../incfiles/end.php');
?>