<?php
define('_IN_JOHNCMS', 1);

require_once('../incfiles/core.php');
$textl = 'Khu Mua Sắm';
require('../incfiles/head.php');
if($user_id){
echo '<div class="phdr">Khu Mua Sắm</div>';
		if(isset($_GET['manh'])){
		mysql_query("UPDATE `users` SET `giaodien` = '1' WHERE `id` = '".$datauser["id"]."'");
		$q="UPDATE `users` SET `giaodien` = '1' WHERE `id` = '".$datauser["id"]."'";
		mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','/home/forumvie/public_html/shop/index.php','".date('d-m-Y  h:i:s A')."')");
			header('Location: /shop/index.php');
		}
		if(isset($_GET['yeu'])){
			mysql_query("UPDATE `users` SET `giaodien` = '0' WHERE `id` = '".$datauser["id"]."'");
			$q="UPDATE `users` SET `giaodien` = '0' WHERE `id` = '".$datauser["id"]."'";
			mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','/home/forumvie/public_html/shop/index.php','".date('d-m-Y  h:i:s A')."')");
			header('Location: /shop/index.php');
		}
		
		if($datauser['giaodien'] == 0){
		echo '<div class="list1"><b style="color: red;">Giao điện:</b><b> <a href="?manh">Chuyển sang chế độ nét cao</a></b></div>';

		}else{
		echo '<div class="list1"><b style="color: red;">Giao điện:</b><b> <a href="?yeu">Chuyển sang chế độ yếu</a></b></div>';
		}
		require('../shop/my.php');
		if(isset($_GET['id'])){
		include 'shop_info.php';
		}
}
require('../incfiles/end.php');
?>