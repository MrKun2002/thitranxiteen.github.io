<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Cộng tiền';
require('../incfiles/head.php');
$kiemtra = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$datauser["id"]."'"));
if($kiemtra['rights'] == 9){
if(isset($_GET['congtien']) && $datauser['rights'] == 9){
		$int = intval($_GET['congtien']);
		$tienvnd = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$int."'"));
		mysql_query("UPDATE `users` SET `tienvnd` = `tienvnd` + '400' WHERE `id` = '".$int."' LIMIT 1");
		echo 'Đã cộng tiền thành công cho user <b>'.$tienvnd['name'].'</b>';
	}
}else{
	echo '<div class="list1">Định làm gì thế hả, xem nội dung mật forum sao, Không được đâu sói ạ</div>';
}
require('../incfiles/end.php');
?>