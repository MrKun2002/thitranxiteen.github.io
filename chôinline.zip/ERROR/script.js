var time = 10;var timer;var t;var url = viethuy.info;
$(document).ready(function(){
	t = $('#container');
	if(t.text()!=''){
		time = t.text();
	}
	t.html('Chuyển trang trong: '+time+'s');
	initSC();
});
function initSC(){
	if(t.text()!=''){
		timer = setInterval(countDown, 900);
	} else {
		setTimeout(initSC, 900);
	}
}
function countDown(){
	t.html('Chuyển trang trong: '+time+'s');
	if(time == 0){
		clearInterval(timer);
		if(location.href==url||url==''){
			url = window.location.protocol+"//"+location.hostname;
		}
		var u = $('#url');
		if(u.val()!=''&&u.val()!=undefined){
			url = u.val();
		}
		window.location = url;
		t.html("Loading...");
	}
	time--;
}