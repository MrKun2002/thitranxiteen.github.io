<?php
//Việt Hóa : JohnCMSVN.COM
//--JohnCMSVN.COm - JohNCMS Việt Nam ---

define('_IN_JOHNCMS', 1);

$textl = 'Câu Cá :D';
$headmod = "fish";
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');
if (!$user_id) {
    echo display_error('Dành cho thành viên hoặc đang bảo trì nhá !');
    require_once ('../incfiles/end.php');
    exit;
}
$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    header('Location: index.php');
    exit;
}

$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    header('Location: index.php');
    exit;
}

$res = mysql_fetch_array(mysql_query("SELECT * FROM `fish_in` WHERE `user_id` = '".$user_id."' LIMIT 1"));
$res2 = mysql_fetch_array(mysql_query("SELECT * FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
$res3 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fish_sad` WHERE `user_id` = '".$user_id."'"), 0);


switch ($act) {

case '1':
$kiemtra1 = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '1' LIMIT 1"));
if($kiemtra1['soluong'] > 0  || $datauser['rights'] == 9){

if($datauser['docamtay'] == 16268 && $res['na'] == 1){
echo '<div class="phdr"><img src="/cauca/img/ve1.png"> <b>Khu câu cá rô</b></div>';
$post = mysql_fetch_array(mysql_query("select * from `khodo` WHERE `id_user`= '".$datauser["id"]."' AND `name` = 16268 LIMIT 1"));
if($post['time'] < time()){
    echo '<div class="rmenu">Cần câu của bạn đã hết hạn rồi bạn hãy quay vào <a href="/ruong/"><b>Rương</b> của mình để tiến hành bán và mua lại cần câu mới nhé!!</div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if($res['na_d'] == 0){
    echo '<div class="rmenu">Bạn đã hết mồi rồi, hãy quay lại <br/><a href="cuahang.html"><b>Cửa Hàng</b></a> để mua thêm mồi nhé!</div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if($res3 > 10){
    echo '<div class="rmenu">Nhà kho của bạn đã đầy rồi không thể chứa thêm được nữa bạn vui lòng vào bán bớt đi để lấy chỗ để lứa cá mới nhé!<br/><a href="nhakho.html">Trong Nhà Kho</a></div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
mysql_query("UPDATE `users` SET `can-cau` = '1' WHERE `id` = '".$datauser['id']."' LIMIT 1");
//-- Online Topic ---//
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '1'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '1'"), 0);
$totalonline = $online_u + $online_g;
$q = @mysql_query("select * from `users` where `lastdate` > " . (time() - 300) . " AND `can-cau` = '1';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)){
$trinhtrangvip = mysql_query("select `rights` from `users` where id='" . $arr['id'] . "'");
$trinhtrangviphonnua = mysql_fetch_array($trinhtrangvip);
if($arr['id'] != $datauser['id']){
$u_on[]='<a href="../users/' . $arr['name'] . '_' . $arr['id'] . '.html"><img style="line-height: 1px;" src="/avatar/' . $arr['id'] . '.png"></a><img src="img/giangcau.gif"/><br/>';
}else{
	$u_on[]='<img style="line-height: 1px;" src="/avatar/' . $arr['id'] . '.png"><img src="img/giangcau.gif"/><br/>';
}
}
if($res2['time'] == 0){
$rt = mt_rand(30, 150);
mysql_query("UPDATE `fish` SET `time` = '".$realtime."', `rand_time` = '".$rt."', `loc` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
}
echo '<style>.oz2 {
    background-image: url(img/caucaronen.png);
	margin: -2px -5px -1px -5px;
	padding: 6px;
	max-width: 100%;
	margin: auto;
	height: 325px;
	border-bottom: 2px solid #e7e7e7;
	}
	.nendacaro{
	background: url("/cauca/img/caucaro.png") no-repeat bottom left;
	max-width: 100%;
	height: 330px;
	border-bottom: 2px solid #e7e7e7;
	margin: -2px -5px -1px -5px;
	}
	.chongoi1
	{
		text-align: left;
		padding: 90px 0px 60px 45px;
	}
	.chongoi2
	{
		text-align: left;
		padding: 10px 0px 60px 38px;
	}
</style>

<div class="oz2">
<div class="nendacaro">';

if ($online_u > 0 && $online_u <= 6){
echo '<div class="chongoi1">';
echo implode(' ',$u_on).'';
}else{
	echo 'Trống';
}
echo '</div></div></div>
';
echo '<div class="list1">';
echo '- Đang đợi cá căn câu, kiên nhẫn chờ đợi đi...';

$time_s = mysql_fetch_array(mysql_query("SELECT `time`, `rand_time`, `danhdau` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($time_s['time'] + $time_s['rand_time'] - $res['na'] < $realtime){
    mysql_query("UPDATE `fish` SET `status` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
	mysql_query("UPDATE `fish` SET `danhdau` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");
    echo '<br/><a href="khu.html?act=fish"><b>[Giật Cá Lên]</a>. "Nhanh tay không nó đi mất"';
}elseif($time_s['time'] + $time_s['rand_time'] - $res['na'] >= $realtime && $time_s['danhdau'] == 1){
	$rand = mt_rand(1, 50);
    echo '<br/>- Chỗ này không có cá tung chỗ khác<br/><a href="khu.html?act=1&amp;r='.$rand.'"><b>[Tung Ra Chỗ Khác]</b></a>';
}else{
    $rand = mt_rand(1, 50);
    echo '<br/><a href="khu.html?act=1&amp;r='.$rand.'"><b>[Tung Ra Chỗ Khác]</b></a>';
	mysql_query("UPDATE `fish` SET `danhdau` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
}

echo '</div>';
$tinhthoigian = $post['time'] - time();
$tinhgio = $tinhthoigian/3600;
$tinhgiotron = (int)$tinhgio;
echo '<div class="list2">
</b>Cần câu Thuê: '.$tinhgiotron.' Tiếng<br/>
Số mồi cơm còn lại: : '.$res['na_d'].'.
</div>';}else{
	echo '<div class="phdr"><img src="/cauca/img/ve1.png"> <b>Khu câu cá rô</b></div>';
	echo '<div class="list1">Bạn không có cần câu tre hoặc không có mồi cơm để câu ở đây, Hay bạn mua cần tre rồi mà chưa đeo cần vào hãy vào <a href="/ruong/"><b>Kho Đồ</b></a> để đeo cần vào đi câu nhé!</div>';
}
}else{

	echo '<div class="phdr"><img src="/cauca/img/ve1.png"> <b>Khu câu cá rô</b></div>';
	echo '<div class="list1">Khu vực đã hết cá rồi, sang khu vực khác câu nhé...</div>';
}
break;

case '2':
$kiemtra2 = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '2' LIMIT 1"));
if($kiemtra2['soluong'] > 0){

mysql_query("UPDATE `users` SET `can-cau` = '2' WHERE `id` = '".$datauser['id']."' LIMIT 1");
if($datauser['docamtay'] == 16269 && $res['na'] == 2){
echo '<div class="phdr"><img src="/cauca/img/ve1.png"><b>Khu câu cá lóc...</b></div>';
$post = mysql_fetch_array(mysql_query("select * from `khodo` WHERE `id_user`= '".$datauser["id"]."' AND `name` = 16269 LIMIT 1"));
if($post['time'] < time()){
    echo '<div class="rmenu">Cần câu của bạn đã hết hạn rồi bạn hãy quay vào <a href="/ruong/"><b>Rương</b></a> của mình để tiến hành bán và mua lại cần câu mới nhé!!</div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if($res['na_d'] == 0){
    echo '<div class="rmenu">Bạn đã hết mồi rồi, hãy quay lại <br/><a href="cuahang.html"><b>Cửa Hàng</b></a> để mua thêm mồi nhé!</div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if($res3 > 10){
    echo '<div class="list1">Kho lữu trữ cá đã đầy vui lòng về sử lí bớt đi nhé.<br/><a href="nhakho.html"><b>[Kho lưu trữ cá]</b></a></div>';
    echo '<div class="list2"><a href="/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
$kiemtra2 = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '2' LIMIT 1"));
//-- Online Topic ---//
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '2'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '2'"), 0);
$totalonline = $online_u + $online_g;
$q = @mysql_query("select * from `users` where `lastdate` > " . (time() - 300) . " AND `can-cau` = '2';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)){
$trinhtrangvip = mysql_query("select `rights` from `users` where id='" . $arr['id'] . "'");
$trinhtrangviphonnua = mysql_fetch_array($trinhtrangvip);
if($arr['id'] != $datauser['id']){
$u_on[]='<a href="../users/' . $arr['name'] . '_' . $arr['id'] . '.html"><img style="line-height: 1px;" src="/avatar/' . $arr['id'] . '.png"></a><img src="img/giangcau.gif"/><br/>';
}else{
	$u_on[]='<img style="line-height: 1px;" src="/avatar/' . $arr['id'] . '.png"><img src="img/giangcau.gif"/><br/>';
}
}


if($res2['time'] == 0){
$rt = mt_rand(60, 250);
mysql_query("UPDATE `fish` SET `time` = '".$realtime."', `rand_time` = '".$rt."', `loc` = '2' WHERE `user_id` = '".$user_id."' LIMIT 1");
}

echo '<style>.oz2 {
    background-image: url(img/caucaronen.png);
	margin: -2px -5px -1px -5px;
	padding: 6px;
	max-width: 100%;
	margin: auto;
	height: 325px;
	border-bottom: 2px solid #e7e7e7;
	}
	.nendacaro{
	background: url("/cauca/img/caucaro.png") no-repeat bottom left;
	max-width: 100%;
	height: 330px;
	border-bottom: 2px solid #e7e7e7;
	margin: -2px -5px -1px -5px;
	}
	.chongoi1
	{
		text-align: left;
		padding: 90px 0px 60px 45px;
	}
	.chongoi2
	{
		text-align: left;
		padding: 10px 0px 60px 38px;
	}
</style>

<div class="oz2">
<div class="nendacaro">';

if ($online_u > 0 && $online_u <= 6){
echo '<div class="chongoi1">';
echo implode(' ',$u_on).'';
}else{
	echo 'Trống';
}
echo '</div></div></div>
';
echo '<div class="list1">';
echo 'Đang thả, hãy đợi xem có động tĩnh gì của cá không...';

$time_s = mysql_fetch_array(mysql_query("SELECT `time`, `rand_time` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($time_s['time'] + $time_s['rand_time'] - $res['na'] < $realtime){
    mysql_query("UPDATE `fish` SET `status` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
	mysql_query("UPDATE `fish` SET `danhdau` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");
    echo '<br/><a href="khu.html?act=fish"><b>[Giật Cá Lên]</a>. "Nhanh tay không nó đi mất"';
}elseif($time_s['time'] + $time_s['rand_time'] - $res['na'] >= $realtime && $time_s['danhdau'] == 1){
	$rand = mt_rand(1, 70);
    echo '<br/>- Chỗ này không có cá tung chỗ khác<br/><a href="khu.html?act=2&amp;r='.$rand.'"><b>[Tung Ra Chỗ Khác]</b></a>';
}else{
    $rand = mt_rand(1, 70);
    echo '<br/><a href="khu.html?act=2&amp;r='.$rand.'"><b>[Tung Ra Chỗ Khác]</b></a>';
	mysql_query("UPDATE `fish` SET `danhdau` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
}

echo '</div>';
$tinhthoigian = $post['time'] - time();
$tinhgio = $tinhthoigian/3600;
$tinhgiotron = (int)$tinhgio;
echo '<div class="list2">
</b>Cần câu Thuê: '.$tinhgiotron.' Tiếng<br/>
Số mồi trùng còn lại: : '.$res['na_d'].'.
</div>';}else{
	echo '<div class="phdr"><img src="/cauca/img/ve2.png"> <b>Khu câu cá lòng tong</b></div>';
	echo 'Bạn không có cần cần câu sắt hoặc không có mồi mồi trùng để câu ở đây, Hay bạn mua cần sắt rồi mà chưa đeo cần vào hãy vào <a href="/ruong/"><b>Kho Đồ</b></a> để đeo cần vào đi câu nhé!';
}
}else{

	echo '<div class="phdr"><img src="/cauca/img/ve2.png"> <b>Khu câu cá lòng tong</b></div>';
	echo '<div class="list1">Khu vực đã hết cá rồi, sang khu vực khác câu nhé...</div>';
}
break;
case '3':


echo '<div class="phdr"><img src="/cauca/img/ve1.png"> <b>Khu câu cá mập</b></div>';
$kiemtra3 = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '3' LIMIT 1"));
if($kiemtra3['soluong'] > 0 || $datauser['rights'] == 9){
if($datauser['docamtay'] == 16270 && $res['na'] == 3){
$post = mysql_fetch_array(mysql_query("select * from `khodo` WHERE `id_user`= '".$datauser["id"]."' AND `name` = 16270 LIMIT 1"));
if($post['time'] < time()){
    echo '<div class="rmenu">Cần câu của bạn đã hết hạn rồi bạn hãy quay vào <a href="/ruong/"><b>Rương</b></a> của mình để tiến hành bán và mua lại cần câu mới nhé!!</div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if($res['na_d'] == 0){
    echo '<div class="rmenu">Bạn đã hết mồi rồi, hãy quay lại <br/><a href="cuahang.html"><b>Cửa Hàng</b></a> để mua thêm mồi nhé!</div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if($res3 > 10){
    echo '<div class="rmenu">Bạn chạy ra khỏi không gian trong nhà lao!<br/><a href="sadok.php">Trong Xa-đốc</a></div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khu câu cá</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
mysql_query("UPDATE `users` SET `can-cau` = '3' WHERE `id` = '".$datauser['id']."' LIMIT 1");
//-- Online Topic ---//
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '3'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '3'"), 0);
$totalonline = $online_u + $online_g;
$q = @mysql_query("select * from `users` where `lastdate` > " . (time() - 300) . " AND `can-cau` = '3';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)){
$trinhtrangvip = mysql_query("select `rights` from `users` where id='" . $arr['id'] . "'");
$trinhtrangviphonnua = mysql_fetch_array($trinhtrangvip);
if($arr['id'] != $datauser['id']){
$u_on[]='<a href="../users/' . $arr['name'] . '_' . $arr['id'] . '.html"><img style="line-height: 1px;" src="/avatar/' . $arr['id'] . '.png"></a><img src="img/giangcau.gif"/><br/>';
}else{
	$u_on[]='<img style="line-height: 1px;" src="/avatar/' . $arr['id'] . '.png"><img src="img/giangcau.gif"/><br/>';
}
}


if($res2['time'] == 0){
$rt = mt_rand(65, 300);
mysql_query("UPDATE `fish` SET `time` = '".$realtime."', `rand_time` = '".$rt."', `loc` = '3' WHERE `user_id` = '".$user_id."' LIMIT 1");
}

echo '<style>.oz2 {
    background-image: url(img/caucaronen.png);
	margin: -2px -5px -1px -5px;
	padding: 6px;
	max-width: 100%;
	margin: auto;
	height: 325px;
	border-bottom: 2px solid #e7e7e7;
	}
	.nendacaro{
	background: url("/cauca/img/caucaro.png") no-repeat bottom left;
	max-width: 100%;
	height: 330px;
	border-bottom: 2px solid #e7e7e7;
	margin: -2px -5px -1px -5px;
	}
	.chongoi1
	{
		text-align: left;
		padding: 90px 0px 60px 45px;
	}
	.chongoi2
	{
		text-align: left;
		padding: 10px 0px 60px 38px;
	}
</style>

<div class="oz2">
<div class="nendacaro">';

if ($online_u > 0 && $online_u <= 6){
echo '<div class="chongoi1">';
echo implode(' ',$u_on).'';
}else{
	echo 'Trống';
}
echo '</div></div></div>
';
echo '<div class="list1">';
echo 'Đang thả, hãy đợi xem có động tĩnh gì của cá không...';

$time_s = mysql_fetch_array(mysql_query("SELECT `time`, `rand_time` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($time_s['time'] + $time_s['rand_time'] - $res['na'] < $realtime){
    mysql_query("UPDATE `fish` SET `status` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
	mysql_query("UPDATE `fish` SET `danhdau` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");
    echo '<br/><a href="khu.html?act=fish"><b>[Giật Cá Lên]</a>. "Nhanh tay không nó đi mất"';
}elseif($time_s['time'] + $time_s['rand_time'] - $res['na'] >= $realtime && $time_s['danhdau'] == 1){
	$rand = mt_rand(1, 99);
    echo '<br/>- Chỗ này không có cá tung chỗ khác<br/><a href="khu.html?act=3&amp;r='.$rand.'"><b>[Tung Ra Chỗ Khác]</b></a>';
}else{
    $rand = mt_rand(1, 99);
    echo '<br/><a href="khu.html?act=3&amp;r='.$rand.'"><b>[Tung Ra Chỗ Khác]</b></a>';
	mysql_query("UPDATE `fish` SET `danhdau` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
}
echo '</div>';
$tinhthoigian = $post['time'] - time();
$tinhgio = $tinhthoigian/3600;
$tinhgiotron = (int)$tinhgio;
echo '<div class="list2">
</b>Cần câu Thuê: '.$tinhgiotron.' Tiếng<br/>
Số mồi trứng kiến còn lại: : '.$res['na_d'].'.
</div>';}else{
	echo 'Bạn không có cần cần của Apoleon(Cần câu hoàng gia) ở trên người hoặc không có trứng kiến để câu ở đây. Hãy vào <a href="/cauca/cuahang.html"><b>Cửa Hàng</b></a> để mua vật phẩm, , Hay bạn mua cần hoàng gia rồi mà chưa đeo cần vào hãy vào <a href="/ruong/"><b>Kho Đồ</b></a> để đeo cần vào đi câu nhé!';
}
}else{

	echo '<div class="list1">Khu vực đã hết cá rồi, sang khu vực khác câu nhé...</div>';
}
break;

case 'fish':
if($res2['status'] != 1){
    header('Location: khu.html');
    exit;
}else{
	
	if($datauser['docamtay'] == 16268 && $res['na'] == 1){
	$fish_k = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '1' LIMIT 1"));
	}elseif($datauser['docamtay'] == 16269 && $res['na'] == 2){
	$fish_k = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '2' LIMIT 1"));
	}elseif($datauser['docamtay'] == 16270 && $res['na'] == 3){
	$fish_k = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '3' LIMIT 1"));
	}
    $sorv = mt_rand(1, 10);
		$kiemtracauca = mysql_fetch_array(mysql_query("SELECT * FROM `fish_tb` WHERE `user_id` = '$user_id' ORDER BY `id` DESC LIMIT 1"));
		$kiemtratimetb = $kiemtracauca[time]+40;
    if($sorv != 10 && $kiemtratimetb <= time() && $fish_k[soluong] > 0){
        

    $rands5 = mt_rand($fish_k['kg_min'], $fish_k['kg_max']);
    $netto_r = $rands5;
    mysql_query("INSERT INTO `fish_sad` SET 
    `user_id` = '".$user_id."',
    `name` = '".$fish_k['name']."',
    `netto` = '".$netto_r."',
    `fish_id` = '".$fish_k['id']."'
    ");
	$giamsoluong = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `name` = '".$fish_k["name"]."' LIMIT 1"));
	mysql_query("UPDATE `fish_r` SET `soluong` = `soluong` - 1 WHERE `id` = '".$giamsoluong["id"]."' LIMIT 1");
	mysql_query("INSERT INTO `fish_tb` SET `user_id` = '".$user_id."', `time` = '".time()."', `id_fish` = '".$fish_k['id']."', `kg` = '".$netto_r."' ");
    mysql_query("UPDATE `fish` SET `vsego` = `vsego`+'".$netto_r."', `kg` = `kg`+'".$netto_r."', `sorv` = '0', `time` = 0, `rand_time` = 0, `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");
    }else{
        mysql_query("UPDATE `fish` SET `sorv` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
    }
    
    $rd1 = mt_rand(1, 3);
    $rd2 = mt_rand(1, 3);
    $rd3 = mt_rand(1, 3);
    
    mysql_query("UPDATE `fish_in` SET `na_d` = `na_d`-1 WHERE `user_id` = '".$user_id."'");

    header('Location: khu.html?act=fishrez');
    exit;
}
break;

case 'fishrez':
echo '<div class="phdr"><b>Giật cá</b></div>';

mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");

if($res2['kg'] >= 2000){
    $rdm = mt_rand(100, 600);
    mysql_query("UPDATE `fish` SET `kg` = '0', `lvl` = `lvl`+1, `money` = `money`+'".$rdm."' WHERE `user_id` = '".$user_id."' LIMIT 1");
    echo '<div class="list2">Xin chúc mừng! Bạn có một cấp độ mới và +'.$rdm.' tiền!</div>';
}

$olo = mysql_query("SELECT * FROM `fish_sad` WHERE `user_id` = '".$user_id."' ORDER BY `id` DESC LIMIT 1");

$sorv = mysql_fetch_array(mysql_query("SELECT `sorv` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($sorv['sorv'] == 1){
    echo '<div class="list1">Cá chạy mất rồi, trình độ câu của bạn kém quá, cá cắn câu rồi mà còn để nó thoát <img src="http://choionline.cf/images/smileys/user/Yahoo/20.gif"/></div>';
    echo '<div class="menu"><a href="khu.html?act='.$res2['loc'].'"><b>[Câu Tiếp]</b></a></div>';
	echo '<div class="menu"><a href="/cauca/"><b>[Thoát ra ngoài "Trình độ của tôi kém lắm"]</b></a></div>';
    require_once ('../incfiles/end.php');
    exit;
}
$fish_p = mysql_fetch_array($olo);
$randumca = rand(1,3);
$vsego = $fish_p['netto'];
	echo '<div class="menu">
	<center><img src="/cauca/img/'.$res['na'].'.png"></center>
	Xin chúc mừng, bạn đã câu được một con cá '.$fish_p['name'].' có trọng lượng '.round($vsego, 0).' KG.</div>';
    echo '<div class="menu"><a href="khu.html?act='.$res2['loc'].'"><b>[Câu Tiếp]</b></a></div>';
	echo '<div class="menu"><a href="/cauca/"><b>[Thoát ra ngoài "Thu hoạch lớn rồi"]</b></a></div>';
	mysql_query("UPDATE `fish` SET `sorv` = '1' WHERE `user_id` = '".$user_id."' LIMIT 1");
	require_once ('../incfiles/end.php');
    exit;
break;

default:
mysql_query("UPDATE `users` SET `can-cau` = '4' WHERE `id` = '".$datauser['id']."' LIMIT 1");
mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");
echo '<div class="phdr">CHỌN KHU CÂU CÁ</div>';
//-- Online Topic ---//
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '4'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '4'"), 0);
$totalonline = $online_u + $online_g;
$q = @mysql_query("select * from `users` where `lastdate` > " . (time() - 300) . " AND `can-cau` = '4';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)){
$trinhtrangvip = mysql_query("select `rights` from `users` where id='" . $arr['id'] . "'");
$trinhtrangviphonnua = mysql_fetch_array($trinhtrangvip);
if($arr['id'] != $datauser['id']){
$u_on[]='<a href="../users/' . $arr['name'] . '_' . $arr['id'] . '.html"><img src="/avatar/' . $arr['id'] . '.png"></a>';
}else{
	$u_on[]='<img src="/avatar/' . $arr['id'] . '.png">';
}
}
//Keet thuc topic
echo '<div class="thanhpho">
<marquee behavior="scroll" direction="left" scrollamount="1" style="margin-top: 5px"><img src="/iconvip/may1.png"></marquee>
<marquee behavior="scroll" direction="left" scrollamount="2" style="margin-top: 10px"><img src="/iconvip/may2.png"></marquee>
';
echo '<div class="vaocau">
<table width="100%">
<tr>
<td width="50%">
<a href="http://choionline.cf/cauca/cuahang.html"><img src="/cauca/img/shopcauca.png"></a>
</td>
<td width="50%" style="padding-top: 20px;">
<a href="/cauca/bxh.html"><img src="/images/bxh.png" /></a>
</td>
</tr>
</table>
</div></div>

<div class="nenda">';
if ($online_u > 0){
echo implode(' ',$u_on).'';
}else{
	echo 'Để giảm thiểu lag, AD xin ẩn các thành viên nhé!';
}
echo '</div><div class="list2">Hãy chọn khu vực để đánh bắt cá nhé!</div>';
$hienthisoluong1 = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '1' LIMIT 1"));
echo '<div class="list1"><table><tr><td><img src="/cauca/img/khu1.png"></td><td> <b>[<a href="khu.html?act=1">Khu câu cá rô</a>]</b>';
if($hienthisoluong1['soluong'] > 0){
echo '<br/> (<span style="color: red;">Hiện còn <b>'.$hienthisoluong1['soluong'].'</b> con cá rô trong khu</span>)';
}else{
	echo '<br/> (<span style="color: red;">Khu vực đã hết cá rồi AE câu ác quá đi</span>)';
	// Mod tự động thêm số lượng cá
	if($hienthisoluong1['time'] == 0){
	mysql_query("UPDATE `fish_r` SET `time` = '".time()."' WHERE `id` = '1'");
	}else{
	$tinhtime = $hienthisoluong1['time'] + 14400;
	$timeht = time();
	if($tinhtime <= $timeht){
		mysql_query("UPDATE `fish_r` SET `soluong` = '70' WHERE `id` = '1'");
		mysql_query("UPDATE `fish_r` SET `time` = '0' WHERE `id` = '1'");
	}else{
			$tinhtimeconlai = ($hienthisoluong1['time']+14400) - time();
			$tinhphutconlai = floor($tinhtimeconlai/60);
			$tinhgioconlai = floor($tinhphutconlai/60);
			$tinhgioconlaidu = floor($tinhphutconlai%60);
			if($tinhgioconlai > 0){
			echo '<br/>- Cá rô phi sẽ được nhập khẩu  từ <b>Thái Lan</b> trong '.$tinhgioconlai.' giờ '.$tinhgioconlaidu.' phút nữa. AE vui lòng kiên nhẫn đợi!';
			}else{
			echo '<br/>- Cá rô phi sẽ được nhập khẩu  từ <b>Thái Lan</b> trong '.$tinhphutconlai.' phút nữa. AE vui lòng kiên nhẫn đợi!';
			}

		}
	}
}
echo '</td></tr></table></div>';
$hienthisoluong2 = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '2' LIMIT 1"));
echo '<div class="list2"><table><tr><td><img src="/cauca/img/khu2.png"></td><td> <b>[<a href="khu.html?act=2">Khu câu lòng tong</a>]</b>';
if($hienthisoluong2['soluong'] > 0){
echo '<br/> (<span style="color: red;">Hiện còn <b>'.$hienthisoluong2['soluong'].'</b> con cá lòng tong trong khu</span>)';
}else{
	echo '<br/> (<span style="color: red;">Khu vực đã hết cá rồi AE câu ác quá đi</span>)';
	// Mod tự động thêm số lượng cá
	if($hienthisoluong2['time'] == 0){
	mysql_query("UPDATE `fish_r` SET `time` = '".time()."' WHERE `id` = '2'");
	}else{
	$tinhtime = $hienthisoluong2['time'] + 14400;
	$timeht = time();
	if($tinhtime <= $timeht){
		mysql_query("UPDATE `fish_r` SET `soluong` = '40' WHERE `id` = '2'");
		mysql_query("UPDATE `fish_r` SET `time` = '0' WHERE `id` = '2'");
	}else{
			$tinhtimeconlai = ($hienthisoluong2['time']+14400) - time();
			$tinhphutconlai = floor($tinhtimeconlai/60);
			$tinhgioconlai = floor($tinhphutconlai/60);
			$tinhgioconlaidu = floor($tinhphutconlai%60);
			if($tinhgioconlai > 0){
			echo '<br/>- Cá lòng tong sẽ được nhập khẩu  từ <b>Hoàng Xa</b> trong '.$tinhgioconlai.' giờ '.$tinhgioconlaidu.' phút nữa. AE vui lòng kiên nhẫn đợi!';
			}else{
			echo '<br/>- Cá lòng tong sẽ được nhập khẩu  từ <b>Hoàng Xa</b> trong '.$tinhphutconlai.' phút nữa. AE vui lòng kiên nhẫn đợi!';
			}
	}
	}
}
echo '</td></tr></table></div>';
$hienthisoluong3 = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '3' LIMIT 1"));
echo '<div class="list1"><table><tr><td><img src="/cauca/img/khu3.png"></td><td> <b>[<a href="khu.html?act=3">Khu câu cá mập</a>]</b>';
if($hienthisoluong3['soluong'] > 0){
echo '<br/> (<span style="color: red;">Hiện còn <b>'.$hienthisoluong3['soluong'].'</b> con cá mập trong khu</span>)';
}else{
	echo '<br/> (<span style="color: red;">Khu vực đã hết cá rồi AE câu ác quá đi</span>)';
	// Mod tự động thêm số lượng cá
	if($hienthisoluong3['time'] == 0){
	mysql_query("UPDATE `fish_r` SET `time` = '".time()."' WHERE `id` = '3'");
	}else{
	$tinhtime = $hienthisoluong3['time'] + 14400;
	$timeht = time();
	if($tinhtime <= $timeht){
		mysql_query("UPDATE `fish_r` SET `soluong` = '15' WHERE `id` = '3'");
		mysql_query("UPDATE `fish_r` SET `time` = '0' WHERE `id` = '3'");
	}else{
		$tinhtimeconlai = ($hienthisoluong3['time']+14400) - time();
		$tinhphutconlai = floor($tinhtimeconlai/60);
		$tinhgioconlai = floor($tinhphutconlai/60);
		$tinhgioconlaidu = floor($tinhphutconlai%60);
			if($tinhgioconlai > 0){
			echo '<br/>- Cá mập sẽ được nhập khẩu  từ <b>Nhật Bổn</b> trong '.$tinhgioconlai.' giờ '.$tinhgioconlaidu.' phút nữa. AE vui lòng kiên nhẫn đợi!';
			}else{
			echo '<br/>- Cá mập sẽ được nhập khẩu  từ <b>Nhật Bổn</b> trong '.$tinhphutconlai.' phút nữa. AE vui lòng kiên nhẫn đợi!';
			}
		
		}
	}
	
}
echo '</td></tr></table></div>';
}

require_once ("../incfiles/end.php");

?>