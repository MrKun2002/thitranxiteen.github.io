<?php
//Việt Hóa : JohnCMSVN.COM
//--JohnCMSVN.COm - JohNCMS Việt Nam ---

define('_IN_JOHNCMS', 1);

$textl = 'Câu Cá :D';
$headmod = "fish";
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');

if (!$user_id) {
    echo display_error('Dành cho thành viên nhá !');
    require_once ('../incfiles/end.php');
    exit;
}

$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    header('Location: index.php');
    exit;
}

mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `fish_sad` WHERE `user_id` = '".$user_id."'"), 0);

echo '<div class="phdr"><b>Kho Lạnh Lưu Trữ Cá</b></div>';

switch ($act) {

case 'add':

$id = intval($_GET['id']);
$kol = mysql_num_rows(mysql_query("SELECT `id` FROM `fish_sad` WHERE `id` = '".$id."' AND `user_id` = '".$user_id."' LIMIT 1"));
if($kol != 1){
    echo '<div class="list1">Cá này không có đâu nhé!<br/><a href="nhakho.html">Quay lại nhà kho</a></div>';
    echo '<div class="list3"><a href="/cauca/">Thoát khỏi nhà kho</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

$req = mysql_fetch_array(mysql_query("SELECT * FROM `fish_sad` WHERE `user_id` = '".$user_id."' AND `id` = '".$id."' LIMIT 1"));
mysql_query("INSERT INTO `fish_koll` SET 
`user_id` = '".$user_id."', 
`name` = '".$req['name']."', 
`netto` = '".$req['netto']."'
");

mysql_query("DELETE FROM `fish_sad` WHERE `id` = '".$id."' AND `user_id` = '".$user_id."' LIMIT 1");

echo '<div class="list1">Cá đã được bổ sung vào bộ sưu tập!</div><div class="list1"><a href="nhakho.html">Quay lại nhà kho</a></div>';

break;

case 'money':

$id = intval($_GET['id']);
$kol = mysql_num_rows(mysql_query("SELECT `id` FROM `fish_sad` WHERE `id` = '".$id."' AND `user_id` = '".$user_id."' LIMIT 1"));
if($kol != 1){
    echo '<div class="list1">Cá này là không có!<br/><a href="nhakho.html">Quay lại nhà kho</a></div>';
    echo '<div class="list3"><a href="/">Về game</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

$req = mysql_fetch_array(mysql_query("SELECT * FROM `fish_sad` WHERE `user_id` = '".$user_id."' AND `id` = '".$id."' LIMIT 1"));
$req2 = mysql_fetch_array(mysql_query("SELECT `cena` FROM `fish_r` WHERE `id` = '".$req['fish_id']."' LIMIT 1"));

echo '<div class="menu">
Cá: '.$req['name'].'<br/>';
$vsego = $req['netto'];
echo 'Trọng lượng: '.round($vsego, 2).' KG.<br/>';
$money = $req['netto'] * $req2['cena'];
echo 'Giá: '.round($money).' Xu
</div>';

echo '<div class="list2"><a href="nhakho.html?act=moneyes&amp;id='.$id.'">Bán</a> | <a href="nhakho.html">Hủy bỏ</a></div>';

break;

case 'moneyes':

$id = intval($_GET['id']);
$kol = mysql_num_rows(mysql_query("SELECT `id` FROM `fish_sad` WHERE `id` = '".$id."' AND `user_id` = '".$user_id."' LIMIT 1"));
if($kol != 1){
    echo '<div class="list1">Cá này là không có!<br/><a href="nhakho.html">Quay lại nhà kho</a></div>';
    echo '<div class="list3"><a href="/cauca/">Thoát khỏi nhà kho</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

$req = mysql_fetch_array(mysql_query("SELECT * FROM `fish_sad` WHERE `user_id` = '".$user_id."' AND `id` = '".$id."' LIMIT 1"));
$req2 = mysql_fetch_array(mysql_query("SELECT `cena` FROM `fish_r` WHERE `id` = '".$req['fish_id']."' LIMIT 1"));
$money = $req['netto'] * $req2['cena'];
$money2 = round($money);
mysql_query("DELETE FROM `fish_sad` WHERE `id` = '".$id."' AND `user_id` = '".$user_id."' LIMIT 1");
mysql_query("UPDATE `users` SET `balans` = `balans`+'".$money2."' WHERE `id` = '".$user_id."' LIMIT 1");
$q="UPDATE `users` SET `balans` = `balans`+'".$money2."' WHERE `id` = '".$user_id."' LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./cauca/sadok.php','".date('d-m-Y  h:i:s A')."')");
echo '<div class="menu">Cá được bán!<br/><a href="nhakho.html">Quay lại nhà kho</a></div>';

break;

default:
if(isset($_GET[ban_ok])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bán Hết Cá Thành Công</div>';
if(isset($_GET[ban_no])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn có cá đâu mà bán</div>';
$tongcamap = mysql_result(mysql_query("SELECT COUNT(*) FROM `fish_sad` WHERE `user_id` = '$user_id' AND `fish_id` = '3'"), 0);
$tongcaro = mysql_result(mysql_query("SELECT COUNT(*) FROM `fish_sad` WHERE `user_id` = '$user_id' AND `fish_id` = '1'"), 0);
$tongcatong = mysql_result(mysql_query("SELECT COUNT(*) FROM `fish_sad` WHERE `user_id` = '$user_id' AND `fish_id` = '2'"), 0);
$tongca = mysql_result(mysql_query("SELECT COUNT(*) FROM `fish_sad` WHERE `user_id` = '$user_id'"), 0);
$giaca = 0;
if($total > 0){
$req = mysql_query("SELECT * FROM `fish_sad` WHERE `user_id` = '".$user_id."' ORDER BY `id` LIMIT $start, $kmess");
while($res = mysql_fetch_array($req)){
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
	$req1 = mysql_query("SELECT * FROM `fish_r` WHERE `name` = '".$res["name"]."' ORDER BY `id` LIMIT $start, $kmess");
	$res1 = mysql_fetch_array($req1);
    $vsego = $res['netto'];
    echo '
	<table width="100%"><tr><td width="13%"><img class="avatarfr" src="/cauca/img/'.$res1['id'].'.png"></td><td width="90%">Loại cá: <b>'.$res['name'].'</b><br/>Trọng lượng: '.$vsego.' KG';
	$giaca += $res1['cena']*$vsego;
    echo '<br/><b>[ <a href="nhakho.html?act=money&amp;id='.$res['id'].'">Bán</a> ]</b></td></tr></table></div>';
    ++$i;
}
	if($tongca != 0){
		echo '<div class="list5">Tổng số tiền từ cá trong kho: <b>'.$giaca.' Xu</b><br/><br/>';
		echo '<a id="nut" href="?all">Bán Tất Cả Cá</a>';
		echo '</div>';
	}
	if(isset($_GET['all']) && $tongca != 0){
		mysql_query("DELETE FROM `fish_sad` WHERE `user_id` = '$user_id'");
		mysql_query("UPDATE `users` SET `balans` = `balans` + '$giaca' WHERE `id` = '$user_id' LIMIT 1");
		$q="UPDATE `users` SET `balans` = `balans` + '$giaca' WHERE `id` = '$user_id' LIMIT 1";
		mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./cauca/sadok.php','".date('d-m-Y  h:i:s A')."')");
		header('Location: ?ban_ok');
	}elseif(isset($_GET['all']) && $tongca == 0){
		header('Location: ?ban_no');
	}
}else{
    echo '<div class="list1">Hiện bạn chưa có cá nhé. Bắt đầu vào cửa hàng mua cần với mồi để mà đi câu đi, mốc nhà kho lạnh này giờ!<Br/>
	<a href="cuahang.html"><b>[Cửa Hàng]</b></a>
	</div>';
}


}

echo '<div class="list3"><a href="/cauca/">Thoát khỏi nhà kho</a></div>';

require_once ("../incfiles/end.php");

?>