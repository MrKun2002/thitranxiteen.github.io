<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Cửa hàng';
require('../incfiles/head.php');
if($user_id){
if(isset($_GET['buy_ok']))msg('Mua!');
if(isset($_GET['buy_no']))msg("Không đủ tiền mua!");
if(isset($_GET['id'])){
$int=intval($_GET['id']);
$sql=mysql_query("SELECT `id` FROM `shop` WHERE `id`='$int' ");
$row=mysql_fetch_assoc($sql);

$post = mysql_fetch_array(mysql_query("select * from `shop` WHERE  `id` = '$int'  LIMIT 1"));

$tien = $post['giamua'];
$kt = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `id_user` = '$user_id' AND `name` = '".$post['name']."' AND `loaisp` = '".$post['loaisp']."'"),0);

if($datauser['balans'] >= $tien && $kt == 0) { 
mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `giamua`, `giaban`, `sucmanh`) VALUES  ('".$post['name']."', '".$post['loaisp']."', '".$user_id."', '".$post['giamua']."','".$post['giaban']."','".$post['sucmanh']."') ");
mysql_query("UPDATE `users` SET `balans` = `balans`- $tien WHERE `id` = $user_id LIMIT 1");
$q="UPDATE `users` SET `balans` = `balans`- $tien WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./cauca/cancau.php','".date('d-m-Y  h:i:s A')."')");
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Mua Hàng Thành công</b></div>';
echo '<div class="menu list-top"><img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" /></div>';
echo '<div class="menu list-top"> Giá tiền: '.$post['giamua'].' Xu</div>';
echo '<div class="menu list-top"> Tăng: '.$post['sucmanh'].' SM</div>';
echo '<div class="menu list-top"> Giá tiền bán lại: '.$post['giaban'].' Xu</div>';
} else { 
echo '<div class="main-xmenu">
<div class="danhmuc"><b>Lỗi Mua Hàng Không Thành công</b></div>';
echo '<div class="menu list-top">Có rồi mua chi nữa !</div>';
}
}else{
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop` WHERE  `loaisp` ='docamtay'"), 0);
$res = mysql_query("SELECT * FROM `shop` WHERE  `loaisp` ='docamtay' LIMIT $start, $kmess");
echo "<div class='main-xmenu'><div class='danhmuc'><b>Cửa hàng Đồ Cầm Tay</b></div>";
echo '<div class="menu">Hệ thống cập nhật '.$tong.' món đồ !</div>';
while ($post = mysql_fetch_array($res)){
if($post['id'] == 164 && $post['id'] == 165 && $post['id'] == 166){
$sm= 'Tăng: '.$post['sucmanh'].' SM';
$gia = 'Giá tiền: '.$post['giamua'].' Xu';
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">
<a href="/shop/?id='.$post['id'].'">Mua</a><br/>
'.$sm.'<br/>
'.$gia.'
</td></tr></tbody></table>
</div>';}
}
if ($tong > $kmess){ //Phân Trang
echo '<div class="trang">' . functions::display_pagination('docamtay.php?', $start, $tong, $kmess) . '</div>';
}
}
echo "<div class='menu list-top'>";
if(isset($_GET['id']))
echo "&laquo; <a href='/shop/'>Cửa hàng</a>";
echo "</div></div>";
}else{
msg('Vui lòng đăng nhập!');
}
if($user_id) {
echo '<div class="main-xmenu">
<div class="danhmuc">Danh Sách Đồ</div>
<div class="menu">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="toc.html"><b>Mua Tóc</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="ao.html"><b>Mua Áo</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="quan.html"><b>Mua Quần</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="non.html"><b>Mua Nón</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="kinh.html"><b>Mua Kính</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="mat.html"><b>Mua Mắt</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="matna.html"><b>Mua Mặt Nạ</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="canh.html"><b>Mua Cánh</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="thucung.html"><b>Mua Thú Cứng</b></a></div>
<div class="menu list-top">
<img src="/icon/next.png" alt="icon" style="vertical-align: -1px;">&nbsp;<a href="docamtay.html"><b>Mua Đồ Cầm Tay</b></a></div></div>
';
}
require('../incfiles/end.php');
?>