<?php
//Việt Hóa : JohnCMSVN.COM
//--JohnCMSVN.COm - JohNCMS Việt Nam ---

define('_IN_JOHNCMS', 1);

$textl = 'Câu Cá :D';
$headmod = "fish";
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');

if (!$user_id) {
    echo display_error('Dành cho thành viên nhá !');
    require_once ('../incfiles/end.php');
    exit;
}

$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    header('Location: index.php');
    exit;
}

mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");

$res = mysql_fetch_array(mysql_query("SELECT `balans` FROM `users` WHERE `id` = '".$user_id."' LIMIT 1"));

echo '<div class="phdr"><img src="/images/cuahang.png" width="14px"> Cửa Hàng Bán Đồ Để Câu</div>';

switch ($act) {
case 'udk':
$ud = intval($_POST['ud']);

if($ud < 1 or $ud > 3){
    echo '<div class="list1">Hãy chọn cần đi bạn, vào mà không mua cần thì vào làm gì hả!<br/><a href="/cauca/cuahang.html"><b>[Làm lại]</b></a></div>';
    echo '<div class="list2"><a href="/cauca/">Thoát khỏi cửa hàng</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if($ud == '1'){
    $mon = '2000';
}elseif($ud == '2'){
    $mon = '5000';
}elseif($ud == '3'){
    $mon = '7000';
}else{
    echo '<div class="list1">Không có gì ở đây cả.</div>';
}
if($res['balans'] > $mon){
mysql_query("UPDATE `users` SET `balans`=`balans`-'".$mon."' WHERE `id` = '$user_id' LIMIT 1");
$q="UPDATE `users` SET `balans`=`balans`-'".$mon."' WHERE `id` = '$user_id' LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./cauca/magazin.php','".date('d-m-Y  h:i:s A')."')");
mysql_query("UPDATE `fish_in` SET `ud`= '".$ud."', `ud_d` = '100' WHERE `user_id` = '$user_id' LIMIT 1");

echo '<div class="list1">Chúc mừng bạn đã mua một cần câu mới!</div>';
echo '<div class="list1"><img src="/images/cuahang.png" width="14px"> <a href="/cauca/cuahang.html">Cửa hàng</a></div>';
}else{
    echo '<div class="list1">Không đủ tiền!<br/><a href="/cauca/cuahang.html?act=ud">Làm lại</a></div>';
}
break;

case 'na':
    echo '<div class="list1">Bạn đang có: <b>'.$datauser['balans'].'</b> xu</div>';
    echo '<div class="list1"><form action="/cauca/cuahang.html?act=nak" name="na" method="post">
	<table width="100%"><tr><td width="5%"><img src="/cauca/img/moi1.png"></td><td width="90%"><b>Mồi cơm</b><br/>- Dùng để câu <b>Cá rô</b>!<br/>
    Giá: <b>250</b> Xu<br/>
	<input type="radio" name="na" value="1"/>
	</td></tr></table>
    <table width="100%"><tr><td width="5%"><img src="/cauca/img/moi2.png"></td><td width="90%"><b>Mồi trùng</b><br/>- Dùng để câu <b>Thòng long</b>!<br/>
    Giá: <b>500</b> Xu<br/>
	<input type="radio" name="na" value="2"/>
	</td></tr></table>
	<table width="100%"><tr><td width="5%"><img src="/cauca/img/moi3.png"></td><td width="90%"><b>Trứng kiến</b><br/>- Dùng để câu <b>Cá mập</b>!<br/>
    Giá: <b>750</b> Xu<br/>
	<input type="radio" name="na" value="3"/>
	</td></tr></table>
    <input type="submit" name="submit" value="Mua mồi!"/></form></div>';
break;

case 'nak':
$na = intval($_POST['na']);

if($na < 1 or $na > 10){
    echo '<div class="list1">Hãy chọn mồi đi bạn, vào mà không mua mồi thì vào làm gì hả!<br/><a href="/cauca/cuahang.html"><b>[Làm lại]</b></a></div>';
    echo '<div class="list2"><a href="/cauca/"><b>Thoát khỏi cửa hàng</b></a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

if($na == '1'){
    $mon = '250';
}elseif($na == '2'){
    $mon = '500';
}elseif($na == '3'){
    $mon = '700';
}else{
    echo '<div class="list1">Không có gì ở đây cả.</div>';
}
if($res['balans'] > $mon){
mysql_query("UPDATE `users` SET `balans`=`balans`-'".$mon."' WHERE `id` = '$user_id' LIMIT 1");
$q="UPDATE `users` SET `balans`=`balans`-'".$mon."' WHERE `id` = '$user_id' LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./cauca/magazin.php','".date('d-m-Y  h:i:s A')."')");
mysql_query("UPDATE `fish_in` SET `na` = '".$na."', `na_d` = '100' WHERE `user_id` = '$user_id' LIMIT 1");

echo '<div class="list1">Chúc mừng bạn đã mua một mồi mới!</div>';
echo '<div class="list1"><a href="/cauca/cuahang.html">Trở lại cửa hàng</a></div>';
}else{
    echo '<div class="list1">Không đủ tiền!<br/><a href="/cauca/">Thoát cửa hàng</a></div>';
}
break;

default:
    echo '<div class="list1"><table width="100%"><tr><td width="10%"><img src="/cauca/img/banhang.png"></td><td width="90%">- Ở đây bạn có thể mua các thiết bị cần thiết để có thể đi câu cá!.</td></tr></table></div>';
    echo '<div class="list1">» <b><a href="/shop/cancau.html">Cần Câu</a></b></div>
   <div class="list1">»<b> <a href="/cauca/cuahang.html?act=na">Môi Câu</a></b>
    </div>';

}

echo '<div class="list3"><a href="/cauca/"><b>Thoát khỏi cửa hàng</b></a></div>';
require_once ("../incfiles/end.php");

?>