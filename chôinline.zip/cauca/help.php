<?php
//Việt Hóa : JohnCMSVN.COM
//--JohnCMSVN.COm - JohNCMS Việt Nam ---

define('_IN_JOHNCMS', 1);

$textl = 'Câu Cá :D';
$headmod = "fish";
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');

if (!$user_id) {
    echo display_error('Dành cho thành viên nhá !');
    require_once ('../incfiles/end.php');
    exit;
}

$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    header('Location: index.php');
    exit;
}

mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");

echo '<div class="phdr"><b>Câu cá</b> | Hướng Dẫn</div>';
echo '<div class="gmenu">Cá</div>';

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `fish_r`"), 0);
if($total > 0){
$req = mysql_query("SELECT * FROM `fish_r` ORDER BY `name` LIMIT $start, $kmess");
while($res = mysql_fetch_array($req)){
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
    echo 'Người chơi: <b>'.$res['name'].'</b><br/>Giá cho 1 kg: '.$res['cena'].'<div class="sub">'.$res['info'].'</div>';
    echo '</div>';
    ++$i;
}
}else{
    echo '<div class="rmenu">Ko có gì</div>';
}

echo '<div class="phdr">Tổng: '.$total.'</div>';

if ($total > $kmess) {
            echo '<div class="menu">' . pagenav('?',$start, $total, $kmess) . '</div>';
}

echo '<div class="gmenu"><a href="index.php">Về Game</a></div>';

require_once ("../incfiles/end.php");

?>