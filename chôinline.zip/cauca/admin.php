<?php
//Việt Hóa : JohnCMSVN.COM
//--JohnCMSVN.COm - JohNCMS Việt Nam ---

define('_IN_JOHNCMS', 1);

$textl = 'Câu Cá :D';
$headmod = "fish";
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');

if (!$user_id) {
    echo display_error('Dành cho thành viên nhá !');
    require_once ('../incfiles/end.php');
    exit;
}

if($rights != '9'){
    header('Location: index.php');
    exit;
}

$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    header('Location: index.php');
    exit;
}

mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");

echo '<div class="phdr"><b>Câu cá</b> | Admin Panel</div>';

switch ($act) {

case 'money':

if (isset($_POST['submit'])) {
    $fish['ids'] = isset($_POST['ids']) ? intval($_POST['ids']) : 0;
    $fish['money'] = isset($_POST['money']) ? intval($_POST['money']) : 0;
    
    $yus = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$fish['ids']."'"));
    if($yus != 1){
        echo '<div class="rmenu">Người này không có!</div>';
        echo '<div class="gmenu"><a href="admin.php">Quay lại</a></div>';
        require_once ('../incfiles/end.php');
        exit;
    }
    
    mysql_query("UPDATE `fish` SET `money` = `money`+'".$fish['money']."' WHERE `user_id` = '".$fish['ids']."' LIMIT 1");
    echo '<div class="rmenu">Số tiền thay đổi!</div>';
}

echo '<form action="admin.php?act=money" method="post">';
echo '<div class="gmenu">Thay đổi số tiền</div>';
echo '<div class="menu">ID người chơi<br /><input type="text" size="10" maxlength="10" name="ids" /></div>';
echo '<div class="menu">Số tiền<br /><input type="text" size="10" maxlength="10" name="money" /></div>';
echo '<div class="list2"><input type="submit" value="Ok nào" name="submit" /></div>';
echo '</form>';

break;

case 'ed':

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `fish_r`"), 0);
if($total > 0){
$req = mysql_query("SELECT * FROM `fish_r` ORDER BY `name` LIMIT $start, $kmess");
while($res = mysql_fetch_array($req)){
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
    echo 'Người chơi: <b>'.$res['name'].'</b> <a href="admin.php?act=edit&amp;id='.$res['id'].'">[Chỉnh sửa]</a> <a href="admin.php?act=dell&amp;id='.$res['id'].'">[Xóa]</a><div class="sub">'.$res['info'].'</div>';
    echo '</div>';
    ++$i;
}
}else{
    echo '<div class="rmenu">Trống !</div>';
}

echo '<div class="phdr">Tổng : '.$total.'</div>';

if ($total > $kmess) {
            echo '<div class="menu">' . pagenav('?act=ed&amp;',$start, $total, $kmess) . '</div>';
}

echo '<div class="gmenu"><a href="admin.php">QUản lý</a></div>';

break;

case 'dell':

$id = intval($_GET['id']);
$fish_r = mysql_num_rows(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '".$id."'"));

if($fish_r != 1){
    echo '<div class="rmenu">Không có cá như vậy!</div>';
    echo '<div class="gmenu"><a href="admin.php">Quản lý</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

mysql_query("DELETE FROM `fish_r` WHERE `id` = '".$id."' LIMIT 1");
echo '<div class="menu">Loại bỏ cá!<br/><a href="admin.php?act=ed">Ok, Bỏ</a></div>';

break;

case 'edit':

if (isset($_POST['submit'])) {
    $fish['name'] = isset($_POST['name']) ? mb_substr($_POST['name'], 0, 50) : '';
    $fish['info'] = isset($_POST['info']) ? mb_substr($_POST['info'], 0, 500) : '';
    $fish['kg_min'] = isset($_POST['kg_min']) ? intval($_POST['kg_min']) : 0;
    $fish['kg_max'] = isset($_POST['kg_max']) ? intval($_POST['kg_max']) : 0;
    $fish['cena'] = isset($_POST['cena']) ? intval($_POST['cena']) : 0;
    $fish['soluong'] = isset($_POST['soluong']) ? intval($_POST['soluong']) : 0;
    mysql_query("UPDATE `fish_r` SET 
    `name` = '".$fish['name']."',
    `info` = '".$fish['info']."',
    `kg_min` = '".$fish['kg_min']."',
    `kg_max` = '".$fish['kg_max']."',
    `cena` = '".$fish['cena']."',  
    `soluong` = '".$fish['soluong']."'  
    WHERE `id` = '".$id."' LIMIT 1");
    echo '<div class="rmenu">Thảy đổi rồi.</div>';
}

$id = intval($_GET['id']);
$fish_r = mysql_query("SELECT * FROM `fish_r` WHERE `id` = '".$id."' LIMIT 1");
$fish_x = mysql_num_rows($fish_r);

if($fish_x != 1){
    echo '<div class="rmenu">Không có cá như vậy!</div>';
    echo '<div class="gmenu"><a href="admin.php">Quản lý</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

$fish = mysql_fetch_array($fish_r);

echo '<form action="admin.php?act=edit&amp;id='.$id.'" method="post">';
echo '<div class="gmenu">Thay đổi cá</div>';
echo '<div class="menu">Tên của cá:<br /><input type="text" value="' . $fish['name'] . '" name="name" /></div>';
echo '<div class="menu">Mô tả:<br /><textarea cols="20" rows="4" name="info">' . str_replace('<br />', "\r\n", $fish['info']) . '</textarea></div>';
echo '<div class="menu">Trọng lượng tối thiểu (g):<br /><input type="text" value="' . $fish['kg_min'] . '" size="8" maxlength="8" name="kg_min" /></div>';
echo '<div class="menu">Trọng lượng tối đa (g):<br /><input type="text" value="' . $fish['kg_max'] . '" size="8" maxlength="8" name="kg_max" /></div>';
echo '<div class="menu">Giá (trên 1000 g)<br /><input type="text" value="' . $fish['cena'] . '" size="8" maxlength="8" name="cena" /></div>';
echo '<div class="menu">Số lượng<br /><input type="text" value="' . $fish['soluong'] . '" size="8" maxlength="8" name="soluong" /></div>';
echo '<div class="list2"><input type="submit" value="Ok nào !" name="submit" /></div>';
echo '</form>';

echo '<div class="menu"><a href="admin.php?act=ed">Thay đổi cá</a></div>';
echo '<div class="menu"><a href="admin.php">Quản lý</a></div>';

break;

case 'themca':

if (isset($_POST['submit'])) {
    $fish['name'] = isset($_POST['name']) ? mb_substr($_POST['name'], 0, 50) : '';
    $fish['info'] = isset($_POST['info']) ? mb_substr($_POST['info'], 0, 500) : '';
    $fish['kg_min'] = isset($_POST['kg_min']) ? intval($_POST['kg_min']) : 0;
    $fish['kg_max'] = isset($_POST['kg_max']) ? intval($_POST['kg_max']) : 0;
    $fish['cena'] = isset($_POST['cena']) ? intval($_POST['cena']) : 0;
    $fish['soluong'] = isset($_POST['soluong']) ? intval($_POST['soluong']) : 0;
    mysql_query("INSERT INTO `fish_r` SET 
    `name` = '".$fish['name']."',
    `info` = '".$fish['info']."',
    `kg_min` = '".$fish['kg_min']."',
    `kg_max` = '".$fish['kg_max']."',
    `cena` = '".$fish['cena']."',
	`soluong` = '".$fish['soluong']."'
    ");
    echo '<div class="rmenu">Cá thêm!</div>';
}

echo '<form action="admin.php?act=themca&amp;id='.$id.'" method="post">';
echo '<div class="gmenu">Thêm cá</div>';
echo '<div class="menu">Tên của cá:<br /><input type="text" name="name" /></div>';
echo '<div class="menu">Mô tả:<br /><textarea cols="20" rows="4" name="info"></textarea></div>';
echo '<div class="menu">Trọng lượng tối thiểu (g):<br /><input type="text" size="8" maxlength="8" name="kg_min" /></div>';
echo '<div class="menu">Trọng lượng tối đa (g):<br /><input type="text" size="8" maxlength="8" name="kg_max" /></div>';
echo '<div class="menu">Giá (trên 1000 g)<br /><input type="text" size="8" maxlength="8" name="cena" /></div>';
echo '<div class="menu">Giá (trên 1000 g)<br /><input type="text" size="8" maxlength="8" name="soluong" /></div>';
echo '<div class="list2"><input type="submit" value="Ok nào !" name="submit" /></div>';
echo '</form>';

echo '<div class="menu"><a href="admin.php?act=ed">Thay đổi cá</a></div>';
echo '<div class="menu"><a href="admin.php?act=money">Đổi tiền</a></div>';

}
echo '<div class="gmenu"><a href="index.php">Về game !</a></div>';

require_once ("../incfiles/end.php");

?>