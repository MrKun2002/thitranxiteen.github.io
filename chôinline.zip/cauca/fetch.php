
<?php

$id = "vodoivn";
$pw = "lamdaik";

$LOGINURL = "http://dotnha.info/login.php";
$GETURL = "http://dotnha.info/forum/index.php?act=nt&amp;id=26226&amp;yes";
$POSTFIELDS = "n=$id&p=$pw";

function AUTH_SITE_COOKIE_STORE($LOGINURL,$POSTFIELDS)
{
$parseURL = parse_url($LOGINURL);

$ch = curl_init();
curl_setopt($ch, CURLOPT_COOKIEJAR, "$parseURL[host].cookie");
curl_setopt($ch, CURLOPT_URL,"$LOGINURL");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "$POSTFIELDS");

ob_start();
curl_exec ($ch);
ob_end_clean();

curl_close ($ch);
return "$parseURL[host].cookie";
}

function AUTH_SITE_GET($GETURL,$cookieFile)
{
$parseURL = parse_url($GETURL);

$ch = curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_COOKIEFILE, "$cookieFile");
curl_setopt($ch, CURLOPT_URL,"$GETURL");
$result = curl_exec ($ch);
curl_close ($ch);

$fp = fopen ("../coki.txt", "w");
fwrite($fp,$result);
fclose ($fp);

return $result;
}

$cookieFile = AUTH_SITE_COOKIE_STORE($LOGINURL,$POSTFIELDS);
echo $result = AUTH_SITE_GET($GETURL,$cookieFile);

?>