<?php
//Việt Hóa : JohnCMSVN.COM
//--JohnCMSVN.COm - JohNCMS Việt Nam ---

define('_IN_JOHNCMS', 1);

$textl = 'Khu Sinh Thái - Giải Trí';
$headmod = "fish";
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');

if (!$user_id) {
    echo display_error('Chỉ cho thành viên đăng ký');
    require_once ('../incfiles/end.php');
    exit;
}
mysql_query("UPDATE `users` SET `can-cau` = '4' WHERE `id` = '".$datauser['id']."' LIMIT 1");
$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    mysql_query("INSERT INTO `fish` SET 
    `name` = '".$login."',
    `user_id` = '".$user_id."',
    `lvl` = '0',
    `money` = '400',
    `time` = '0',
    `vsego` = '0',
    `rand_time` = '0',
    `status` = '0',
    `loc` = '0',
    `kg` = '0',
    `sorv` = '0'
    ");
    
    mysql_query("INSERT INTO `fish_in` SET 
    `user_id` = '".$user_id."',
    `ud` = '0',
    `ud_d` = '0',
    `kr` = '0',
    `kr_d` = '0',
    `ka` = '0',
    `ka_d` = '0',
    `na` = '0',
    `na_d` = '0'
    ");
}

mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");

$res = mysql_fetch_array(mysql_query("SELECT * FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));

echo '<div class="phdr"><b>Khu Sinh Thái</b></div>';
//-- Online Topic ---//
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '4'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '4'"), 0);
$totalonline = $online_u + $online_g;
$q = @mysql_query("select * from `users` where `lastdate` > " . (time() - 300) . " AND `can-cau` = '4';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)){
$trinhtrangvip = mysql_query("select `rights` from `users` where id='" . $arr['id'] . "'");
$trinhtrangviphonnua = mysql_fetch_array($trinhtrangvip);
if($arr['id'] != $datauser['id']){
$u_on[]='<a href="../users/' . $arr['name'] . '_' . $arr['id'] . '.html"><img src="/avatar/' . $arr['id'] . '.png"></a>';
}else{
	$u_on[]='<img src="/avatar/' . $arr['id'] . '.png">';
}
}
//Keet thuc topic
echo '<div class="thanhpho">
<marquee behavior="scroll" direction="left" scrollamount="1" style="margin-top: 5px"><img src="/iconvip/may1.png"></marquee>
<marquee behavior="scroll" direction="left" scrollamount="2" style="margin-top: 10px"><img src="/iconvip/may2.png"></marquee>
';
echo '
<div class="vaocau">
<table width="100%">
<tr>
<td width="50%">
<a href="http://choionline.cf/cauca/cuahang.html"><img src="/cauca/img/shopcauca.png"></a>
</td>
<td style="padding-bottom: 20px;">
<a href="http://choionline.cf/cauca/khu.html"><img src="/cauca/img/vao.gif"/></a>
</td>
<td width="50%" style="padding-top: 20px;">
<a href="/cauca/bxh.html"><img src="/images/bxh.png" /></a>
</td>
</tr>
</table>
</div></div>

<div class="nenda">';
if ($online_u > 0){
echo implode(' ',$u_on).'';
}else{
	echo 'Trống';
}
$vsego = $res['vsego'];
echo '
</div><div class="list1"><table width="100%"><tbody><tr><td width="6%"><img class="avatarfr" src="http://choionline.cf/avatar/'.$datauser['id'].'.png" width="32" height="32" alt="">&nbsp;</td><td class="list3" width="80%"><img src="/images/online.png"><b> <font color="red">'.$datauser['name'].'</font></b><div class="sub"><div><span class="gray">Tiền: </span> <b>'.$datauser['balans'].'</b> Xu
<br/><span class="gray">Lever câu cá:</span> <b>'.$res['lvl'].'</b>
<br/>Đã đánh bắt: <b>'.round($vsego, 2).'</b> KG Cá.<br/>
<img src="/nongtrai/img/icon/warehouse.png" width="14px"> <a href="/cauca/nhakho.html">Kho Để Cá</a>
</div></div></td></tr></tbody></table></div>';
$res2 = mysql_query("SELECT * FROM `fish_tb` ORDER BY `id` DESC LIMIT 6");
while ($post2 = mysql_fetch_array($res2)){
$truycapuser = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$post2["user_id"]."'"));
$thongtinca = mysql_fetch_array(mysql_query("SELECT * FROM `fish_r` WHERE `id` = '".$post2["id_fish"]."'"));
	echo '<div class="list1"><b>- '.$truycapuser['name'].'</b> vừa câu được một con <b>'.$thongtinca['name'].'</b> có trọng lượng <b>'.$post2['kg'].'</b> KG</div>';
}
if($rights == '9'){
    echo '<br/><span class="red"><b><a href="admin.php">Quản lý</a></b></span>';
}

echo '</div>';

require_once ("../incfiles/end.php");

?>