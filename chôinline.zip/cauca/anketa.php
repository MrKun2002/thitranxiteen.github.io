<?php
//Việt Hóa : JohnCMSVN.COM
//--JohnCMSVN.COm - JohNCMS Việt Nam ---
define('_IN_JOHNCMS', 1);

$textl = 'Câu Cá :D';
$headmod = "fish";
require_once ('../incfiles/core.php');
require_once ('../incfiles/head.php');

if (!$user_id) {
    echo display_error('Dành cho thành viên nhá !');
    require_once ('../incfiles/end.php');
    exit;
}


$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    header('Location: index.php');
    exit;
}

mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");



$id = intval($_GET['id']);
$res = mysql_query("SELECT * FROM `fish` WHERE `user_id` = '".$id."' LIMIT 1");
$rez = mysql_num_rows($res);
if($rez != 1){
    echo '<div class="rmenu">Lỗi! Không có người dùng như vậy.</div>';
    echo '<div class="gmenu"><a href="/cauca/">Trở về khu sinh thái</a></div>';
    require_once ('../incfiles/end.php');
    exit;
}

$req = mysql_fetch_array($res);
echo '<div class="phdr"><b>THÔNG TIN CHI TIẾT '.$req['name'].'</b></div>';
$vsego = $req['vsego'];
echo '<div class="list1">
Cá đánh bắt: '.$vsego.' Kilogam Cá<br/>
Cấp bậc: '.$req['lvl'].'<br/>
</div>';

$req2 = mysql_fetch_array(mysql_query("SELECT * FROM `fish_in` WHERE `user_id` = '".$id."' LIMIT 1"));

echo '<div class="menu"><a href="/cauca/bxh.html">Quay Lại Xếp hạng</a></div>';
echo '<div class="gmenu"><a href="/cauca/">Về khu sinh thái</a></div>';

require_once ("../incfiles/end.php");

?>