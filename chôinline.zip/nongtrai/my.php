<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Trang trại của tôi!';
if(isset($user_id)){
if(isset($_GET['add_ok']))msg('Mở đất!');
if(isset($_GET['udobr_ok']))msg('Bón phân thành công!');
if(isset($_GET['cuoc_ok']))msg('Bạn đã cuốc đi một ô đất, gieo gì tiếp vào đó nào!');
if(isset($_GET['add_no']))msg('Cấp độ của bạn phải nhỏ hơn 50 mới mua được đất nhé!');
if(isset($_GET['tuoi_ok']))msg('Tưới nước thành công!');
if(isset($_GET['thuhoach_ok'])){
	if(empty($_GET['thuhoach_ok'])){
		msg('Thu hoạch thành công!');
	}else{
		$so_qua = intval($_GET['thuhoach_ok']);
		msg('Thu hoạch thành công và bạn nhận được '.$so_qua.' chiếc kẹo');
	}
}
if(isset($_GET['thuhoach_no']))msg('Thu hoạch không thành công!');
if(isset($_GET['gieohat_ok']))msg('Gieo hạt thành công!');
if(isset($_GET['gieohat_no']))msg('Gieo hạt không thành công!');
if(isset($_GET['hay_tich']))msg('Hãy chọn cây trồng!');
$tinhgiaodat = $datauser['kinh-nghiem'] + 5000;
$kao=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_gr` WHERE `id_user` = '$user_id'"),0);
if(isset($_GET['gr_add']) && $datauser['balans'] >= $tinhgiaodat && $kao < 55)
{
	if($datauser['level'] <=50){
	mysql_query("UPDATE `users` SET `balans` = `balans`- '$tinhgiaodat' WHERE `id` = $user_id LIMIT 1");
	$q="UPDATE `users` SET `balans` = `balans`- '$tinhgiaodat' WHERE `id` = $user_id LIMIT 1";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/my.php','".date('d-m-Y  h:i:s A')."')");
	mysql_query("UPDATE `users` SET `kinh-nghiem` = `kinh-nghiem` + '5000' WHERE `id` = $user_id LIMIT 1");
	mysql_query("INSERT INTO `fermer_gr` (`semen`, `id_user`) VALUES  ( '0', '".$user_id."') ");
	header('Location: /nongtrai/?add_ok');
	}else{header('Location: /nongtrai/?add_no');}
}


if(isset($_GET['add'])){
echo '<div class="gmenu">';
echo "Chi phí của một ô đất là ".$tinhgiaodat." xu";
echo "<form method='post' action='?gr_add'>\n";
echo "<input type='submit' name='save' value='Mua!' />\n";
echo "</form>\n";
echo '</div>';
}
else{
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_gr` WHERE `id_user` = '$user_id'"),0);
$k_page = ceil($k / $SET['p_str']);
$page = page();
$start=$SET['p_str']*$page-$SET['p_str'];

$res = mysql_query("select * from `fermer_gr` WHERE `id_user` = '$user_id'  LIMIT $start, $SET[p_str];");
echo'
<div class="dat">
<a href="/nongtrai/nhakho.html"><img src="/icon/nhakho.png" alt="icon" style="vertical-align: -10%;"></a>
<a href="/nongtrai/nhabep/"><img src="/icon/nhabep.png" alt="icon" style="vertical-align: -10%;"></a>
';
if(time() > $datauser['tgcaykhe'] + 7200){
echo '<a href="/nongtrai/khe'.$datauser['id'].'#menu"><img src="/images/caykhechin.png" width="60px"/></a>';
}else{
	echo ' <a href="/nongtrai/khe'.$datauser['id'].'#menu"><img src="/images/caykhe.png" width="60px"></a><br>';
}
echo'<div class="cola">
';
if($k >= 10){
echo '<form name="autofarm" action="/nongtrai/autofarm.php" method="post">';
}
while ($post = mysql_fetch_array($res)){
if($k >= 10){
echo '<span style="display: inline-block; text-align: center; padding-right: 5px;">';
}
$semen=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1"));
$p = mysql_fetch_array(mysql_query("select * from `fermer_gr` WHERE  `id` = '$post[id]'  LIMIT 1"));
if($p['semen'] != 0)
{
$pt= $semen['rand2'];
if($post['woter']==0)$pt=floor($pt/2);
mysql_query("UPDATE `fermer_gr` SET `kol` = $pt WHERE `id` = '$post[id]' LIMIT 1");
}

if($post['semen']==0){$name_gr='Gieo hạt';}else{$name_gr=$semen['name'];}

$vremja=$post['time']-$time;
$timediff=$vremja;
$oneMinute=60;
$oneHour=3600;
$oneDay=86400;
$dayfield=floor($timediff/$oneDay);
$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour);
$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute);
$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute));
if($dayfield>0)$day=$dayfield.'ngày. ';
else $day='';
if($hourfield>0)$hour=$hourfield.'giờ. ';
else $hour='';
if($minutefield>0)$min=$minutefield.'phút. ';
else $min='';
if($post['semen']!=0 && $time>$post['time'] && $post['kol']==0)
{
$pt= $semen['rand2'];
mysql_query("UPDATE `fermer_gr` SET `kol` = $pt WHERE `id` = $int LIMIT 1");
}
	$farmname = mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1"));
	$tinhgiaohat = $farmname[time] / 4;
	$tinhgiaohat2 = (int)$tinhgiaohat;
	$tinhthoigian = $post[time] - $time;
	if($post[semen] > 0){
		if($tinhthoigian >= ($tinhgiaohat2*3)){
			if($post['semen']!= 13)
			echo '
			<a href="/nongtrai/gieohat.html?id='.$post['id'].'#menu"><img src="/nongtrai/img/product/gieohat.png" alt="*"/></a>
			';
			
			echo '
			';
		}else if($tinhthoigian < ($tinhgiaohat2*3)){
			if($tinhthoigian >= ($tinhgiaohat2*2)){
				if($post['semen']!= 13)
				echo '
				<a href="/nongtrai/gieohat.html?id='.$post['id'].'#menu"><img src="/nongtrai/img/product/'.$post['semen'].'.png" alt="*"/></a>';
			}else if($tinhthoigian < ($tinhgiaohat2*2)){
				if($tinhthoigian >= ($tinhgiaohat2)){
					if($post['semen']!= 13)
					echo '
					<a href="/nongtrai/gieohat.html?id='.$post['id'].'#menu"><img src="/nongtrai/img/product/'.$post['semen'].'-uong.png" alt="*"/></a>';
				}else{
					if($post['semen']!= 13)
					echo '
					<a href="/nongtrai/gieohat.html?id='.$post['id'].'#menu"><img src="/nongtrai/img/product/'.$post['semen'].'-chin.png" alt="*"/></a>';
				}
			}
		}
	}else{
		echo '<a href="/nongtrai/gieohat.html?id='.$post['id'].'"><img src="/nongtrai/img/product/0.png" alt="*"/></a> ';
		if($post['semen']!=0)
		echo "".$time_1."";
	}
	if($k >= 10){
		echo '<p style="margin-top: -2px;"><input type="checkbox" name="caytrong[]" id="autofarm" value="'.$post['id'].'"/></p>';
		echo '</span>';
		}
}
if(isset($_GET['add'])) echo"&laquo; <a href='../nongtrai'>Nông trại</a>";
else echo "<a href='/nongtrai/?add'><img src='/icon/muadat.png' alt='icon' style='vertical-align: 0px;'></a>";
$dog1 = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_dog` WHERE `id_user` = '$datauser[id]'"));

if($dog1['time'] < time()){
	mysql_query("UPDATE `users` SET `tienxu` = '0' WHERE `id` = '".$datauser["id"]."' LIMIT 1");
	if(time() > $dog1['time']){
	mysql_query("DELETE FROM `fermer_dog` WHERE `id_user` = '".$datauser["id"]."'");
	}
	
}else{
	mysql_query("UPDATE `users` SET `tienxu` = '1' WHERE `id` = '".$datauser["id"]."' LIMIT 1");
	}
if($datauser['tienxu'] >= 1)
{
	echo '<span style="padding-left: 50px;"><img src="/images/thucung/7.png"></span>
	';
}
echo '<img src="/avatar/' . $datauser['id']. '.png" style="z-index: 1;"/>';
//echo '<div class="cola">';

//-- Mod thu hoach tung vat nuoi --//
$vatnuoiga = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'"));
// Mod hien thi ga //
$kiemtra50 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'"), 0);
if($kiemtra50 == 0){
	mysql_query("DELETE FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '2'");
}
if($vatnuoiga['vatnuoi'] == 50){
$res1 = mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '50'");
$thuhoach = mysql_result($res1, 0);
if($thuhoach > 0){
	echo '<a href="/nongtrai/vatnuoi/?thuhoach=50"><img src="/nongtrai/vatnuoi/img/trung.png"></a>';
}else{
echo '<img src="/nongtrai/vatnuoi/img/oga.png">';
}
}
//ket thuc thu hoach //

echo "</div>";
echo '<div class="conduong"></div><div class="cola2"><div class="chuong">';
// Mod hien thi vat nuoi
$res23 = mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."'");
while($post = mysql_fetch_array($res23)){
	$tinhname = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_name` WHERE `id` = '".$post['vatnuoi']."'"));
	// cho vat nuoi mang
	$tinhchoan_mang = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'"));
	$demchoan_mang = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'"), 0);
	$timechoan_mang_ht = time()-$tinhchoan_mang['timechoan'];
	//cho vat nuoi an dat
	$tinhchoan_radat = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '2'"));
	$demchoan_radat = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '2'"), 0);
	$timechoan_radat_ht = time()-$tinhchoan_radat['timechoan'];
	//cho ca an
	$tinhchoan_ca = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '3'"));
	$demchoan_ca = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '3'"), 0);
	$timechoan_ca_ht = time()-$tinhchoan_ca['timechoan'];
	// END
	$tinhtimec = $tinhname['timechet'] + $post['time'];
	$tinhtimel = $tinhname['timelon'] + $post['time'];
	$tinhtimeth = $post['timethuhoach'] + $tinhname['time'];
	$tinhtimehtc = $tinhtimec - time();
	$tinhtimehtl = $tinhtimel - time();
	$timeht = time();
	if($tinhname['id'] != 50 && $tinhname['id'] != 54){
	// mod vat nuoi trong chuong
	$random = rand(15,70);
	$random2 = rand(15,70);
	if($tinhtimehtl < 0){
	echo ' <a href="/nongtrai/vatnuoi/?id='.$post['id'].'#menu"><img src="/nongtrai/vatnuoi/img/'.$post['vatnuoi'].'.gif" style="position: absolute;vertical-align: 0px;margin:'.$random2.'px 0 0 '.$random.'px;"></a> ';
	}else{
	echo ' <a href="/nongtrai/vatnuoi/?id='.$post['id'].'#menu"><img src="/nongtrai/vatnuoi/img/'.$post['vatnuoi'].'-con.gif" style="position: absolute;vertical-align: 0px;margin:'.$random2.'px 0 0 '.$random.'px;"></a> ';
	//ket thuc
	}
		if($tinhtimehtc < 0){
			mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."'");
			$timkiemvatnuoichuong52 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '$user_id' AND `vatnuoi` = '52'"), 0);
			$timkiemvatnuoichuong51 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '$user_id' AND `vatnuoi` = '51'"), 0);
			$timkiemvatnuoichuong53 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '$user_id' AND `vatnuoi` = '53'"), 0);
			if($timkiemvatnuoichuong52 == 0 && $timkiemvatnuoichuong51 == 0 && $timkiemvatnuoichuong53 == 0){
			mysql_query("DELETE FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'");
			}
		}
		if($tinhtimehtl < 0 && ($post['timethuhoach'] == 0 || $timeht >= $tinhtimeth)){
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '1' WHERE `id` = '".$post["id"]."'");
		}
		if($timechoan_mang_ht >= 86400 && $demchoan_mang != 0){
			mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."'");
			mysql_query("DELETE FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'");
		}
		if($demchoan_mang == 0){
			$tinhtimemua = time() - $post['time'];
			if($tinhtimemua >= 86400){
				mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."'");
			}
		}
	}elseif($tinhname['id'] == 54){
	
		// mod ca
		$random = rand(340,410);
		$random2 = rand(15,70);
		if($tinhtimehtl < 0){
		echo ' <a href="/nongtrai/vatnuoi/?id='.$post['id'].'#menu"><img src="/nongtrai/vatnuoi/img/'.$post['vatnuoi'].'.gif" style="position: absolute;vertical-align: 0px;margin:'.$random2.'px 0 0 '.$random.'px;"></a> ';
		}else{
		echo ' <a href="/nongtrai/vatnuoi/?id='.$post['id'].'#menu"><img src="/nongtrai/vatnuoi/img/'.$post['vatnuoi'].'.gif" style="position: absolute;vertical-align: 0px;margin:'.$random2.'px 0 0 '.$random.'px;"></a> ';
		//ket thuc
		}
		if($tinhtimehtc < 0){
			
			mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."' AND `id_user` = '$user_id'");
			$timkiemvatnuoica = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '$user_id' AND `vatnuoi` = '54'"), 0);
			if($timkiemvatnuoica == 0){
			mysql_query("DELETE FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '3'");
			}
		}
		if($tinhtimehtl < 0 && ($post['timethuhoach'] == 0 || $timeht >= $tinhtimeth)){
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '1' WHERE `id` = '".$post["id"]."'");
		}
		if($timechoan_ca_ht >= 86400 && $demchoan_ca != 0){
			mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."'");
			mysql_query("DELETE FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '3'");
		}
		if($demchoan_ca == 0){
			$tinhtimemua = time() - $post['time'];
			if($tinhtimemua >= 86400){
				mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."'");
			}
		}
		
	}else{
		//mod vat nuoi ngoai chuong
		$random = rand(400,1);
		$random2 = rand(-80,-100);
		if($tinhtimehtl < 0){
		echo ' <a href="/nongtrai/vatnuoi/?id='.$post['id'].'#menu"><img src="/nongtrai/vatnuoi/img/'.$post['vatnuoi'].'.gif" style="position: absolute;vertical-align: 0px;margin:'.$random2.'px 0 0 '.$random.'px;"></a> ';
		}else{
		echo ' <a href="/nongtrai/vatnuoi/?id='.$post['id'].'#menu"><img src="/nongtrai/vatnuoi/img/'.$post['vatnuoi'].'-con.gif" style="position: absolute;vertical-align: 0px;margin:'.$random2.'px 0 0 '.$random.'px;"></a> ';
		}
		if($tinhtimehtc < 0){
			mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."'");
			$timkiemvatnuoiga = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '$user_id' AND `vatnuoi` = '50'"), 0);
			if($timkiemvatnuoiga == 0){
			mysql_query("DELETE FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '2'");
			}
		}
		if($tinhtimehtl < 0 && ($post['timethuhoach'] == 0 || $timeht >= $tinhtimeth) && $tinhtimehtc > 0){
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '1' WHERE `id` = '".$post["id"]."'");
		}
		if($timechoan_radat_ht >= 86400 && $demchoan_radat != 0){
			mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."'");
			mysql_query("DELETE FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '2'");
		}
		if($demchoan_radat == 0){
			$tinhtimemua = time() - $post['time'];
			if($tinhtimemua >= 86400){
				mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '".$post["id"]."'");
			}
		}
	}
}
// mod mang an khi co vat nuoi trong chuong
$kiemtra51 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '51'"), 0);
$kiemtra52 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'"), 0);
$kiemtra53 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'"), 0);
if($kiemtra51 == 0 && $kiemtra52==0 && $kiemtra53 == 0){
//mod xoa mang an
	mysql_query("DELETE FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'");
}else{
//ket thuc
$vatnuoilon = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'"));
// Mod hien thi mang an vat nuoi trong chuong //
	$timechoan = $vatnuoilon['timechoan']+7200;
	$tinhtime = $timechoan - time();
	if($tinhtime <= 0){
	echo '<a href="/nongtrai/vatnuoi/?choan=1"><img src="/nongtrai/vatnuoi/img/mang.png" style="position: absolute;vertical-align: 0px;margin:15px 0 0 108px"></a>';
	}else{
	echo '<a href="/nongtrai/vatnuoi/?choan=1"><img src="/nongtrai/vatnuoi/img/mang2.png" style="position: absolute;vertical-align: 0px;margin:15px 0 0 108px"></a>';
	}
}
// ket thuc hien thi cho an //
//mod hien thi sua bo //
$vatnuoibo = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'"));
// Mod hien thi sua bo //
if($vatnuoibo['vatnuoi'] == 52){
$res1 = mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '52'");
$thuhoach = mysql_result($res1, 0);
if($thuhoach > 0){
	echo '<a href="/nongtrai/vatnuoi/?thuhoach=52"><img src="/nongtrai/vatnuoi/img/suabo.png" style="position: absolute;vertical-align: 0px;margin:80px 0 0 125px"></a>';
}else{
echo '<img src="/nongtrai/vatnuoi/img/xodung.png" style="position: absolute;vertical-align: 0px;margin:80px 0 0 125px">';
}
}
//ket thuc//
//mod hien thi long cuu //
$vatnuoibo = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'"));
//mod hien thi long cuu //
if($vatnuoibo['vatnuoi'] == 53){
$res1 = mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '53'");
$thuhoach = mysql_result($res1, 0);
if($thuhoach > 0){
	echo '<a href="/nongtrai/vatnuoi/?thuhoach=53"><img src="/nongtrai/vatnuoi/img/longcuu.png" style="position: absolute;vertical-align: 0px;margin:80px 0 0 100px"></a>';
}else{
echo '<img src="/nongtrai/vatnuoi/img/mangcuu.png" style="position: absolute;vertical-align: 0px;margin:80px 0 0 100px">';
}
}
//ket thuc//
echo '</div>';
echo '<div class="hoca"></div>';
echo '</div>';
echo '<div class="clear"></div>';
echo "</div>";
if($k >= 10){
echo '<div class="list5" style="text-align: center;">';
echo '<br/><input type="submit" name="tuoinuoc" value="Tưới nước"/>';
echo '<input type="submit" name="thuhoach" value="Thu Hoạch"/>';
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '$user_id'"),0);
if($k!=0){
$res = mysql_query("select * from `fermer_sclad` WHERE `id_user` = '$user_id' "); 
echo '<select name="sadit">';
while ($post = mysql_fetch_array($res)){
$semen=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1")); 
$name_gr=$semen['name'];
if($semen['id'] != 13 && $semen['id'] != 50 && $semen['id'] != 51 && $semen['id'] != 52 && $semen['id'] != 53 && $semen['id'] != 54){
	echo "<option value='".$post['id']."'>".$name_gr." [".$post['kol']."]</option>";
}
}
echo "</select>";
echo "<input type='submit' name='gieohat' value='Gieo hạt' />\n";
}else{
echo '
<select name="cad" disabled="disabled" ><br />
<option value="0" selected="selected">Không có hạt giống nào!</option>
</select>';
}

echo '</form>';
echo '</div>';
}
if($datauser['status'] != ""){
echo '<div class="rmenu" style="font-size: 17px"> '.$datauser['status'].'</div>';
echo '<a name="menu"></a>';
}
if ($k_page>1)
str('/nongtrai/?',$k_page,$page); // ham page
}
echo "</div>";
}else{
msg('Vui lòng đăng nhập!');
}
?>