<?php
$time = time();
if($user_id){
include 'str.php';

$dog = mysql_result(mysql_query("select count(*) from `fermer_dog` WHERE  `id_user` = '1'  LIMIT 1"),0);
if($dog==0){
mysql_query("INSERT INTO `fermer_dog` (`id_user`,`time`) VALUES  ($user_id,NULL) ");
$q="INSERT INTO `fermer_dog` (`id_user`,`time`) VALUES  ($user_id,NULL) ";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}
//$post = mysql_result(mysql_query("select count(*) from `fermer_gr` WHERE  `id_user` = '{$user_id}'  LIMIT 1"),0);
//if($post<5){
//mysql_query("INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '1') ");
//mysql_query("INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '1') ");
//mysql_query("INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '1') ");
//mysql_query("INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '1') ");
//mysql_query("INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '1') ");
//}
}
$SET = mysql_fetch_assoc(mysql_query("SELECT * FROM `ferma_set`"));

function msg($t){
echo '<div class="mainblok"><div class="rmenu" align="center">'.$t.'</div></div>';
}
function err(){
global $err;
if (isset($err)){
if (is_array($err)){
foreach ($err as $key=>$value) {
echo "<div class='rmenu'>$value</div>\n";}}
else echo "<div class='rmenu'>$err</div>\n";}}function page() {
global $k_page;
if (isset($_GET['page'])) {
if ($_GET['page'] == 'end') $page = $k_page;
else $page = abs(intval($_GET['page']));
}
else $page = 1;
if ($page > $k_page) $page = $k_page;
return $page;
}
function k_page($k_post=0,$k_p_str=10){
if ($k_post!=0){$v_pages=ceil($k_post/$k_p_str);return $v_pages;}

else return 1;}

function str($link='?',$k_page,$page){
if($k_page==1 OR isset($_GET['from'])) echo'<div class="ferma_menu">Trang.: <re>'.$page.' Của '.$k_page.'</re> ';
else echo'<div class="ferma_menu">Trang.: '.$page.' Của '.$k_page.' ';
if ($page != 1 ) echo "/ <a class='re' href=\"".$link."page=".($page-1)."\">Trang trước.</a> ";
if ($page != $k_page) echo "/ <a class='re' href=\"".$link."page=".($page+1)."\">Trang sau.</a>";
echo '</div>';
}
$time = time();
// Nhiệm vụ Farm
function nhiemvu($nongsan,$id_user_nv){
	$nv_nongsan = mysql_query("SELECT * FROM `gamemini_nhiemvu` WHERE `loainv` = 'nongsan'");
	while($w_nongsan = mysql_fetch_array($nv_nongsan)){
		if($w_nongsan[nongsan] == $nongsan){
			echo 'text';
			$timkiem_nv = mysql_result(mysql_query("SELECT COUNT(*) FROM `gamemini_nhiemvu_nhan` WHERE `user_id` = '{$id_user_nv}' AND `nhiemvu_id` = '{$w_nongsan[id]}'"), 0);
			if($timkiem_nv > 0){
				mysql_query("UPDATE `gamemini_nhiemvu_nhan` SET `tienhanh` = `tienhanh`+ '1' WHERE `user_id` = '{$id_user_nv}' AND `nhiemvu_id` = '{$w_nongsan[id]}'");
				echo 'Text';
			}
			echo $timkiem_nv;
		}
	}
}
?>