<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Hàng xóm!';
require('../incfiles/head.php');
if($user_id){
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `users`"),0);
$k_page = ceil($k / $kmess);
$page = page();
$start=$kmess*$page-$kmess;
# пусто
echo '<div class="mainblok"><div class="phdr"><b>Hàng xóm</b></div>';
if ($k==0)
{
echo '<div class="rmenu"> Không có thành viên!</div>';
}
else{
$q=mysql_query("SELECT `id`,`name`,`fermer_oput`,`fermer_level` FROM `users` ORDER BY `fermer_oput`,`fermer_level` DESC LIMIT $start, $kmess");
while ($ank = mysql_fetch_assoc($q)){
if (file_exists(('../avatar/'.$ank['id'].'.png'))) {
echo '<img src="../avatar/'.$ank['id'].'.png"width="50"height="50"alt="'.$ank['id'].'"/>';
} else {
echo '<img src="../avatar/'.$ank['id'].'.png"width="50"height="50"alt="'.$ank['id'].'"/>';
}
echo '<div class="list1">
 <a href="nongtrai.html?id='.htmlspecialchars($ank['id']).'">'.htmlspecialchars($ank['name']).'</a><br/>
<img src="img/icon/rating.png" alt="*" /> Exp: '.(int)$ank['fermer_oput'].'
<br/>
Level: '.(int)$ank['fermer_level'].'</div>';
}}
if ($k_page > 1){
	echo '</div><div class="rmenu" align="center">';
	str("hangxom.html?",$k_page,$page); // Trang dau ra
	echo '</div>';
}
echo "<div class='phdr'>";
echo "&raquo; <a href='/nongtrai/'>Nông trại</a>";
echo "</div></div>";
}else{
msg('Vui lòng đăng nhập!');
}
require('../incfiles/foot.php');
?>
