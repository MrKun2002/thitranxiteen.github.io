<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Hàng xóm!';
require('../incfiles/head.php');
$int=intval($_GET['id']);
$timkiem = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_gr` WHERE `id_user` = '$int'"), 0);
if($timkiem != 0){
if(!$user_id){
msg('Vui lòng đăng nhập!');
}elseif($user_id != $int){

# ham Kiem tra tinh xac thuc
if(!$int){
echo '<div class="ferma_menu">Thông tin!</div>';
echo "<div class='ferma_rekl'>";
echo "&laquo; <a href='hangxom.html'>Hàng xóm</a><br/>";
echo "&laquo; <a href='/nongtrai/'>Nông trại</a><br/>";
echo "</div>";
require('../incfiles/end.php');
exit;
}
# Kiem tra cac item
$sql=mysql_query("SELECT `id` FROM `users` WHERE `id`='$int' ");
$row=mysql_fetch_assoc($sql);
if(!mysql_num_rows($sql)){
echo '<div class="ferma_menu">Không tồn tại người chơi này</div>';
echo "<div class='ferma_rekl'>";
echo "&laquo; <a href='hangxom.html'>Hàng xóm</a><br/>";
echo "&laquo; <a href='/nongtrai/'>Nông trại</a><br/>";
echo "</div>";
require('../incfiles/head.php');
exit;
}
if($int==$user['id'])header('Location: /nongtrai/');
$ank=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='$int' LIMIT 1"));
if(isset($_GET['vor'])){
$vor=intval($_GET['vor']);
if($user_id) {
# Ham xac thuc
if(!$vor){
echo '<div class="ferma_menu">Chưa có người chơi nào!</div>';
echo "<div class='ferma_rekl'>";
echo "&laquo; <a href='hangxom.html'>Hàng xóm</a><br/>";
echo "&laquo; <a href='/nongtrai/'>Nông trại</a><br/>";
echo "</div>";
require('../incfiles/end.php');
exit;
}
# Kiem tra cac item
$sql=mysql_query("SELECT `id` FROM `fermer_gr` WHERE `id`='$vor' ");
$row=mysql_fetch_assoc($sql);
if(!mysql_num_rows($sql)){
echo '<div class="ferma_menu">Không có ô đất đó đâu!</div>';
echo "<div class='ferma_rekl'>";
echo "&laquo; <a href='hangxom.html'>Hàng xóm</a><br/>";
echo "&laquo; <a href='/nongtrai/'>Nông trại</a><br/>";
echo "</div>";
require('../incfiles/end.php');

exit;
}

$gr = mysql_fetch_array(mysql_query("select * from `fermer_gr` WHERE `id` ='$vor' "));
$semen = mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE `id` = '$gr[semen]' "));
$qi = mysql_fetch_assoc(mysql_query("SELECT * FROM `fermer_vor` WHERE `id_user` = '$user_id'  AND `gr` = '$vor' LIMIT 1"));
$time1 = time();
if($datauser[fermer_oput] >= 200){
if($qi['time']<$time1){
$rand1=floor($semen['rand1']/10);
$rand2=floor($semen['rand2']/10);
$rand=rand($rand1,$rand2);
$dog = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_dog` WHERE `id_user` = '$int'"));
if($dog['time'] < $time){
if($gr[time]-time() <= 0){
$t=$time+86400;
mysql_query("INSERT INTO `fermer_vor` (`id_user` , `gr`, `time`) VALUES  ('".$user_id."', '".$vor."', '".$t."') ");
$q="INSERT INTO `fermer_vor` (`id_user` , `gr`, `time`) VALUES  ('".$user_id."', '".$vor."', '".$t."') ";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
mysql_query("UPDATE `users` SET `fermer_oput` = `fermer_oput`- '200' WHERE `id` = $user_id LIMIT 1");
$q="UPDATE `user` SET `fermer_oput` = `fermer_oput`- '200' WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
if($gr['kol']>$rand){
mysql_query("UPDATE `fermer_gr` SET `kol` = `kol`- $rand WHERE `id` = $vor LIMIT 1");
$q="UPDATE `fermer_gr` SET `kol` = `kol`- $rand WHERE `id` = $vor LIMIT 1";

mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
$remils = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `mua` = '1' AND `id_user` = '$user_id' AND `semen` = '$gr[semen]'"),0);
if($remils>0) mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol`+ '".$rand."' WHERE `mua` = '1' AND `id_user` = $user_id AND `semen` = '$gr[semen]' LIMIT 1");
else mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`,`mua`) VALUES  ('".$rand."', '".$gr['semen']."', '".$user_id."','1') ");
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Zê! Bạn đã ăn chộm được rồi.. Quả này giàu to!!</div>';
}elseif($gr['kol'] <= $rand1){
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Nhà chủ đã bị trộm gần hết rồi, bạn để lại một ít cho nhà chủ sống</div>';
}
$se=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$gr[semen]'  LIMIT 1"));
}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Cây chưa chín không thể chộm đâu :D</div>';
}
} else {
$randumdog = $datauser[balans]/2;
$rand=rand(1,$randumdog);
	if($datauser[balans] > $rand){
		mysql_query("UPDATE `users` SET `balans` = `balans` - $rand WHERE `id` = $user_id LIMIT 1");
		$q="UPDATE `users` SET `balans` = `balans` - $rand WHERE `id` = $user_id LIMIT 1";
		mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/fermers_gr.php','".date('d-m-Y  h:i:s A')."')");
		//mysql_query("UPDATE `users` SET `balans` = `balans` + $rand WHERE `id` = $ank[id] LIMIT 1");
		//$q="UPDATE `users` SET `balans` = `balans` + $rand WHERE `id` = $ank[id] LIMIT 1";
		//mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/fermers_gr.php','".date('d-m-Y  h:i:s A')."')");
		echo '<div class="list1">Bạn vừa bị một con chó cắn rách quần, bạn bỏ chạy rất nhanh nhưng đánh rơi mất '.$rand.' Xu!</div>';
		echo "<div class='rmenu'>";
		echo "&laquo; <a href='hangxom.html'>Hàng xóm</a><br/>";
		echo "&laquo; <a href='/nongtrai/'>Nông trại</a><br/>";
		echo "</div>";
		require('../incfiles/foot.php');

		exit;
	}else if($datauser[balans] <= $rand){
		echo '<div class="list1">Bạn vừa bị một con chó cắn. Nhưng mà không có mất xu nào. Về tiêm phòng đi nhé!</div>';
		echo "<div class='rmenu'>";
		echo "&laquo; <a href='hangxom.html'>Hàng xóm</a><br/>";
		echo "&laquo; <a href='/nongtrai/'>Nông trại</a><br/>";
		echo "</div>";
		require('../incfiles/foot.php');
	}

}
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã ăn trộm rồi! Trộm nữa là chủ nhà phát hiện ra đấy tìm cây khác đi!!</div>';}
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ kinh nghiệm đi có thể ăn chộm ti!!</div>';
}
}
}

$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_gr` WHERE `id_user` = '".$int."'"),0);
$k_page = ceil($k / $SET['p_str']);
$page = page();
$start=$SET['p_str']*$page-$SET['p_str'];
$res = mysql_query("select * from `fermer_gr` WHERE `id_user` =  '".$int."' LIMIT $start, $SET[p_str];");
$jun2 = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '$int'"));

//echo ' '.$jun6['time'].'  ';
echo'
<div class="phdr" style="font-weight: bold;"> Nông Trại Của '.$jun2['name'].'</div>
<div class="dat"><img src="/icon/farm.png" alt="icon" style="vertical-align: 0px;"> <a href="cuahang.html"><img src="/icon/cuahangfarm.png" alt="icon" style="vertical-align: -7px;"></a><br>
<div class="cola">';
while ($post = mysql_fetch_array($res)){
$p = mysql_fetch_array(mysql_query("select * from `fermer_gr` WHERE  `id` = '$post[id]'  LIMIT 1"));
if($p['semen']!=0 && $time>$p['time'] && $p['kol']==0)
{
$pt=rand($semen['rand1'],$semen['rand2']);
if($post['woter']==0)$pt=floor($pt/2);
mysql_query("UPDATE `fermer_gr` SET `kol` = $pt WHERE `id` = '$post[id]' LIMIT 1");
$q="UPDATE `fermer_gr` SET `kol` = $pt WHERE `id` = '$post[id]' LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}
$semen=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1"));
if($post['semen']==0){
$name_gr='';
//echo '<img src="img/product/'.$post['semen'].'.png" alt="*"/> ';
}else{$name_gr=$semen['name'];}
$qi1 = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vor` WHERE `id_user` = '$user_id'  AND `gr` = '$post[id]' LIMIT 1"));
$jun1 = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '$int'"));

if($post['semen'] > 0){
//echo "Sản lượng: ".$post['kol']."";
$qi = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vor` WHERE `id_user` = '$user_id'  AND `gr` = '$post[id]' LIMIT 1"));
$jun = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '$int'"));
	$farmnamegr = mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1"));
	$tinhgiaohatgr = $farmnamegr[time] / 4;
	$tinhgiaohatgr2 = (int)$tinhgiaohatgr;
	$tinhthoigiangr = $post[time] - $time;

		if($tinhthoigiangr >= ($tinhgiaohatgr2*3)){
			if($post['semen']!= 13)
			echo '<img src="img/product/gieohat.png" alt="*"/> ';
		}else if($tinhthoigiangr < ($tinhgiaohatgr2*3)){
			if($tinhthoigiangr >= ($tinhgiaohatgr2*2)){
				if($post['semen']!= 13)
				echo '<img src="img/product/'.$post['semen'].'.png" alt="*"/> ';
			}else if($tinhthoigiangr < ($tinhgiaohatgr2*2)){
				if($tinhthoigiangr >= ($tinhgiaohatgr2)){
					if($post['semen']!= 13)
					echo '<img src="img/product/'.$post['semen'].'-uong.png" alt="*"/> ';
				}else if($tinhthoigiangr < ($tinhgiaohatgr2)){
					if($tinhthoigiangr > 0){
						if($post['semen']!= 13)
						echo '<img src="img/product/'.$post['semen'].'-uong.png" alt="*"/> ';
					}else if($tinhthoigiangr <= 0){
						if($post['semen']!= 13)
						echo '<a href="?id='.$int.'&amp;vor='.$post['id'].'"><img src="img/product/'.$post['semen'].'-chin.png" alt="*"/></a> ';
					}
				}
			}
		}
//echo '';
}
else if($post['semen'] == 0){
echo '<img src="img/product/0.png" alt="*"/> ';}
}

$jun2 = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '$int'"));
if ($k_page>1)str('nongtrai.html?id='.$int.'&',$k_page,$page);
//ket thuc //
echo '</div></div>';
if($jun2['status'] != ""){
echo '<div class="rmenu" style="font-size: 17px"> '.$jun2['status'].'</div>';
}

echo'<div class="phdr" style="font-weight: bold;"> Thông tin</div><div class="gmenu"><div class="list1">Chó đang có thể đang ở chế độ tàn hình, cẩn thận nhé bạn, kẻo tiền mất tật mang!!</div>';
// Mod ad them dat cho mem //

if($datauser['rights'] == 9) { 
if(isset($_GET['themdatxml556']))
	{
	mysql_query("INSERT INTO `fermer_gr` (`semen`, `id_user`) VALUES  ( '0', '".$int."') ");
	}
if(isset($_GET['xoadatxml554']))
	{
	$res = mysql_query("select * from `fermer_gr` WHERE `id_user` =  '".$int."' LIMIT $start, $SET[p_str];");
$post = mysql_fetch_array($res);
	mysql_query("DELETE FROM `fermer_gr` WHERE `id` = '".$post["id"]."'");
	}
if(isset($_GET['themchoxml1554'])){
		$time = time();
		$time2 = $time+60*60*24*30;
		mysql_query("UPDATE `users` SET `balans` = `balans` - $cena WHERE `id` = $user_id LIMIT 1");
		$q="UPDATE `users` SET `balans` = `balans` - $cena WHERE `id` = $user_id LIMIT 1";
		mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/fermers_gr.php','".date('d-m-Y  h:i:s A')."')");
		mysql_query("INSERT INTO `fermer_dog` SET
		`id_user` = '$int',
		`time` = '$time2'
		");
		mysql_query("UPDATE `users` SET `tienxu` = '1' WHERE `id` = $int LIMIT 1");
	}
	echo '<div class="list1"><a href="/nongtrai/nongtrai.html?id='.$int.'&amp;themdatxml556"><b>[Thêm Đất Cho Mem]</b></a></div>';
	echo '<div class="list1"><a href="/nongtrai/nongtrai.html?id='.$int.'&amp;xoadatxml554"><b>[Xóa Đất Bớt Đất]</b></a></div>';
	echo '<div class="list1"><a href="/nongtrai/nongtrai.html?id='.$int.'&amp;themchoxml1554"><b>[Thêm chó cho mem]</b></a></div>';
}
echo "<div class='list1'>&laquo; <a href='hangxom.html'>Hàng xóm</a></div>";
echo "<div class='list1'>&laquo; <a href='/nongtrai/'>Về Nông Trại</a></div>";
echo "</div>";

}else{
	header('Location: /nongtrai');
}
}else{
	echo '- Người chơi chưa tham gia nông trại';
}
require('../incfiles/foot.php');

?>