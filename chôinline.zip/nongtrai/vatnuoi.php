<?php
// Viết bởi choionline.cf - Vodoivn VTG
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Khu nuôi gia xúc, gia cầm!';
require('../incfiles/head.php');

echo '<div class="phdr">Nông Trại</div>';
if($user_id){
if(isset($_GET['thuhoach_yes'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Thu hoạch thành công rồi ^^</div>';
if(isset($_GET['vatnuoi_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đi đâu đấy, làm gì có vật nuôi này.. </div>';
if(isset($_GET['thuhoach_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Thu hoạch không thành công, kiểm tra lại nhé!</div>';
if(isset($_GET['banvn_yes'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bán vật nuôi thành công!</div>';
if(isset($_GET['ktvatnuoi_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Đây không phải vật nuôi của bạn!</div>';
if(isset($_GET['choan_yes'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Cho vật nuôi ăn thành công!</div>';
if(isset($_GET['choan_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Vật nuôi vẫn đang no chưa cần ăn!</div>';
if(isset($_GET['choan_no2'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn làm gì có vật nuôi này mà cho ăn!</div>';

// Mod hien thi vat nuoi
if($datauser['giaodien'] == 0){
		echo '<div class="list1"><b style="color: red;">Giao điện:</b><b> <a href="/nongtrai/?manh">Chuyển sang chế độ nét cao</a></b></div>';
		require('../nongtrai/my2.php');
		}else{
		echo '<div class="list1"><b style="color: red;">Chế độ giao điện:</b><b> <a href="/nongtrai/?yeu">Chuyển sang chế độ yếu</a></b></div>';
		require('../nongtrai/my.php');
		}
//-- Mod ham cho an -- //
if(isset($_GET['choan'])){
	$thunuoi2 = intval($_GET['choan']);
	// ham cho an vat nuoi trong chuong //
	if($thunuoi2 == 1){
		$vatnuoilon = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'"));
		$timechoan = $vatnuoilon['timechoan']+7200;
		$tinhtime = $timechoan - time();
		if($tinhtime <= 0){
			$kiemtravatnuoi51 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '51'"), 0);
			$kiemtravatnuoi52 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'"), 0);
			$kiemtravatnuoi53 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'"), 0);
			if($kiemtravatnuoi51 > 0 || $kiemtravatnuoi52 > 0 || $kiemtravatnuoi53 > 0){
				$kiemtrachoan = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'"), 0);
				if($kiemtrachoan == 1){
					mysql_query("UPDATE `fermer_choan` SET `timechoan` = '".time()."' WHERE `user_id` = '".$datauser["id"]."' AND `name` = '1'");
					if($kiemtravatnuoi52 > 0){
					mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = `choan`+1 WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'");
					}
					if($kiemtravatnuoi53 > 0){
					mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = `choan`+1 WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'");
					}
				}elseif($kiemtrachoan == 0){
					mysql_query("INSERT INTO `fermer_choan` (`user_id`, `name`, `timechoan`) VALUES ('".$datauser["id"]."', '1', '".time()."')");
					if($kiemtravatnuoi52 > 0){
					mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = `choan`+1 WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'");
					}
					if($kiemtravatnuoi53 > 0){
					mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = `choan`+1 WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'");
					}
				}
				header('Location: ../?choan_yes');
			}else{
				header('Location: ../?choan_no2');
			}
		}else{
			header('Location: ../?choan_no');
		}
	}
	if($thunuoi2 == 2){
		$vatnuoilon = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '2'"));
		$timechoan = $vatnuoilon['timechoan']+4200;
		$tinhtime = $timechoan - time();
		if($tinhtime <= 0){
			$kiemtravatnuoi2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'"), 0);
			if($kiemtravatnuoi2 > 0){
				$kiemtrachoan = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '2'"), 0);
				if($kiemtrachoan == 1){
					$wiew_choan = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'"));
					if($wiew_choan[choan] < 3){
					mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = `choan`+1 WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'");
					}
					mysql_query("UPDATE `fermer_choan` SET `timechoan` = '".time()."' WHERE `user_id` = '".$datauser["id"]."' AND `name` = '2'");
				}elseif($kiemtrachoan == 0){
					mysql_query("INSERT INTO `fermer_choan` (`user_id`, `name`, `timechoan`) VALUES ('".$datauser["id"]."', '2', '".time()."')");
					mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = `choan`+1 WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'");
				}
				header('Location: ../?choan_yes');
			}else{
				header('Location: ../?choan_no2');
			}
		}else{
			header('Location: ../?choan_no');
		}
	}
	//ca
	if($thunuoi2 == 3){
		$vatnuoilon = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '3'"));
		$timechoan = $vatnuoilon['timechoan']+7200;
		$tinhtime = $timechoan - time();
		if($tinhtime <= 0){
			$kiemtravatnuoi2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '54'"), 0);
			if($kiemtravatnuoi2 > 0){
				$kiemtrachoan = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_choan` WHERE `user_id` = '".$datauser["id"]."' AND `name` = '3'"), 0);
				if($kiemtrachoan == 1){
					mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = `choan`+1 WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '54'");
					mysql_query("UPDATE `fermer_choan` SET `timechoan` = '".time()."' WHERE `user_id` = '".$datauser["id"]."' AND `name` = '3'");
				}elseif($kiemtrachoan == 0){
					mysql_query("INSERT INTO `fermer_choan` (`user_id`, `name`, `timechoan`) VALUES ('".$datauser["id"]."', '3', '".time()."')");
					mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = `choan`+1 WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '54'");
				}
				header('Location: ../?choan_yes');
			}else{
				header('Location: ../?choan_no2');
			}
		}else{
			header('Location: ../?choan_no');
		}
	}
	
	
}
// -- Mod ham thu hoach vat nuoi --//
if(isset($_GET['thuhoach'])){
	$thunuoi2 = intval($_GET['thuhoach']);
	//mod thu hoach ga //
	if($thunuoi2 == 50){
		$kiemtravatnuoi2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '50'"), 0);
		if($kiemtravatnuoi2 > 0){
		$sanluongtrung = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_name` WHERE `id` = '50'"));
		$sochoan = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'"));
		$sanluongtr = $sanluongtrung['rand1']*$sochoan['choan'];
		$tongsotrung = $sanluongtr*$kiemtravatnuoi2;
		// Mod gộp sản lượng trứng vào trong kho //
		$kiemtratrung = mysql_fetch_array(mysql_query("SELECT `semen` FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '50'"));
		if($kiemtratrung['semen'] == 50){
			$tongtrung = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '50'"), 0);
			if($tongtrung == 1){
			header('Location: ../?thuhoach_yes');
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `timethuhoach` = '".time()."' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '50'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '50'");
			mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol` + '".$tongsotrung."' WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '50' ");
			}
		}else{
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'");
			mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$tongsotrung."', '50', '".$datauser["id"]."') ");
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'");
			header('Location: ../?thuhoach_yes');
			echo 'Thu hoach thanh cong tess else';
			mysql_query("UPDATE `fermer_vatnuoi` SET `timethuhoach` = '".time()."' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '50'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '50'");
		}
			}else{
			header('Location: ../?thuhoach_no');
		}
	}elseif($thunuoi2 == 52){
		// mod thu hoach bo //
		$kiemtravatnuoi2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '52'"), 0);
		if($kiemtravatnuoi2 > 0){
		$sanluongtrung = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_name` WHERE `id` = '52'"));
		$sochoan = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'"));
		$sanluongtr = $sanluongtrung['rand1']*$sochoan['choan'];
		$tongsotrung = $sanluongtr*$kiemtravatnuoi2;
		// Mod gộp sản lượng sua bo vào trong kho //
		$kiemtratrung = mysql_fetch_array(mysql_query("SELECT `semen` FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '52'"));
		if($kiemtratrung['semen'] == 52){
			$tongtrung = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '52'"), 0);
			if($tongtrung == 1){
			header('Location: ../?thuhoach_yes'); 
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `timethuhoach` = '".time()."' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '52'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '52'");
			mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol` + '".$tongsotrung."' WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '52' ");
			}
		}else{
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'");
			mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$tongsotrung."', '52', '".$datauser["id"]."') ");
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'");
			header('Location: ../?thuhoach_yes');
			mysql_query("UPDATE `fermer_vatnuoi` SET `timethuhoach` = '".time()."' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '52'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '52'");
		}
			}else{
			header('Location: ../?thuhoach_no');
		}
	}elseif($thunuoi2 == 53){
		// mod thu hoach cuu //
		$kiemtravatnuoi2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '53'"), 0);
		if($kiemtravatnuoi2 > 0){
		$sanluongtrung = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_name` WHERE `id` = '53'"));
		$sochoan = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'"));
		$sanluongtr = $sanluongtrung['rand1']*$sochoan['choan'];
		$tongsotrung = $sanluongtr*$kiemtravatnuoi2;
		// Mod gộp sản lượng long cuu vào trong kho //
		$kiemtratrung = mysql_fetch_array(mysql_query("SELECT `semen` FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '53'"));
		if($kiemtratrung['semen'] == 53){
			$tongtrung = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '53'"), 0);
			if($tongtrung == 1){
			header('Location: ../?thuhoach_yes'); 
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `timethuhoach` = '".time()."' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '53'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '53'");
			mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol` + '".$tongsotrung."' WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '53' ");
			}
		}else{
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'");
			mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$tongsotrung."', '53', '".$datauser["id"]."') ");
			mysql_query("UPDATE `fermer_vatnuoi` SET `choan` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'");
			header('Location: ../?thuhoach_yes');
			mysql_query("UPDATE `fermer_vatnuoi` SET `timethuhoach` = '".time()."' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '53'");
			mysql_query("UPDATE `fermer_vatnuoi` SET `view` = '0' WHERE `id_user` = '".$datauser["id"]."' AND `view` = '1' AND `vatnuoi` = '53'");
		}
			}else{
			header('Location: ../?thuhoach_no');
		}
	}else{
		header('Location: ../?vatnuoi_no');
	}
}
// ket thuc
echo '</div></div>';
if(isset($_GET['id'])){
$int = intval($_GET['id']);
$vatnuoi = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_vatnuoi` WHERE `id` = '".$int."'"));
$tenvatnuoi = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_name` WHERE `id` = '".$vatnuoi['vatnuoi']."'"));
if($vatnuoi[id_user] == $datauser['id']){
$timeht = time();
$tinhthoigian = $vatnuoi['time']+ $tenvatnuoi['timelon'];
$tinhthoigianc = $vatnuoi['time']+ $tenvatnuoi['timechet'];
// Mod ban thu nuoi
if(isset($_GET['ban'])){
	if($timeht >= $tinhthoigian){
	mysql_query("UPDATE `users` SET `balans` = `balans` + '".$tenvatnuoi["rand2"]."' WHERE `id` = '".$datauser["id"]."'");
	$q="UPDATE `users` SET `balans` = `balans` + '".$tenvatnuoi["rand2"]."' WHERE `id` = '".$datauser["id"]."'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/vatnuoi.php','".date('d-m-Y  h:i:s A')."')");
	mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '$int'");
	header('Location: ../?banvn_yes');
	}else{
		mysql_query("UPDATE `users` SET `balans` = `balans` + '".$tenvatnuoi["rand1"]."' WHERE `id` = '".$datauser["id"]."'");
		$q="UPDATE `users` SET `balans` = `balans` + '".$tenvatnuoi["rand1"]."' WHERE `id` = '".$datauser["id"]."'";
		mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/vatnuoi.php','".date('d-m-Y  h:i:s A')."')");
		mysql_query("DELETE FROM `fermer_vatnuoi` WHERE `id` = '$int'");
		header('Location: ../?banvn_yes');
	}
}else if(isset($_GET['ban'])){
	header('Location: ../?tess');
}
//ket thuc
echo '<div class="phdr">Thông tin vật nuôi</div><div class="list1">';
echo '<img src="/nongtrai/vatnuoi/img/'.$tenvatnuoi['id'].'.gif"> '.$tenvatnuoi['name'].' ';
	$tinhtime = $tinhthoigian - time();
	$timediff=$tinhtime;
	$oneMinute=60;
	$oneHour=60*60;
	$oneDay=60*60*24;
	$dayfield=floor($timediff/$oneDay);
	$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour);
	$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute);
	$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute));
	if($dayfield>0)$day=$dayfield.' ngày ';
	if($minutefield>0)$minutefield=$minutefield." phút";else$minutefield='';
	$time_1=$day.$hourfield." giờ ".$minutefield;
if($tinhtime > 0) {
	if($vatnuoi['vatnuoi'] == 50){
		echo '<br/>Thời gian lớn còn: '.timeonline($tinhtime).' ';
		echo '<br/><img src="/nongtrai/vatnuoi/img/cam.png"> <a href="?choan=2"><b>Cho ăn</b></a>';
	}elseif($vatnuoi['vatnuoi'] == 54){
		echo '<br/>Thời gian lớn còn: '.timeonline($tinhtime).' ';
		echo '<br/><img src="/nongtrai/vatnuoi/img/cam.png"> <a href="?choan=3"><b>Cho ăn</b></a>';
	}else{
	echo '<br/>Thời gian lớn còn: '.timeonline($tinhtime).' ';
	}
}else{
	if($vatnuoi['vatnuoi'] == 51){
		echo '<br/> '.$tenvatnuoi['name'].' của bạn đã lớn rồi, có thể bán lấy ít tiền tiêu!';
	}elseif($vatnuoi['vatnuoi'] == 50){
		echo '<br/>Gà đã lớn, đã có thể đẻ trứng cho bạn rồi, còn bán con vật đi sẽ được ít xu lắm!';
		echo '<br/><img src="/nongtrai/vatnuoi/img/cam.png"> <a href="?choan=2"><b>Cho ăn</b></a>';
	}elseif($vatnuoi['vatnuoi'] == 52){
		echo '<br/>Bò đã lớn, đã có thể vắt sữa đem bán, còn bán con vật đi sẽ được ít xu lắm!';
	}elseif($vatnuoi['vatnuoi'] == 53){
		echo '<br/>Cừu đã lớn, đã có thể lấy lông cừu đem bán, còn bán con vật đi sẽ được ít xu lắm!';
	}elseif($vatnuoi['vatnuoi'] == 54){
		echo '<br/>Cá đã lớn, đã có thể bán lấy sản lượng!';
	}
	
}
	$tinhtimec = $tinhthoigianc - time();
	$timediffc=$tinhtimec;
	$oneMinutec=60;
	$oneHourc=60*60;
	$oneDayc=60*60*24;
	$dayfieldc=floor($timediffc/$oneDayc);
	$hourfieldc=floor(($timediffc-$dayfieldc*$oneDayc)/$oneHourc);
	$minutefieldc=floor(($timediffc-$dayfieldc*$oneDayc-$hourfieldc*$oneHourc)/$oneMinutec);
	$secondfieldc=floor(($timediffc-$dayfieldc*$oneDayc-$hourfieldc*$oneHourc-$minutefieldc*$oneMinutec));
	if($dayfieldc>0)$dayc=$dayfieldc.' ngày ';
	if($minutefieldc>0)$minutefieldc=$minutefieldc." phút";else$minutefieldc='';
	$time_1c=$dayc.$hourfieldc." giờ ".$minutefieldc;
if($tinhtimec > 0){
	echo '<br/>Thời gian còn sống: '.timeonline($tinhtimec).' ';
	echo '<br/><b>[ <a href="?id='.$int.'&amp;ban">Bán</a> ]';
	if($timeht >= $tinhthoigian){
		echo ' Giá: '.$tenvatnuoi['rand2'].' Xu</b>';
		
	}else{
		echo ' Giá: '.$tenvatnuoi['rand1'].' Xu</b>';
	}
}else{
	echo '<br/>Vật nuôi đã chết';
}
echo '</div>';
}else{
header('Location: ../?ktvatnuoi_no');
}
}
echo '<div class="phdr">» <a href="/nongtrai/">Nông trại</a></div>';
}else{
echo '<div class="list1">- Bạn vui lòng đăng nhập để sử dụng chức năng này nhé</div>';
}
require('../incfiles/foot.php');
?>