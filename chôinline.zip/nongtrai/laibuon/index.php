<?php
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
$textl = 'Lái buôn';
require('../../incfiles/head.php');
if(isset($_GET['chuyencan_yes'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn nhận được 5 điểm chuyên cần từ lái buôn ^^</div>';
if(isset($_GET['chuyencan_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã nhận quà báo danh của ngày hôm nay rồi ^^</div>';
echo '
<div class="phdr">Lái Buôn</div>
<div class="gmenu">';
if($user_id){
	echo '
<div class="list1"><table width="100%"><tbody><tr><td width="6%"><img src="../img/laibuon.gif" alt="">&nbsp;</td><td style="padding: 0px;" width="80%"><b>[ <font color="red">Lái Buôn</font> ]</b>
<div class="list3"><a href="chuyencan.php">Báo Danh Hàng Ngày</a></div>
<div class="list3"><a href="doidiem.php">Đổi kẹo</a></div>
<div class="list3"><a href="nhiemvu/">Nhiệm vụ <b style="color: red">UPDATE</b></a></div>
<div class="list3"><a href="../">Quay lại</a></div>

</div></div></td></tr></tbody></table></div>
';

echo '<div class="list1"><center></center><b></b></div>';


}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng này nhé!</div>';
}
require('../../incfiles/end.php');
?>