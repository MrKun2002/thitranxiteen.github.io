<?php
/////////////////////////////////////////////////////
//---CODE VIẾT BỞI Forum viet.MOBI - VODOIVN VTG---//
///////////////////////////////////////////////////
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
$textl = 'Đổi điểm';
require('../../incfiles/head.php');
echo '
<div class="phdr">Sự Kiện Haloween</div>
<div class="gmenu">';
if($user_id){
$doi_qua = 50;
$doi_qua2 = 100;
$xoai = 7;
$dua_hau = 11;
$thanh_long = 6;
$trung = 50;
$lua = 12;
$nho = 10;
$toi = 16;
$luong = 1;
// Đổi Quà Even
$kt_duahau = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `semen` = $dua_hau AND `mua` = 0"));
$kt_toi = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `semen` = $toi AND `mua` = 0"));
$kt_thanhlong = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `semen` = $thanh_long AND `mua` = 0"));
$kt_nho = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `semen` = $nho AND `mua` = 0"));
$kt_xoai = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `semen` = $xoai AND `mua` = 0"));
$kt_trung = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `semen` = $trung AND `mua` = 0"));
$kt_lua = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `semen` = $lua AND `mua` = 0"));
if(isset($_GET['doikeo'])){
if($kt_trung[kol] >= $doi_qua && $kt_lua[kol] >= $doi_qua2){
	mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`, `thongtin`) 
	VALUES  ('4', 'vatpham', '".$user_id."' , '0','0', 'Kẹo Noel', 'Dùng cho sự kiện')
	");
	mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol` - $doi_qua WHERE `id_user` = '$user_id' AND `semen` = $trung AND `mua` = 0 LIMIT 1");
	mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol` - $doi_qua2 WHERE `id_user` = '$user_id' AND `semen` = $lua AND `mua` = 0 LIMIT 1");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Đổi kẹo noel thành công !</div>';
}else{
echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ nông sản để đổi chiếc kẹo này !</div>';
}

}
// Index Even
echo '
<div class="list1"><table width="100%"><tbody><tr><td width="6%"><img src="../img/laibuon.gif" alt="">&nbsp;</td><td style="padding: 0px;" width="80%"><b>[ <font color="red">Lái Buôn</font> ]</b>
<div class="list3"><a href="?doikeo">Đổi Kẹo Giáng Sinh</a><br/>
<b>[</b> 1 kẹo giáng sinh = 50 trứng + 100 lúa = 1 điển even<b>]</b>
</div>
</div></div></td></tr></tbody></table></div>
';

}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng này nhé!</div>';
}
echo '</div>';
require('../../incfiles/end.php');
?>