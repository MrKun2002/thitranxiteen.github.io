<?php
define('_IN_JOHNCMS', 0);
require_once('../../incfiles/core.php');
$textl = 'Chuyên cần';
echo '
<div class="phdr">Lái Buôn</div>
<div class="gmenu">';
date_default_timezone_set('Asia/Ho_Chi_Minh');
if($user_id){
$kiemtra = date("d");
if($datauser['timechuyencan'] != $kiemtra){
mysql_query("UPDATE `users` SET `chuyencan` = '5', `timechuyencan` = '$kiemtra' WHERE `id` = '$user_id' LIMIT 1");
header('Location: ../laibuon/?chuyencan_yes');
}else{
	header('Location: ../laibuon/?chuyencan_no');
}


}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng này nhé!</div>';
}
?>