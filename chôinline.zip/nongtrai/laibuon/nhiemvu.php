<?php
define('_IN_JOHNCMS', 0);
require_once('../../incfiles/core.php');
$textl = 'Nhiệm Vụ';
include('../../incfiles/head.php');
echo '<div class="phdr">Nhiệm Vụ</div>
<div class="gmenu">';
if($user_id){
	if(isset($_GET[thuong])){
		$int = intval($_GET[thuong]);
		$kt_nhan = mysql_result(mysql_query("SELECT * FROM `gamemini_nhiemvu_nhan` WHERE `user_id` = '{$user_id}' AND `nhiemvu_id` = '{$int}'"), 0);
		if($kt_nhan > 0){
			$kt_nv = mysql_fetch_array(mysql_query("SELECT * FROM `gamemini_nhiemvu` WHERE `id` = '{$int}'"));
			$kt_nv_nhan = mysql_fetch_array(mysql_query("SELECT * FROM `gamemini_nhiemvu_nhan` WHERE `user_id` = '{$user_id}' AND `nhiemvu_id` = '{$int}'"));
			if($kt_nv_nhan[tra_nv] == 0){
			if($kt_nv_nhan[tienhanh] >= $kt_nv[chiso]){
				mysql_query("UPDATE `users` SET `balans` = `balans` + '{$kt_nv[phanthuong]}' WHERE `id` = '{$user_id}' LIMIT 1");
				mysql_query("UPDATE `gamemini_nhiemvu_nhan` SET `tra_nv` = '1' WHERE `user_id` = '{$user_id}' AND `nhiemvu_id` = '{$int}' LIMIT 1");
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã trả nhiệm vụ thành công <a href="../nhiemvu/"><b>Quay lại</b></a></div>';
			}else{
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn chưa hoàn thành nhiệm vụ không thể trả được :) <a href="../nhiemvu/"><b>Quay lại</b></a></div>';
			}
			}else{
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Nhiệm vụ này bạn đã trả rồi hãy đợi ngày kế tiếp để làm nhiệm vụ này nhé! <a href="../nhiemvu/"><b>Quay lại</b></a></div>';
			}
		}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn chưa nhận nhiệm vụ này <a href="../nhiemvu/"><b>Quay lại</b></a></div>';
			
		}
		echo '</div>';
		include('../../incfiles/end.php');
		exit;
	}
	if(isset($_GET[id])){
		$int = intval($_GET[id]);
		if(isset($_POST[dongy])){
			if(mysql_query("INSERT INTO `gamemini_nhiemvu_nhan` SET
					`user_id` = '{$user_id}',
					`nhiemvu_id` = '{$int}',
					`tienhanh` = '0'
			") == true){
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn nhận nhiệm vụ thành công, hãy bắt đầu làm nhiệm vụ đi nào <a href="../nhiemvu/"><b>Quay lại</b></a></div>';
			}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã nhận nhiệm vụ này rồi <a href="../nhiemvu/"><b>Quay lại</b></a></div>';
			}
			include('../../incfiles/end.php');
			exit;
		}
		if(isset($_POST[khong])){
			header('Location: ../nhiemvu/');
			include('../../incfiles/end.php');
			exit;
		}elseif(!isset($_POST[dongy]) && !isset($_POST[khong])){
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn có muốn nhận nhiệm vụ này không?<br/>
			<form action="" method="post">
				<input type="submit" name="dongy" value="Đồng Ý"/>
				<input type="submit" name="khong" value="Không"/>
			</form>
		</div>';
		}
	}else{
	$tong = mysql_result(mysql_query("SELECT count(*) FROM `gamemini_nhiemvu`"), 0);
	$res = mysql_query("SELECT * FROM `gamemini_nhiemvu` WHERE `id` ORDER BY `id` DESC LIMIT $start,$kmess");
	while($post = mysql_fetch_array($res)){
		echo '<div class="nenfr">';
		echo 'Nhiệm vụ: <b>'.$post[name].'</b><br/>';
		echo 'Thông tin: '.$post[huong_dan].'<br/>';
		echo 'Phần thưởng: '.$post[phanthuong].' Xu<br/>';
		$kiem_nhan = mysql_result(mysql_query("SELECT count(*) FROM `gamemini_nhiemvu_nhan` WHERE `user_id` = '$user_id' AND `nhiemvu_id` = '$post[id]'"), 0);
		if($kiem_nhan == 0){
		echo '[<a href="?id='.$post[id].'"><b>Nhận Nhiệm Vụ</b></a>]';
		}else{
			$tiendo = mysql_fetch_array(mysql_query("SELECT `tienhanh`,`tra_nv` FROM `gamemini_nhiemvu_nhan` WHERE `user_id` = '{$user_id}' AND `nhiemvu_id` = '{$post[id]}'"));
			if($tiendo[tra_nv] == 0){
			if($tiendo[tienhanh] >= $post[chiso]){
			echo '[<a href="thuong_'.$post[id].'.html"><b>Nhận Thưởng</b></a>]';
			}else{
			echo '[Tiến độ <b>'.$tiendo[tienhanh].'</b>/'.$post[chiso].']';
			}
			}else{
			echo '[<b>Đã trả nhiệm vụ</b>]';
			}
		}
		echo '</div>';
	}
	// Phân trang
	if($tong > $kmess){
		echo '<div class="trang">' . functions::display_pagination2('page', $start, $tong, $kmess) . '</div>';
	}
	}
}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng nhé!</div>';
}
echo '</div>';
include('../../incfiles/end.php');
?>