<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Nông trại Online';
require('../incfiles/head.php');
echo '<div class="mainblok"><div class="phdr" style="font-weight: bold;">Nông Trại</div><div class="gmenu">';
//echo '<div class="list4">- Để có thể nhận được kẹo noel bạn cần phải chăm chỉ thu hoạch từng cây một, không được dùng auto farm.</div>';
if($user_id) {
	switch($act){
		default:
		if(isset($_GET['vatnuoi_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đi đâu đấy, làm gì có vật nuôi này.. </div>';
		if(isset($_GET['banvn_yes'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bán vật nuôi thành công!</div>';
		if(isset($_GET['ktvatnuoi_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Đây không phải vật nuôi của bạn!</div>';
		if(isset($_GET['choan_yes'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Cho vật nuôi ăn thành công!</div>';
		if(isset($_GET['choan_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Vật nuôi vẫn đang no chưa cần ăn!</div>';
		if(isset($_GET['choan_no2'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn làm gì có vật nuôi này mà cho ăn!</div>';
		if(isset($_GET['tess'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Tài khoản bạn đang trong quá trình tess không thể bán vật nuôi!</div>';
		if(isset($_GET['manh'])){
			mysql_query("UPDATE `users` SET `giaodien` = '1' WHERE `id` = '".$datauser["id"]."'");
			header('Location: /nongtrai?act=1');
		}
		if(isset($_GET['yeu'])){
			mysql_query("UPDATE `users` SET `giaodien` = '0' WHERE `id` = '".$datauser["id"]."'");
			header('Location: /nongtrai?act=1');
		}
		
		if($datauser['giaodien'] == 0){
		echo '<div class="list1"><b style="color: red;">Giao điện:</b><b> <a href="/nongtrai/?manh">Chuyển sang chế độ nét cao</a></b></div>';
		require('../nongtrai/my2.php');
		}else{
		echo '<style>
		body{
			min-width: 900px
		}
		</style>
		';
		echo '<div class="list1"><b style="color: red;">Giao điện:</b><b> <a href="/nongtrai/?yeu">Chuyển sang chế độ yếu</a></b></div>';
		require('../nongtrai/my.php');
		}
		
		echo '
		<div class="mainblok"><div class="phdr" style="font-weight: bold;">Menu Nhanh</div>
		<form action="/users/profile.php?act=edit&amp;user=' . $datauser['id'] . '" method="post">
		<br><input type="text" value="" name="status" size="15" placeholder="Bạn đang nghĩ gì?" style="border-radius: 2px;">
		<input class="button_head" type="submit" value="Đăng" name="submit">
		</form>
		<div class="list1"><img src="/images/money_bag.png"/>';
		require('../nongtrai/thongtin.php');

		echo'</div>
		<div class="list1"><img src="img/icon/soil.png" alt="*" /> <a href="cuahang.html"> Cửa hàng</a><br /></div>
		<div class="list1"><img src="img/icon/rating.png" alt="*" /> <a href="hangxom.html"> Hàng xóm</a><br /></div>
		<div class="list1">- Cấp nông trại hiện tại của bạn là cấp <b>'.$datauser['fermer_level'].'</b> tức tương đương với <b>'.$datauser['fermer_oput'].' EXP</b> bạn đã nhận đươc, điểm EXP tụt thì lever sẽ giảm</b></div>
		<div class="phdr">
		&laquo; <a href="/nongtrai/?act=1"> Thoát</a>
		</div></div>
		';
		break;
		case '1':

		if($datauser['giaodien'] == 1){
			echo '
<style>
body{
min-width: 570px;
}
</style>
';
			echo '<div class="list1"><b style="color: red;">Giao điện:</b><b> <a href="?yeu"> Chuyển sang giao diện yếu</a></b></div>';
				echo '

				<div class="cola3">';
date_default_timezone_set('Asia/Ho_Chi_Minh');
	$kiemtra = date("H");
if($kiemtra >= 6 && $kiemtra <= 18){
echo '<div class="nennongtrai">
<marquee behavior="scroll" direction="left" scrollamount="1" style="margin-top: 5px"><img src="/iconvip/may1.png"></marquee>
<marquee behavior="scroll" direction="left" scrollamount="2" style="margin-top: 10px"><img src="/iconvip/may2.png"></marquee>
</div>';
}else{
echo '<div class="nennongtrai_toi"></div>';
}
				echo '
		<div style="margin-top: -70px;text-align: center;"><a href="/nongtrai/hangxom.html"><img src="img/hangxom.png" style="padding-right: 10px;"></a><a href="/nongtrai/"><img src="../icon/farm.png"></a><a href="atm"><img src="img/atm.png"></a><a href="cuahang.html"><img src="../icon/cuahangfarm.png"></a>
		
		</div>
		<div class="dat2"><a href="/nongtrai/bxh.html"><img src="http://choionline.cf/images/bxh.png"></a>
		<a href="laibuon/"><img src="img/laibuon.gif" style="position: absolute;vertical-align: 0px;margin:-40px 0 0 60px;"></a>
		</div>
		</div>
		';
		}else{
			echo '<div class="list1"><b style="color: red;">Giao điện:</b><b> <a href="?manh"> Chuyển sang giao diện nét cao</a></b></div>';
			echo '
			<div class="list1">- <a href="/nongtrai/">Tiến vào nông trại của tôi</a><br/>- Hãy vào trang trại để trải nghiệm cảm giác nông dân nào :D</div>
			<div class="list1">- <a href="/nongtrai/atm">Cây ATM</a><br/>- Đổi xu thành lượng</div>
			<div class="list1">- <a href="/nongtrai/hangxom.html">Hàng Xóm</a><br/>- Đi ăn trộm mất 200 exp/1 lần trộm</div>
			<div class="list1">- <a href="laibuon/">Lái Buôn</a><br/>- Nhiệm vụ và nhận điểm quay số miễn phí</div>
			<div class="list1">- <a href="/nongtrai/cuahang.html">Cửa Hàng</a><br/>- Cửa hàng mua hạt giống và vật nuôi</div>
			<div class="list1">- <a href="/nongtrai/bxh.html">Bảng Xếp Hạng 20 Farm Pro Nhất</a></div>
			';
		}
		echo '<div class="phdr">
		&laquo; <a href="/"> Thoát</a>
		</div>';
		break;
		}
	}
else
{
header('Location: ../index.php');
}
require('../incfiles/foot.php');
?>
