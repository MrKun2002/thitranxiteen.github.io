<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');

if(isset($user_id)){

if(isset($_GET['add_no']));

else{
$res = mysql_query("select * from `fermer_gr` WHERE `id_user` = '$user_id'  LIMIT $start, $SET[p_str];");
while ($post = mysql_fetch_array($res)){
$semen=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1"));
$p = mysql_fetch_array(mysql_query("select * from `fermer_gr` WHERE  `id` = '$post[id]'  LIMIT 1"));
if($p['semen']!=0 && $time>$p['time'] && $p['kol']==0)
{
$pt=rand($semen['rand1'],$semen['rand2']);
if($post['woter']==0)$pt=floor($pt/2);
mysql_query("UPDATE `fermer_gr` SET `kol` = $pt WHERE `id` = '$post[id]' LIMIT 1");
$q="UPDATE `fermer_gr` SET `kol` = $pt WHERE `id` = '$post[id]' LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}

if($post['semen']==0){$name_gr='Gieo hạt';}else{$name_gr=$semen['name'];}

$vremja=$post['time']-$time;
$timediff=$vremja;
$oneMinute=60;
$oneHour=3600;
$oneDay=86400;
$dayfield=floor($timediff/$oneDay);
$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour);
$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute);
$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute));
if($dayfield>0)$day=$dayfield.'ngày. ';
else $day='';
if($hourfield>0)$hour=$hourfield.'giờ. ';
else $hour='';
if($minutefield>0)$min=$minutefield.'phút. ';
else $min='';
if($post['semen']!=0 && $time>$post['time'] && $post['kol']==0)
if($time=$post['time'])$time_1="";
{
	echo 'Có thể thu hoạch rồi';
}

}
}
}else{
msg('Vui lòng đăng nhập!');
}
?>