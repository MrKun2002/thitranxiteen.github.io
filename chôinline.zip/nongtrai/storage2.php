<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Nhà kho của tôi!';
require('../incfiles/head.php');

if($user_id){
if(isset($_GET['sell_ok']))msg('Đã bán thành công!');
if(isset($_GET['id'])){
$int=intval($_GET['id']);
$sql=mysql_query("SELECT `id` FROM `fermer_sclad` WHERE `id`='$int' AND `id_user` = $user_id ");
$row=mysql_fetch_assoc($sql);
if(!mysql_num_rows($sql)){
echo '<div class="rmenu">Vật Phẩm Không Tồn Tại!</div>';
echo "<div class='phdr'>";
echo "&laquo; <a href='storage.php'>Nhà Kho</a>";
echo "</div>";
require('../incfiles/end.php');

exit;
}
$post=mysql_fetch_array(mysql_query("select * from `fermer_sclad` WHERE `id`= '$int' LIMIT 1"));
$semen=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1"));
$dohod=$post['kol']*$semen['dohod'];
if(isset($_GET['sell']))
{
mysql_query("UPDATE `users` SET `sucmanh` = `sucmanh`+ $dohod WHERE `id` = $user_id LIMIT 1");
$q="UPDATE `users` SET `sucmanh` = `sucmanh`+ $dohod WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
mysql_query("DELETE FROM `fermer_sclad` WHERE `id` = $_GET[id] ");
$q="DELETE FROM `fermer_sclad` WHERE `id` = $_GET[id] ";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
header('Location: storage.php?sell_ok');
}
echo "
'.$datauser[sucmanh].'
<div class='mainblok'><div class='phdr'><b>Nhà kho</b></div>";
echo '<div class="list1"><img src="img/sv1/'.$post['semen'].'.png" alt="*" />'.htmlspecialchars($semen['name']).'<br />';
echo "
</div>
";
echo "<div class='newsx'>";
echo "<form method='post' action='?id=".$int."&amp;sell'>\n";
echo "<input type='submit' name='save' value='Bán' />\n";
echo "</form>\n";
echo "</div>";
}else{
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '$user_id'"),0);
$k_page = ceil($k / $SET['p_str']);
$page = page();
$start=$SET['p_str']*$page-$SET['p_str'];
echo'';
echo "<div class='mainblok'><div class='phdr'><b>Nhà kho</b></div>";
if($k==0){echo "<div class='rmenu'>Chưa Có Sản phẩm nào.<br/>";
echo'<a href="/nongtrai">Trang Trại</a></div>';
include"../incfiles/end.php";
die("");
}
$res = mysql_query("select * from `fermer_sclad` WHERE `id_user` = '$user_id' LIMIT $start, $SET[p_str];");
while ($post = mysql_fetch_array($res)){
$semen=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1"));
$dohod=$post['kol']*$semen['dohod'];
echo '
<a href="?id='.$post['id'].'&amp;sell"> Bán</a><br/>
</div>';
}
if ($k_page>1)str('storage.php?',$k_page,$page); // Вывод страниц
}
echo "<div class='phdr'>";
if(isset($_GET['id']))
echo "&laquo; <a href='storage.php'>Nhà Kho</a>";
else
echo "&laquo; <a href='index.php'>Nông trại</a>";
echo "</div></div>";
}else{
msg('Bạn Chưa Đăng Nhập!');
}
require('../incfiles/foot.php');


?>