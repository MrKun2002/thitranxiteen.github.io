<?php
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_name`"),0);
$k_page = ceil($k / $SET['p_str']);
$page = page();
$start=$SET['p_str']*$page-$SET['p_str'];
$res = mysql_query("SELECT * FROM `fermer_name` LIMIT $start, $SET[p_str];");
echo'';
echo "<div class='mainblok'><div class='phdr'><b>Cửa hàng</b></div>";

while ($post = mysql_fetch_array($res)){
if($post[id] != 13){
if($post[id] == 52 || $post[id] == 53){
$a="<a href='?id=$post[id]'>".htmlspecialchars($post['name'])."</a>";$lev="Giá: <big>$post[cena] Lượng</big><br/>";
}else{
$a="<a href='?id=$post[id]'>".htmlspecialchars($post['name'])."</a>";$lev="Giá: <big>$post[cena] Xu</big><br/>";
}
if($post[level] > 0){
$lev_c="Cấp $post[level] Mới dùng được";
}
echo '<div class="list1">
<table><tr><td>
<img src="img/sv1/'.$post['id'].'.png" alt="*" class="portrait"/></td><td>
'.$a.'<br/>
'.$lev.'
'.$lev_c.'
</td></tr></table>
</div>';
}
}
if ($k_page>1)str('shop.php?',$k_page,$page);
?>
