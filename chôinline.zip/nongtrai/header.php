<?php
if(isset($_GET['gr']))header("Location: gieohat.html?id=".$_GET['gr']."&ok");
if(isset($_GET['gr2']))header("Location: gieohat.html?id=".$_GET['gr2']."&sob_ok");
?>