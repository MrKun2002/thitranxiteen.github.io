<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Thông Tin Tài Khoản';
if($user_id){
$requser=mysql_query("SELECT `id`, `id` FROM `users` WHERE (id='$user_id') ");

$curuser=mysql_fetch_array($requser);

if (core::$user_set['avatar']) {
if (file_exists(($rootpath . 'files/users/avatar/' .$curuser['id'] . '.png')))

echo '';
else
echo '';

echo'<b>'.$datauser['balans'].' Xu</b>';
}
}
else{
msg('Vui lòng đăng nhập!');
}
?>