<?php
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_udobr_name`"),0);
$k_page = ceil($k / $SET['p_str']);
$page = page();
$start=$SET['p_str']*$page-$SET['p_str'];
$res = mysql_query("select * from `fermer_udobr_name` LIMIT $start, $SET[p_str];");
echo'';
echo "<div class='mainblok'><div class='phdr'><b>Cửa hàng phân bón</b></div>";
while ($post = mysql_fetch_array($res)){
$timediff=($post['time']/60);
echo '<div class="list1">
<img src="img/udobr/'.$post['id'].'.png" alt="*" class="portrait" />
<a href="?id='.$post['id'].'">'.htmlspecialchars($post['name']).' </a><br/>
Giảm thời gian: '.$timediff.' Phút<br/>
Giá: <img src="img/icon/money.png" alt="*" /> <big>'.$post['cena'].' Xu</big><br/>
Tốc Độ tăng trưởng <b>'.$time_1.'</b><br/>
</div>
';
}
if ($k_page>1)str('shop_udobr.php?',$k_page,$page);
?>
