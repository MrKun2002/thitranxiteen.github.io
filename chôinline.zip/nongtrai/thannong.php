<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl ='TOP Thần Nông';
require('../incfiles/head.php');
if (!$user_id) {
echo functions::display_error($lng['access_guest_forbidden']);
require('../incfiles/end.php');
exit;
}
echo'<div class="mainblok"><div class="phdr"><b>TOP NÔNG TRẠI</a></b></div>';
$req = mysql_query("SELECT *  FROM `users` ORDER BY `fermer_oput` DESC LIMIT 20");
$i = 1;
while ($res=mysql_fetch_array($req)) {
//mau nick
if ($res['rights'] == 0 ) {
$colornick['colornick'] = '000000';
}
if ($res['rights'] == 1 ) {
$colornick['colornick'] = 'FFD700';
}
if ($res['rights'] == 2 ) {
$colornick['colornick'] = '7192a8';
}
if ($res['rights'] == 3 ) {
$colornick['colornick'] = '0000FF';
}
if ($res['rights'] == 4 ) {
$colornick['colornick'] = '40E000';
}
if ($res['rights'] == 5 ) {
$colornick['colornick'] = '40E000';
}
if ($res['rights'] == 6 ) {
$colornick['colornick'] = '228622';
}
if ($res['rights'] == 7 ) {
$colornick['colornick'] = '860086';
}
if ($res['rights'] == 8 ) {
$colornick['colornick'] = 'FF0000';
}
if ($res['rights'] == 9 ) {
$colornick['colornick'] = 'FF0000';
}
if ($res['rights'] == 10 ) {
$colornick['colornick'] = '7192a8';
}
//het mau nick
echo '<div class="list1">';
echo '<b><a href="nongtrai.html?id='.$res['id'].'">';
if (file_exists(('../avatar/'.$res['id'].'.png'))) {
echo '<img src="../avatar/'.$res['id'].'.png"width="20"height="20"alt="'.$res['id'].'" class="chatbox_avatar chatbox_avatar_online"/>';
} else {
echo '<img src="../avatar/'.$res['id'].'.png"width="20"height="20"alt="'.$res['id'].'"class="chatbox_avatar chatbox_avatar_online"/>';
}
echo'<font color="#'.$colornick['colornick'].'">'.$res['name'].'</font></a></b><br/>Level: <b>'.$res['fermer_level'].'</b><br/>';
echo' Xu: '.$res['balans'].'';
echo'<br/> EXP: '.$res['fermer_oput'].'';
echo '</div>';
$i++;
}
echo '</div>';
require('../incfiles/foot.php');
?>