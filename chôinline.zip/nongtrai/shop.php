<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Cửa hàng';
require('../incfiles/head.php');
if($user_id){
if(isset($_GET['buy_ok']))msg('Mua!');
if(isset($_GET['buy_no']))msg("Không đủ tiền!");
if(isset($_GET['id'])){
include 'shop_info.php';
}else{
echo '<div class="list1"><b>Tạp Hóa | <a href="cuahangphan.html">Cửa Hàng Phân Bón</a></b></div>';
include 'shop_index.php';

echo '<div class="list1"><img src="/images/thucung/7.png" alt="*" class="portrait">
<a href="muacho.html">Chó Canh</a><br>
Giá: <img src="img/icon/money.png" alt="*"> <big>20000</big><br></div>';
}
echo "<div class='phdr'>";
echo "&raquo; <a href='/nongtrai/'>Trang trại của tôi</a>";
if(isset($_GET['id']))echo " | &laquo; <a href='cuahang.html'>Cửa hàng</a>";
echo "</div></div>";
}else{
msg('Vui lòng đăng nhập!');
}
require('../incfiles/foot.php');
?>