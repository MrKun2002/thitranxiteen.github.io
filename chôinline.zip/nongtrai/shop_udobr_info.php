<?php
$int=intval($_GET['id']);
# проверим на коректность
if(!$int){
echo '<div class="rmenu">Lỗi link dẫn!</div>';
echo "<div class='phdr'>";
echo "&laquo; <a href='shop_udobr.php'>Shop Phân Bón</a>";
echo "</div>";
require('../incfiles/end.php');
exit;
}
# проверим товар
$sql=mysql_query("SELECT `id` FROM `fermer_udobr_name` WHERE `id`='$int' ");
$row=mysql_fetch_assoc($sql);
if(!mysql_num_rows($sql)){
echo '<div class="rmenu">Lỗi Link Dẫn!</div>';
echo "<div class='phdr'>";
echo "&laquo; <a href='shop_udobr.php'>Shop Phân Bón</a>";
echo "</div>";
require('../incfiles/end.php');
exit;
}
$post = mysql_fetch_array(mysql_query("select * from `fermer_udobr_name` WHERE  `id` = '$int'  LIMIT 1"));
$timediff=$post['time'];
$oneMinute=60;
$oneHour=60*60;
$oneDay=60*60*24;
$dayfield=floor($timediff/$oneDay);
$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour);
$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute);
$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute));
if($dayfield>0)$day=$dayfield.' ngày ';
if($minutefield>0)$minutefield=$minutefield." phút";else$minutefield='';
$time_1=$day.$hourfield." giờ. ".$minutefield;
echo "<div class='mainblok'><div class='phdr'><b>Mua phân bón</b></div>";
echo '<div class="list1"><img src="img/udobr/'.$post['id'].'.png" alt="*" /> '.htmlspecialchars($post['name']).'</div>';
echo '<div class="newsx"> Giá: <b> '.$post['cena'].'</b> Xu';
echo '<br />Giảm <b> '.$time_1.'</b> thời gian tăng trưởng cây trồng';
echo "<form method='post' action='?id=".$int."&amp;$passgen'>\n";
echo 'Số lượng <input type="text" name="kupit" size="4"/><input type="submit" name="save" value="Mua" />';
echo '</form>';
echo '</div>';
$_POST['kupit']=(int)$_POST['kupit'];
$kup=$post['cena']*$_POST['kupit'];
if(isset($_POST['kupit']) && $datauser['balans']>=$kup && $_POST['kupit']>0)
{
$remils = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_udobr` WHERE `id_user` = '$user_id' AND `udobr` = '$int'"),0);
if($remils>0)
{
 mysql_query("UPDATE `fermer_udobr` SET `kol` = `kol`+ '".$_POST['kupit']."' WHERE `id_user` = $user_id AND `udobr` = '$int' LIMIT 1");
}
else
{
 mysql_query("INSERT INTO `fermer_udobr` (`kol` , `udobr`, `id_user`) VALUES  ('".$_POST['kupit']."', '".$int."', '".$user_id."') ");
 }
 mysql_query("UPDATE `users` SET `balans` = `balans`- $kup WHERE `id` = $user_id LIMIT 1");
 $q="UPDATE `users` SET `balans` = `balans`- $kup WHERE `id` = $user_id LIMIT 1";
 mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/shop_udobr_info.php','".date('d-m-Y  h:i:s A')."')");
header('Location: shop_udobr.php?buy_ok');
}
if(isset($_POST['kupit']) && strlen($_POST['kupit'])==0 || isset($_POST['kupit']) && $_POST['kupit']<1) msg("Lỗi Chỉ được phép nhập Số!");
if(isset($_POST['kupit']) && $datauser['balans']<$kup)header('Location: shop_udobr.php?buy_no');
?>
