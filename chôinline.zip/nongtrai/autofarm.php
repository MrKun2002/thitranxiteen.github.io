<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Nhà kho của tôi!';
// Yêu Cầu Không Xóa Dòng Này //
// Code được viết bởi Vodoivn-VTG choionline.cf //

if($user_id){
$time = time();
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_gr` WHERE `id_user` = '$user_id'"),0);
if(isset($_POST['tuoinuoc']) || isset($_POST['thuhoach']) || isset($_POST['gieohat']) && $k >= 10){
	$n = "";
	// Tuoi nuoc
	if(isset($_POST['tuoinuoc'])){
	$tuoinuoc = $_POST['caytrong'];
	$n = count($tuoinuoc);
		for($i = 0 ; $i < $n ; $i++){
			$post = mysql_fetch_array(mysql_query("select * from `fermer_gr` WHERE  `id` = '".$tuoinuoc[$i]."'  LIMIT 1"));
			if($post['time']>$time){
			mysql_query("UPDATE `fermer_gr` SET `woter` = '1' WHERE `id` = '".$tuoinuoc[$i]."' LIMIT 1");
			}
		}
		header('Location: /nongtrai/?tuoi_ok');
	}
	// Thu Hoach
	if(isset($_POST['thuhoach'])){
	$thuhoach = $_POST['caytrong'];
	$dem_qua = 0;
	$n = count($thuhoach);
		for($i = 0 ; $i < $n ; $i++){
			$post = mysql_fetch_array(mysql_query("select * from `fermer_gr` WHERE  `id` = '".$thuhoach[$i]."'  LIMIT 1"));
			if($user_id==$post['id_user'] && $post['semen']!=0 && $post['time']<$time)
			{
			$semen = mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE `id` = '$post[semen]' "));
			$remils = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `mua` = 0 AND `semen` = '$post[semen]'"),0);
			if($remils>0)
			{ 
				mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol`+ '".$post['kol']."' WHERE `id_user` = $user_id AND `mua` = 0 AND `semen` = '$post[semen]' LIMIT 1");
				$q="UPDATE `fermer_sclad` SET `kol` = `kol`+ '".$post['kol']."' WHERE `id_user` = $user_id AND `semen` = '$post[semen]' LIMIT 1";
				mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
				header("Location: /nongtrai/?thuhoach_ok");
			}
			else
			{
			mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$post['kol']."', '".$post['semen']."', '".$user_id."') ");
			$q="INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$post['kol']."', '".$post['semen']."', '".$user_id."') ";
			mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");	
			}
			// Function Nhiệm vụ kích hoạt
			nhiemvu($post[semen],$user_id);
			mysql_query("UPDATE `users` SET `fermer_oput` = `fermer_oput`+ '".$semen['oput']."' WHERE `id` = $user_id LIMIT 1");
			$q="UPDATE `users` SET `fermer_oput` = `fermer_oput`+ '".$semen['oput']."' WHERE `id` = $user_id LIMIT 1";
			mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
			mysql_query("UPDATE `fermer_gr` SET `semen` = '0' WHERE `id` = '".$thuhoach[$i]."' LIMIT 1");
			$q="UPDATE `fermer_gr` SET `semen` = '0' WHERE `id` = '".$thuhoach[$i]."' LIMIT 1";
			mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
			mysql_query("UPDATE `fermer_gr` SET `time` = NULL WHERE `id` = '".$thuhoach[$i]."' LIMIT 1");
			$q="UPDATE `fermer_gr` SET `time` = NULL WHERE `id` = '".$thuhoach[$i]."' LIMIT 1";
			mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
			mysql_query("UPDATE `fermer_gr` SET `woter` = '0' WHERE `id` = '".$thuhoach[$i]."' LIMIT 1");
			$q="UPDATE `fermer_gr` SET `woter` = '0' WHERE `id` = '".$thuhoach[$i]."' LIMIT 1";
			mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
			mysql_query("UPDATE `fermer_gr` SET `kol` = '0' WHERE `id` = '".$thuhoach[$i]."' LIMIT 1");
			$q="UPDATE `fermer_gr` SET `kol` = '0' WHERE `id` = '".$thuhoach[$i]."' LIMIT 1";
			mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
			mysql_query("UPDATE `fermer_gr` SET `woter` = '0' WHERE `id` = '".$thuhoach[$i]."' LIMIT 1");
			$q="UPDATE `fermer_gr` SET `woter` = '0' WHERE `id` = '".$thuhoach[$i]."' LIMIT 1";
			mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
			$post_sk_ev = even_sk_auto_farm($user_id);
			$dem_qua = $dem_qua+$post_sk_ev;
				if($dem_qua == 0){
					header("Location: /nongtrai/?thuhoach_ok");
				}else{
					header("Location: /nongtrai/?thuhoach_ok=$dem_qua");
				}
			
			}else{
			header("Location: /nongtrai/?thuhoach_no");
			}
		}
	}
	if(isset($_POST['gieohat'])){
		$gieohat = $_POST['caytrong'];
		$n = count($gieohat);
		for($i = 0 ; $i < $n ; $i++){
				$post = mysql_fetch_array(mysql_query("select * from `fermer_gr` WHERE  `id` = '".$gieohat[$i]."'  LIMIT 1"));
				if($post && $user_id==$post['id_user'] && $post['semen']==0)
				{
				$res = mysql_fetch_array(mysql_query("select * from `fermer_sclad` WHERE `id` = '$_POST[sadit]' "));
				$semen = mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE `id` = '$res[semen]' "));
				$t=$time+$semen['time'];
				mysql_query("UPDATE `fermer_gr` SET `semen` = $res[semen] WHERE `id` = '".$gieohat[$i]."' LIMIT 1");
				$q="UPDATE `fermer_gr` SET `semen` = $res[semen] WHERE `id` = '".$gieohat[$i]."' LIMIT 1";
				mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
				mysql_query("UPDATE `fermer_gr` SET `time` = '$t' WHERE `id` = '".$gieohat[$i]."' LIMIT 1");
				$q="UPDATE `fermer_gr` SET `time` = '$t' WHERE `id` = '".$gieohat[$i]."' LIMIT 1";
				mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
				if($res['kol']>=2){
				mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol`-'1' WHERE `id` = $_POST[sadit] LIMIT 1");
				$q="UPDATE `fermer_sclad` SET `kol` = `kol`-'1' WHERE `id` = $_POST[sadit] LIMIT 1";
				mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
				}else{
				mysql_query("DELETE FROM `fermer_sclad` WHERE `id` = $_POST[sadit] ");
				$q="DELETE FROM `fermer_sclad` WHERE `id` = $_POST[sadit] ";
				mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
				}
				header("Location: /nongtrai/?gieohat_ok");
				}else{
				header("Location: /nongtrai/?gieohat_no");
				}
		}
	}
	if($n == ""){
		header('Location: /nongtrai/?hay_tich');
	}
}else{
	header('Location: /nongtrai');
}

}else{
	echo 'Bạn chưa đăng nhập';
}
?>