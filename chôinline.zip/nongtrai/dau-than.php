<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Mua chó!';
require('../incfiles/head.php');
if($user_id){
if($level>=0){
$cena = '0';
$tienxucong = '1';
if($datauser['tienxu'] < $tienxucong){
	if(isset($_GET['add_dog']) && $datauser['balans']>$cena){
	$t=$time+60*60*24*30;
	mysql_query("UPDATE `users` SET `balans` = `balans` - $cena WHERE `id` = $user_id LIMIT 1");
	$q="UPDATE `users` SET `balans` = `balans` - $cena WHERE `id` = $user_id LIMIT 1";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/dau-than.php','".date('d-m-Y  h:i:s A')."')");
	mysql_query("UPDATE `fermer_dog` SET `time` = $t WHERE `id_user` = $user_id LIMIT 1");
	mysql_query("UPDATE `users` SET `tienxu` = `tienxu` + $tienxucong WHERE `id` = $user_id LIMIT 1");
	msg('Mua chó! thành công');
	}
	else if($datauser['balans']<$cena)
	{
	msg('Không đủ tiền!');
	}
}
else 
msg('Bạn đã có chó rồi, mua làm gì nữa, nó dại thì làm sao. Đợi chó hết hạn rồi mua sau nhé!');
 # Hien thi man hinh
echo '';
echo '<div class="mainblok"><div class="phdr"><b>Mua chó</b></div><div class="list1"><center><img src="http://dotnha.info/images/thucung/7.png"/>Con chó sẽ bảo vệ trang trại của bạn chống bị ăn cắp một tháng! <br/> bạn sẽ phải trả chi 
phí là 20.000 xu</div>';
echo '<div class="gmenu">';
echo "<form method='post' action='?add_dog'>\n";
echo "<input type='submit' name='save' value='Mua' />";
echo "</form>\n";
echo '</div>';
}else{ msg('Cấp độ của bạn không đủ để mua một 
con chó! Bạn cần đạt cấp độ 5 trở lên!');}
echo "<div class='phdr'>";
echo "&raquo; <a href='my.php'>Trang trại</a>";
echo "</div></div>";
}else{
msg('Xin vui lòng đăng nhập');
}
require('../incfiles/end.php');
?>