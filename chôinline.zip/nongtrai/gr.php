<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Trang trại của tôi';
require('../incfiles/head.php');
echo '<div class="mainblok"><div class="phdr" style="font-weight: bold;">Nông Trại</div>';
if($datauser['giaodien'] == 0){
		require('../nongtrai/my2.php');
		}else{
		require('../nongtrai/my.php');
		}
if($user_id){
$int=intval($_GET['id']);
$post = mysql_fetch_array(mysql_query("select * from `fermer_gr` WHERE  `id` = '$int'  LIMIT 1"));
if(isset($_GET['ok']))msg('Thành công!');
if(isset($_GET['mn']))msg('Thu hoạch thành công và bạn nhận được 1 chiếc kẹo của ông già noel khi đang chăm chỉ làm vườn!');
if(isset($_GET['sob_ok']))msg('Cây trồng được thu
hoạch!
<a href="../nongtrai/">Nông Trại</a>');
// mod cuoc cay trong
if(isset($_GET['cuoccay'])){
	if($user_id==$post['id_user']){
	mysql_query("UPDATE `fermer_gr` SET `semen` = 0, `time` = NULL, `kol` = NULL WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `semen` = 0 AND `time` = NULL AND `kol` = NULL WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
	header("Location: /nongtrai/?cuoc_ok");
	}else{
		echo 'Không phải là cây của bạn nhé, cuôc của người ta là bị chửi đấy ';
	}
}
//ket thuc cuoc cay trong
if(isset($_POST['sadit']) && $post && $user_id==$post['id_user'] && $post['semen']==0)
{
$res = mysql_fetch_array(mysql_query("select * from `fermer_sclad` WHERE `id` = '$_POST[sadit]' "));
$semen = mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE `id` = '$res[semen]' "));
$t=$time+$semen['time'];
mysql_query("UPDATE `fermer_gr` SET `semen` = $res[semen] WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `semen` = $res[semen] WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
mysql_query("UPDATE `fermer_gr` SET `time` = '$t' WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `time` = '$t' WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
if($res['kol']>=2){
mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol`-'1' WHERE `id` = $_POST[sadit] LIMIT 1");
$q="UPDATE `fermer_sclad` SET `kol` = `kol`-'1' WHERE `id` = $_POST[sadit] LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}else{
mysql_query("DELETE FROM `fermer_sclad` WHERE `id` = $_POST[sadit] ");
$q="DELETE FROM `fermer_sclad` WHERE `id` = $_POST[sadit] ";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}
header("Location: header.php?gr=".$int."");
}
if(isset($_GET['get']) && $user_id==$post['id_user'] && $post['semen']!=0 && $post['time']<$time)
{
$semen = mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE `id` = '$post[semen]' "));
$remils = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `mua` = 0 AND `semen` = '$post[semen]'"),0);
if($remils>0)
{ 
	mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol`+ '".$post['kol']."' WHERE `id_user` = $user_id AND `mua` = 0 AND `semen` = '$post[semen]' LIMIT 1");
	$q="UPDATE `fermer_sclad` SET `kol` = `kol`+ '".$post['kol']."' WHERE `id_user` = $user_id AND `semen` = '$post[semen]' LIMIT 1";
	mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}
else
{
 mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$post['kol']."', '".$post['semen']."', '".$user_id."') ");
	$q="INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$post['kol']."', '".$post['semen']."', '".$user_id."') ";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");	
}
// Function Nhiệm vụ kích hoạt
nhiemvu($post[semen],$user_id);
mysql_query("UPDATE `users` SET `fermer_oput` = `fermer_oput`+ '".$semen['oput']."' WHERE `id` = $user_id LIMIT 1");
$q="UPDATE `users` SET `fermer_oput` = `fermer_oput`+ '".$semen['oput']."' WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
mysql_query("UPDATE `fermer_gr` SET `semen` = '0' WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `semen` = '0' WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
mysql_query("UPDATE `fermer_gr` SET `time` = NULL WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `time` = NULL WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
mysql_query("UPDATE `fermer_gr` SET `woter` = '0' WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `woter` = '0' WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
mysql_query("UPDATE `fermer_gr` SET `kol` = '0' WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `kol` = '0' WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
mysql_query("UPDATE `fermer_gr` SET `woter` = '0' WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `woter` = '0' WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
	$post = even_sk($user_id);
	if($post != ''){
		header("Location: gieohat.html?id=".$int.$post."");
	}else{
		header("Location: gieohat.html?id=".$int."&ok");
	}
}
if(isset($_POST['udobr']) && $post && $user_id==$post['id_user'] && $post['semen']!=0)
{
$res = mysql_fetch_array(mysql_query("select * from `fermer_udobr` WHERE `id` = '$_POST[udobr]' "));
$semen = mysql_fetch_array(mysql_query("select * from `fermer_udobr_name` WHERE `id` = '$res[udobr]' "));
mysql_query("UPDATE `fermer_gr` SET `time` = `time`- $semen[time] WHERE `id` = $int LIMIT 1");
if($res['kol']>=2){
mysql_query("UPDATE `fermer_udobr` SET `kol` = `kol`-'1' WHERE `id` = $_POST[udobr] LIMIT 1");
$q="UPDATE `fermer_udobr` SET `kol` = `kol`-'1' WHERE `id` = $_POST[udobr] LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}else{
mysql_query("DELETE FROM `fermer_udobr` WHERE `id` = $_POST[udobr] ");
$q="DELETE FROM `fermer_udobr` WHERE `id` = $_POST[udobr] ";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}
header("Location: /nongtrai/?udobr_ok");
}
if(isset($_GET['woter']) && $post['woter']!=1){
mysql_query("UPDATE `fermer_gr` SET `woter` = '1' WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `woter` = '1' WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
msg('Tưới nước thành công!!!');
}
if($post){
if($user_id ==$post['id_user']){
include'../nongtrai/gr2.php';}else{echo "<div class='rmenu'>Đây không phải là đất của bạn</div>";}
}else{echo "<div class='rmenu'>Không tồn tại!!!</div>";}
echo "<div class='phdr'>";
echo "&laquo; <a href='/nongtrai/'>Nông trại</a>";
echo "</div></div>";
}else{
msg('Vui lòng đăng nhập!');
}
require('../incfiles/foot.php');
?>
