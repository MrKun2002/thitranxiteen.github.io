<?php
define('_IN_JOHNCMS', 1);
$textl = 'ATM - Chuyển Khoản';
$headmod = 'nick';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
if (!$user_id) {
echo 'Chỉ cho người dùng đăng ký';
require_once ('../incfiles/end.php');
exit;
}

switch($act){
case 'ok':
$tinhtimechuyen = time() - $datauser['tgchuyenluong'];
if($datauser['balans'] >= 20000){
	if($tinhtimechuyen >= 28800){
		mysql_query("UPDATE `users` SET `luong`=`luong` + '1', `tgchuyenluong` = '".time()."'  WHERE `id` = '$user_id' LIMIT 1");
		mysql_query("UPDATE `users` SET `balans`=`balans`-'20000'  WHERE `id` = '$user_id' LIMIT 1");
		$q="UPDATE `users` SET `balans`=`balans`-'20000'  WHERE `id` = '$user_id' LIMIT 1";
		mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/atm.php','".date('d-m-Y  h:i:s A')."')");
		// Обновляем время топика
		// Обновляем статистику юзера
		echo '<div class="menu">Chuyển xu sang lượng thành công thành công!</div>';
	}else{
		echo '<div class="rmenu">Hôm nay bạn đã chuyển rồi, đợi cho đủ 8 tiếng mới đổi tiếp được nhé!</div>';
	}
}else{
echo '<div class="rmenu">Xu của bạn không đủ để chuyển sang lượng, hãy kiếm thêm!</div>';
}
break;
case 'doixu':
echo '<div class="phdr"><b>Cây ATM</b></div>';
echo '<div class="list2">Xu Hiện Có: ' . $datauser['balans'] . ' Xu<br/>';
echo 'Lượng Hiện Có: ' . $datauser['luong'] . ' Lượng<br/>';
echo 'Tỉ Lệ: <b>20.000</b> Xu = <b>1</b> Lượng<br/>';
echo '<b>[ <a href="?act=ok">Đổi Xu Thành Lượng</a> ]</b><br/>
<b style="color: red">Lưu ý</b>: Một ngày chỉ chuyển duy nhất được một lần 
</div>
';
break;
default:

echo '<div class="phdr"><b>Cây ATM</b></div>';

echo '- <a href="?act=ok">Đổi Xu Thành Lượng</a> <br/>
- <a href="http://choionline.cf/napthe">Nạp Lượng</a> <br/>
- <a href="http://choionline.cf/napxu">Nạp Xu</a> <br/>

</div>
';
break;

}
echo '<div class="phdr">
		« <a href="/nongtrai/?act=1"> Khỏi Cây ATM</a>
		</div>';
require('../incfiles/foot.php');
?>