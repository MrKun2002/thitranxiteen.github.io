<?php
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
include_once('../func.php');
$textl = 'Nhà bếp của tôi!';
include('../../incfiles/head.php');
// Yêu Cầu Không Xóa Dòng Này //
// Code được viết bởi Vodoivn-VTG choionline.cf //
echo '<div class="phdr">Nhà Bếp</div>';
if($user_id){
	// Học kĩ năng làm bánh
	if(isset($_GET[lambanh])){
		$int = intval($_GET[lambanh]);
		$kt_banh = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_nhabep_banh` WHERE `id` = '{$int}' AND `kinang` = '1'"), 0);
		$banh = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_nhabep_banh` WHERE `id` = '{$int}'"));
		$kt_kinang = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_nhabep_kinang` WHERE `user_id` = '{$user_id}' AND `banh_id` = '{$int}'"), 0);
		if($kt_banh > 0){
			if($kt_kinang == 0){
				if(isset($_POST[dongy])){
					if($datauser[fermer_oput] >= $banh[exp]){
					$time_nangcap = $banh[time]*65+time();
					mysql_query("UPDATE `users` SET `fermer_oput` = `fermer_oput` - {$banh[exp]} WHERE `id` = '{$user_id}'");
					mysql_query("INSERT INTO `fermer_nhabep_kinang` SET
						`user_id` = '{$user_id}',
						`banh_id` = '{$int}',
						`time_hoc` = '{$time_nangcap}'
						");
					echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bánh đã được thêm quá trình học của bạn <a href="/nongtrai/nhabep/">Quay lại</a>!</div>';
					}else{
						echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ kinh nghiệm để học làm món bánh này <a href="/nongtrai/nhabep/">Quay lại</a>!</div>';
					}
				}
				if(isset($_POST[khong])){
					header('Location: /nongtrai/nhabep/');
				}elseif(!isset($_POST[dongy]) && !isset($_POST[khong])){
					echo '<div class="rmenu" style="text-align: center; font-size: 16px;">
						Bạn có muốn học kĩ năng làm bánh này và trả đi <b>'.$banh[exp].'</b> kinh nghiệm không?
						<form action="" method="post">
							<input type="submit" name="dongy" value="Đồng Ý"/>
							<input type="submit" name="khong" value="Không"/>
						</form><br/>
						<a href="/nongtrai/nhabep/">Quay lại</a>
						</div>
					';
				}
			}else{
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã học kĩ năng này rồi nhé!</div>';
			}
		}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Không có loại bánh này, hoặc kĩ năng làm bánh này không phải học!</div>';
		}
		include('../../incfiles/end.php');
		exit;
	}
// Hiển thị thông tin hỏi làm bánh này hay không
	if(isset($_GET[id])){
	$int = intval($_GET[id]);
	$loi = 0;
	$tong = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `fermer_nhabep_lambanh` WHERE `user_id` = '{$user_id}'"), 0);
	$kt_lambanh = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `fermer_nhabep_lambanh` WHERE `user_id` = '{$user_id}' AND `banh_id` = '{$int}'"), 0);
	$kt_banh = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_nhabep_banh` WHERE `id` = '{$int}'"), 0);
	$banh = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_nhabep_banh` WHERE `id` = '{$int}'"));
	if($kt_lambanh == 0){
	if($kt_banh > 0){
	if($banh[kinang] == 1){
		$kt_kinang = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_nhabep_kinang` WHERE `user_id` = '{$user_id}' AND `banh_id` = '{$int}'"), 0);
		if($kt_kinang >= 1){
		$kinang_hoc = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_nhabep_kinang` WHERE `user_id` = '{$user_id}' AND `banh_id` = '{$int}'"));
		if($kinang_hoc[time_hoc] <= time()){
		if($tong <= $datauser['lerver_nhabep']){
		if(isset($_POST['dongy'])){
			$nguyenlieu = mysql_query("SELECT * FROM `fermer_nhabep_vatlieu` WHERE `banh_id` = '{$int}'");
			while($p_nl = mysql_fetch_array($nguyenlieu)){
				$dem_ns = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'"), 0);
				if($dem_ns > 0){
				$kiemtra = mysql_fetch_array(mysql_query("SELECT `kol` FROM `fermer_sclad` WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'"));
				if($kiemtra[kol] < $p_nl[soluong]){
					$loi++;
				}
				}else{
					$loi++;
				}
			}
			if($loi == 0){
				$nguyenlieu2 = mysql_query("SELECT * FROM `fermer_nhabep_vatlieu` WHERE `banh_id` = '{$int}'");
				while($p_nl = mysql_fetch_array($nguyenlieu2)){
				
				$kiemtra = mysql_fetch_array(mysql_query("SELECT `kol` FROM `fermer_sclad` WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'"));
				if($kiemtra[kol] == $p_nl[soluong]){
					mysql_query("DELETE FROM `fermer_sclad` WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'");
				}
				if($kiemtra[kol] > $p_nl[soluong]){
					mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol` - {$p_nl[soluong]} WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'");
				}
				}
				$timechinbanh = ($banh[time]*60)+time();
				mysql_query("INSERT INTO `fermer_nhabep_lambanh` SET
					`banh_id` = '{$int}',
					`user_id` = '{$user_id}',
					`time_chin` = '{$timechinbanh}'
				");
				header('Location: nhabep-'.$user_id.'.html');
			}else{
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ nguyên liệu để làm bánh! <a href="/nongtrai/nhabep/">Quay lại</a></div>';
			}
		}
		if(isset($_POST['khong'])){
			header('Location: nhabep-'.$user_id.'.html');
		}
		echo '<div class="rmenu" font-size: 13px;">Bạn có muốn làm <b>'.$banh[name].'</b> không?
		<br/><br/><form action="" method="post">
			<input type="submit" name="dongy" value="Đồng ý"/>
			<input type="submit" name="khong" value="Không"/>
		</form><br/>
		<a href="/nongtrai/nhabep/">Quay lại</a>
		</div>';
		}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Nhà bếp của bạn đã chật kín bánh rồi, hãy vào nâng cấp thêm nhé!<a href="/nongtrai/nhabep/">Quay lại</a></div>';
		}
		}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Kĩ năng chưa học xong hãy đợi cho kĩ năng học xong đã nhé!<a href="/nongtrai/nhabep/">Quay lại</a></div>';
		}
		}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn chưa học được kĩ năng làm món bánh này, hãy học kĩ năng này đi nhé bạn :)! <a href="/nongtrai/nhabep/">Quay lại</a></div>';
		}
	}else{
		if($tong <= $datauser['lerver_nhabep']){
			if(isset($_POST['dongy'])){
				$nguyenlieu = mysql_query("SELECT * FROM `fermer_nhabep_vatlieu` WHERE `banh_id` = '{$int}'");
				while($p_nl = mysql_fetch_array($nguyenlieu)){
					$dem_ns = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'"), 0);
					if($dem_ns > 0){
					$kiemtra = mysql_fetch_array(mysql_query("SELECT `kol` FROM `fermer_sclad` WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'"));
					if($kiemtra[kol] < $p_nl[soluong]){
						$loi++;
					}
					}else{
						$loi++;
					}
				}
				if($loi == 0){
					$nguyenlieu2 = mysql_query("SELECT * FROM `fermer_nhabep_vatlieu` WHERE `banh_id` = '{$int}'");
					while($p_nl = mysql_fetch_array($nguyenlieu2)){
					
					$kiemtra = mysql_fetch_array(mysql_query("SELECT `kol` FROM `fermer_sclad` WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'"));
					if($kiemtra[kol] == $p_nl[soluong]){
						mysql_query("DELETE FROM `fermer_sclad` WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'");
					}
					if($kiemtra[kol] > $p_nl[soluong]){
						mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol` - {$p_nl[soluong]} WHERE `id_user` = '{$user_id}' AND `semen` = '{$p_nl[nongsan_id]}' AND `mua` = '0'");
					}
					}
					$timechinbanh = ($banh[time]*60)+time();
					mysql_query("INSERT INTO `fermer_nhabep_lambanh` SET
						`banh_id` = '{$int}',
						`user_id` = '{$user_id}',
						`time_chin` = '{$timechinbanh}'
					");
					header('Location: nhabep-'.$user_id.'.html');
				}else{
					echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ nguyên liệu để làm bánh! <a href="/nongtrai/nhabep/">Quay lại</a></div>';
				}
			}
			if(isset($_POST['khong'])){
				header('Location: nhabep-'.$user_id.'.html');
			}
			echo '<div class="rmenu" font-size: 13px;">Bạn có muốn làm <b>'.$banh[name].'</b> không?
			<br/><br/><form action="" method="post">
				<input type="submit" name="dongy" value="Đồng ý"/>
				<input type="submit" name="khong" value="Không"/>
			</form>
			</div>';
		}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Nhà bếp của bạn đã chật kín bánh rồi, hãy vào nâng cấp thêm nhé! <a href="/nongtrai/nhabep/">Quay lại</a></div>';
		}
	}
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Không có loại bánh này! <a href="/nongtrai/nhabep/">Quay lại</a></div>';
	
	}
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đang làm bánh này rồi không thể làm tiếp cái nữa! <a href="/nongtrai/nhabep/">Quay lại</a></div>';
	
	}
	include('../../incfiles/end.php');
	exit;
	}
// Nhận bánh
if(isset($_GET[nhanbanh])){
	$int = intval($_GET[nhanbanh]);
	$kiemtrabanh = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_nhabep_lambanh` WHERE `user_id` = '{$user_id}' AND `id` = '{$int}'"), 0);
	if($kiemtrabanh > 0){
		$thongtin_banh = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_nhabep_lambanh` A JOIN `fermer_nhabep_banh` B ON A.banh_id = B.id WHERE `user_id` = '{$user_id}' AND A.id = '{$int}'"));
		if($thongtin_banh[time_chin] <= time()){
			mysql_query("DELETE FROM `fermer_nhabep_lambanh` WHERE `id` = '{$int}'");
			mysql_query("UPDATE `users` SET `{$thongtin_banh[donvi]}` = `{$thongtin_banh[donvi]}`+'{$thongtin_banh[trigia]}' WHERE `id` = '{$user_id}' LIMIT 1");
			echo '<div class="rmenu" style="text-align: center; font-size: 14px;">Bán bánh thành công <a href="nhabep-'.$user_id.'.html">Quay lại nhà bếp</a></div>';
		}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 14px;">Bánh chưa chín, đừng nóng vội nhé bạn ơi <a href="nhabep-'.$user_id.'.html">Quay lại nhà bếp</a></div>';
		}
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 14px;">Đây không phải bánh của bạn <a href="nhabep-'.$user_id.'.html">Quay lại nhà bếp</a></div>';
	}
	include('../../incfiles/end.php');
	exit;
}
// Nâng cấp nhà bếp
if(isset($_GET[nangcap])){
	if($datauser[lerver_nhabep] <= 15){
	if($datauser[lerver_nhabep] == 1){
		$kinhnghiem = 500;
	}elseif($datauser[lerver_nhabep] <= 5){
		$kinhnghiem = 1000*$datauser[lerver_nhabep];
	}elseif($datauser[lerver_nhabep] >= 5){
		$kinhnghiem = 3000*$datauser[lerver_nhabep];
	}
	if(isset($_POST[dongy])){
	if($datauser[lerver_nhabep] < $datauser[fermer_level] && $datauser[fermer_oput] >= $kinhnghiem){
		mysql_query("UPDATE `users` SET `lerver_nhabep` = `lerver_nhabep` + '1', `fermer_oput` = `fermer_oput` - '{$kinhnghiem}' WHERE `id` = '{$user_id}'");
		echo '<div class="rmenu" style="text-align: center; font-size: 14px;">Nâng cấp thành công, nhà bếp của bạn đã lên 1 cấp độ mới <a href="nhabep-'.$user_id.'.html">Quay lại nhà bếp</a></div>';
	}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 14px;">Bạn không đủ kinh nghiệm để có thể nâng cấp <a href="nhabep-'.$user_id.'.html">Quay lại nhà bếp</a></div>';
	}
	}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 14px;">Bạn có muốn nâng cấp nhà bếp của mình lên 1 cấp độ mới và tiêu hao mất <b>'.$kinhnghiem.'</b> kinh nghiệm không
	<form action="" method="post">
	<input type="submit" name="dongy" value="Đồng Ý"/>
	<input type="submit" name="khong" value="Không"/>
	</form>
	</div>';
	}
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 14px;">Cấp độ của nhà bếp của bạn đã tối đa <a href="nhabep-'.$user_id.'.html">Quay lại nhà bếp</a></div>';
	}
	include('../../incfiles/end.php');
	exit;
}
// Danh sách bánh đang trong lò
if(isset($_GET[danhsach])){
	$int = intval($_GET[danhsach]);
	if($int == $user_id){
	$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_nhabep_lambanh` WHERE `user_id` = '{$int}'"), 0);
	echo '<div class="list4">Cấp độ nhà bếp: <b>'.$datauser[lerver_nhabep].'</b> [<b><a href="nangcap.html">Nâng cấp nhà bếp</a></b>]</div>';
	if($tong > 0){
	$res = mysql_query("SELECT *, A.id as `lambanh_id` FROM `fermer_nhabep_lambanh` A JOIN `fermer_nhabep_banh` B ON A.banh_id = B.id WHERE `user_id` = '{$int}' ORDER BY `time_chin` DESC LIMIT $start, $kmess");
	while($post = mysql_fetch_array($res)){
		$tinhtime = $post[time_chin] - time();
		$timechin = timeonline($tinhtime);
		echo '<div class="nenfr"><table><tr><td>';
		echo '<img style="border-radius: 5px;" src="image/'.$post[banh_id].'.png"/" width="30" height="30">';
		echo '</td><td style="vertical-align: top; font-size: 12px;">
		<b>'.functions::checkout($post[name]).'</b><br/>';
		if($tinhtime > 0){
			echo 'Thời gian ra lò: '.$timechin.'.<br/>';
		}else{
			echo 'Trị Giá: <b>'.$post[trigia].'</b> ';
			if($post[donvi] == 'luong'){
			echo 'Lượng';
			}else{
				echo 'Xu';
			}
			echo '<br/>[<b><a href="nhanbanh_'.$post[lambanh_id].'.html">Bán bánh</a></b>]';
		}
		echo '</td></tr>
		</table>
		</div>';
	}
	if ($tong > $kmess){ //Phân Trang
	echo '<div class="trang">' . functions::display_pagination2('nhabep-'.$user_id, $start, $tong, $kmess) . '</div>';
	}
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Nhà bếp của bạn đang bỏ trống, chưa nổi lửa</div>';
	}
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Đây không phải lò bánh của bạn</div>';
	}
	echo '<div class="list5"><a href="/nongtrai/nhabep/">Danh sách bánh các loại bánh</a></div>';
	include('../../incfiles/end.php');
	exit;
}
	$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_nhabep_banh`"), 0);
	$res = mysql_query("SELECT * FROM `fermer_nhabep_banh` WHERE `id` ORDER BY `id` ASC");
	while($post = mysql_fetch_array($res)){
		echo '<div class="nenfr"><table><tr><td>';
		echo '<img src="image/'.$post[id].'.png"/" width="30" height="30">';
		echo '</td><td style="vertical-align: top; font-size: 12px;">';
		if($post[kinang] == 0){
		echo '<a href="?id='.$post[id].'"><b>'.functions::checkout($post[name]).'</b></a><br/>';
		}else{
			$dem_kinang = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_nhabep_kinang` WHERE `user_id` = '{$user_id}' AND `banh_id` = '{$post[id]}'"), 0);
			if($dem_kinang > 0){
			$kiemtra_kinang = mysql_fetch_array(mysql_query("SELECT * FROM `fermer_nhabep_kinang` WHERE `user_id` = '{$user_id}' AND `banh_id` = '{$post[id]}'"));
				if($kiemtra_kinang[time_hoc] <= time()){
					echo '<a href="?id='.$post[id].'"><b>'.functions::checkout($post[name]).'</b></a>';
					echo '<br/>[<b>Đã học</b>]<br/>';
				}else{
					echo '<b>'.functions::checkout($post[name]).'</b>';
					$tinhtime_hoc = $kiemtra_kinang[time_hoc]-time();
					if($tinhtime_hoc > 0){
						echo '<br/>[ Đang học: <b style="color: red;">'.timeonline($tinhtime_hoc).'</b> ]<br/>';
					}else{
						echo '<br/>[<b>Đã học</b>]<br/>';
					}
				}
			}else{
			echo '<b>'.functions::checkout($post[name]).'</b>';
			echo '<br/> [ <a href="hoc_'.$post[id].'.html"><b>Học Kĩ Năng</b></a> ]<br/>';
			}
		}
		echo 'Thời gian: '.$post[time].' phút.<br/>';
		echo 'Thu Nhập: '.$post[trigia].' ';
		if($post[donvi] == 'luong'){
			echo 'Lượng';
		}else{
			echo 'Xu';
		}
		echo '.<br/>';
		$vatlieu = mysql_query("SELECT * FROM `fermer_nhabep_vatlieu` WHERE `banh_id` = '$post[id]'");
		while($view_vatlieu = mysql_fetch_array($vatlieu)){
			if($view_vatlieu['nongsan_id'] == 50){
				$img_ns = '../vatnuoi/img/trung.png';
			}
			elseif($view_vatlieu['nongsan_id'] == 52){
				$img_ns = '../vatnuoi/img/suabo.png';
			}
			elseif($view_vatlieu['nongsan_id'] == 53){
				$img_ns = '../vatnuoi/img/longcuu.png';
			}else{
				$img_ns = '../img/sv1/'.$view_vatlieu[nongsan_id].'.png';
			}
			echo '<img src="'.$img_ns.'" width="15px" height="15px"/> '.$view_vatlieu['ten_ns'].' x '.$view_vatlieu['soluong'].' ';
		}
		echo '</td></tr>
		</table>
		</div>';
	}
	echo '<div class="list5"><a href="/nongtrai/nhabep/nhabep-'.$user_id.'.html">Lò Bánh Của Bạn</a></div>';
}else{
msg('Bạn Chưa Đăng Nhập!');
}
include('../../incfiles/end.php');
?>