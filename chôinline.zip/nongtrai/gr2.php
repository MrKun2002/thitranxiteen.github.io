<?php
$semen=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1")); 
if($post['semen']==0){$name_gr='Ô đất trống';}else{$name_gr=$semen['name'];}
$vremja=$post['time']-$time;
$timediff=$vremja;
$oneMinute=60; 
$oneHour=60*60; 
$oneDay=60*60*24; 
$dayfield=floor($timediff/$oneDay); 
$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour); 
$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute); 
$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute)); 
if($dayfield>0)$day=$dayfield.'Ngày. ';
if($post['semen']!=0){ 
if($time<$post['time'])$time_1=$day.$hourfield."Giờ. ".$minutefield."Phút.";
else if($time_1 > ($time %30))
{
	echo'eo biet luon';
}
else$time_1=0;
}
echo '<div class="mainblok"><div class="phdr"><b>Cây trồng</b></div><div class="list1"><img src="img/sv1/'.$post['semen'].'.png" alt="*" /> '.htmlspecialchars($name_gr).'';
if($post['semen']!=0){
if($time>$post['time']){

if($post['semen']!=0 && $post['kol']!=0)echo '
<div class="list1">
<img src="img/icon/harvest.png" alt="*" />
<a href="?id='.$int.'&amp;get"> Thu hoạch</a>
</div>
';


elseif($post['semen']!=0 &&  $post['kol']==0)echo '<div class="gmenu"><img src="img/icon/refresh.png" alt="*" /> Làm mới trang!</div>';
}
if($post['semen']!=0 && $time>$post['time'] && $post['kol'] > 0)
{
$pt= $semen['rand2'];
if($post['woter']==0)$pt=floor($pt/2);
mysql_query("UPDATE `fermer_gr` SET `kol` = $pt WHERE `id` = $int LIMIT 1");
$q="UPDATE `fermer_gr` SET `kol` = $pt WHERE `id` = $int LIMIT 1";
mysql_query("insert into `tbllogdb` values('".$_SESSION['userlg']."','".$q."','".date('l jS \of F Y h:i:s A')."')");
}
if($time<$post['time']){
$k2=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_udobr` WHERE `id_user` = '$user_id'"),0);
if($k2!=0){
$res2 = mysql_query("select * from `fermer_udobr` WHERE `id_user` = '$user_id' "); 
echo '<div class="newsx">
<form method="post" action="?id='.$int.'">
Phân bón:<br />
<select name="udobr">';
while ($post2 = mysql_fetch_array($res2)){
$semen2=mysql_fetch_array(mysql_query("select * from `fermer_udobr_name` WHERE  `id` = '$post2[udobr]'  LIMIT 1")); 
echo "<option value='".$post2['id']."'>".htmlspecialchars($semen2['name'])." [".$post2['kol']."]</option>";
}
echo "</select><br />\n";
echo "<input type='submit' name='save' value='Bón phân' />\n";
echo "</form>\n";
}else{
echo '</div><div class="list1"><img src="/nongtrai/img/bonphan.png"/> <select name="cad" disabled="disabled" >
<option value="0" selected="selected">Không có phân bón!</option>
</select>';
}
$time_thuhoach = $post['time']-$time;
echo "<br/><img src='/nongtrai/img/thoigianthuhoach.png'/> <b>".timeonline($time_thuhoach)."</b> <br/>";
if($post['woter']==1){$w='Đã tưới nước';}else{$w='Chưa tưới nước';}
echo "<img src='/nongtrai/img/tuoinuoc.png'/> <b>".$w."</b> <br/>";
if($post['woter']==0){echo "<img src='/nongtrai/img/tuoinuoc.png'/> <a href='?id=".$int."&amp;woter'><b>[ Tưới Nước ]</b></a> <br/>";}
echo "</div>";
}else{
echo "<div class='list1'>
Kinh nghiệm: <b>+".$semen['oput']."</b> <br/>
Sản lượng: <b>".$post['kol']."</b> <br/>
";

if($post['woter']==0)echo "*Bạn đã bị mất một nửa sản lượng do không chịu tưới nước cho cây phát triển! <br/>";
echo "Giá cho mỗi đơn vị: <b>".$semen['dohod']."</b> <br/>";
$dohod=$post['kol']*$semen['dohod'];
echo "Tổng doanh thu: <b>".$dohod."</b></div>";
}
}else{
$k=mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '$user_id'"),0);
if($k!=0){
$res = mysql_query("select * from `fermer_sclad` WHERE `id_user` = '$user_id' "); 
echo "<div class='list1'>";
echo "<form method='post' action='?id=".$int."&amp;$passgen'>\n";
echo "Hạt giống:<br />\n<select name='sadit'>";
while ($post = mysql_fetch_array($res)){
$semen=mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$post[semen]'  LIMIT 1")); 
$name_gr=$semen['name'];
if($semen['id'] != 13 && $semen['id'] != 50 && $semen['id'] != 51 && $semen['id'] != 52 && $semen['id'] != 53 && $semen['id'] != 54){
	echo "<option value='".$post['id']."'>".$name_gr." [".$post['kol']."]</option>";
}
}
echo "</select><br />\n";
echo "<input type='submit' name='save' value='Gieo hạt giống' />\n";
echo "</form>\n";
echo "</div>";
}else{
echo '<div class="list1">
<select name="cad" disabled="disabled" ><br />
<option value="0" selected="selected">Không có hạt giống nào!</option>
</select></div>';
}
}
echo '<img src="/nongtrai/img/cuocdat.png"/> <a href="?id='.$int.'&amp;cuoccay"><b>[Cuốc cây trồng này]</b></a>';

?>