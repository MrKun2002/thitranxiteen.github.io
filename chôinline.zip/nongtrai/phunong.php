<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl ='TOP Phú Nông';
require('../incfiles/head.php');
if (!$user_id) {
echo functions::display_error($lng['access_guest_forbidden']);
require('../incfiles/end.php');
exit;
}
echo'<div class="mainblok"><div class="phdr"><b>TOP Phú Nông</b></div>';
$req = mysql_query("SELECT *  FROM `users` ORDER BY `balans` DESC LIMIT 10");
$i = 1;
while ($res=mysql_fetch_array($req)) {
//mau nick
if ($res['rights'] == 0 ) {
$colornick['colornick'] = '000000';
}
if ($res['rights'] == 1 ) {
$colornick['colornick'] = 'FFD700';
}
if ($res['rights'] == 2 ) {
$colornick['colornick'] = '7192a8';
}
if ($res['rights'] == 3 ) {
$colornick['colornick'] = '0000FF';
}
if ($res['rights'] == 4 ) {
$colornick['colornick'] = '40E000';
}
if ($res['rights'] == 5 ) {
$colornick['colornick'] = '40E000';
}
if ($res['rights'] == 6 ) {
$colornick['colornick'] = '228622';
}
if ($res['rights'] == 7 ) {
$colornick['colornick'] = '860086';
}
if ($res['rights'] == 8 ) {
$colornick['colornick'] = 'FF0000';
}
if ($res['rights'] == 9 ) {
$colornick['colornick'] = 'FF0000';
}
if ($res['rights'] == 10 ) {
$colornick['colornick'] = '7192a8';
}
//het mau nick
echo '<div class="list1">';
echo '<b><a href="/users/profile.php?user='.$res['id'].'">';
if (file_exists(('../files/users/avatar/' . $res['id'] . '.png'))) {
echo '<img src="../files/users/avatar/'.$res['id'].'.png"width="20"height="20"alt="'.$res['id'].'" class="chatbox_avatar chatbox_avatar_online"/>';
} else {
echo '<img src="../images/empty.png"width="20"height="20"alt="'.$res['id'].'"class="chatbox_avatar chatbox_avatar_online"/>';
}
echo'<font color="#'.$colornick['colornick'].'">'.$res['name'].'</font></a></b><br/><img src="http://choionline.cf/images/money_bag.png"> '.$res['balans'].'Xu<br/>';
echo' Level: '.$res['fermer_level'].'';
echo'<br/> EXP: '.$res['fermer_oput'].'';
echo '</div>';
$i++;
}
echo '</div>';
require('../incfiles/foot.php');
?>