<?php
$int=intval($_GET['id']);
if(!$int){
echo '<div class="rmenu">Lỗi Link dẫn!</div>';
require('../incfiles/foot.php');
exit;
}
$sql=mysql_query("SELECT `id` FROM `fermer_name` WHERE `id`='$int' ");
$row=mysql_fetch_assoc($sql);
if(!mysql_num_rows($sql)){
echo '<div class="rmenu">Lỗi Link Dẫn! Hoặc link không tồn tại</div>';
echo "<div class='phdr'>";
echo "&laquo; <a href='shop.php'>Cửa Hàng Hạt giống</a>";
echo "</div>";
require('../incfiles/foot.php');
exit;
}
$post = mysql_fetch_array(mysql_query("select * from `fermer_name` WHERE  `id` = '$int'  LIMIT 1"));
if($post[id] != 50 && $post[id] != 51 && $post[id] != 52 && $post[id] != 53 && $post[id] != 54){
// cua hang hoa qua
if($level>=$post['level']){
$timediff=$post['time'];
$oneMinute=60;
$oneHour=60*60;
$oneDay=60*60*24;
$dayfield=floor($timediff/$oneDay);
$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour);
$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute);
$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute));
if($dayfield>0)$day=$dayfield.' ngày ';
if($minutefield>0)$minutefield=$minutefield." phút";else$minutefield='';
$time_1=$day.$hourfield." giờ ".$minutefield;
echo "<div class='mainblok'><div class='phdr'><b>Mua hạt giống</b></div>";
echo '<div class="list1"><img src="img/sv1/'.$post['id'].'.png" alt="*" /> '.htmlspecialchars($post['name']).'';
echo '<img src="img/icon/money.png" alt="*" /> Giá: '.$post['cena'].'';
echo '<br /><img src="img/icon/experience.png" alt="*" /> Kinh Nghiệm: +'.$post['oput'].'';
echo '<br />Thời Gian Sinh truởng: <b>'.$time_1.'</b> <br/>Số Lượng Thu hoạch: <b>~'.$post['rand2'].'</b><br/>Giá 1 đơn vị : <b>'.$post['dohod'].'</b> <br/>';
$dohod=$post['rand2']*$post['dohod'];
echo '
Tổng thu nhập '.$dohod.'</b> Xu';
echo '<form method="post" action="?id='.$int.'&amp;'.$passgen.'">
Số Luợng Mua :<br />
<input type="text" name="kupit" size="4"/><input type="submit" name="save" value="Mua" />
</form>
</div>';
$_POST['kupit']=(int)$_POST['kupit'];
$kup=$post['cena']*$_POST['kupit'];
if(isset($_POST['kupit']) && $datauser['balans']>=$kup && $_POST['kupit']>0 && $_POST['kupit'] <= 60)
{
if($datauser[balans] - $kup > 0){
$remils = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '$user_id' AND `mua` = 1 AND `semen` = '$int'"),0);
if($remils>0) mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol`+ '".$_POST['kupit']."' WHERE `id_user` = $user_id AND `mua` = 1 AND `semen` = '$int' LIMIT 1");
else mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`,`mua`) VALUES  ('".$_POST['kupit']."', '".$int."', '".$user_id."','1') ");
mysql_query("UPDATE `users` SET `balans` = `balans`- $kup WHERE `id` = $user_id LIMIT 1");
$q="UPDATE `users` SET `balans` = `balans`- $kup WHERE `id` = $user_id LIMIT 1";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/shop_info.php','".date('d-m-Y  h:i:s A')."')");
header('Location: cuahang.html?buy_ok');
}else{
header('Location: shop.php?buy_no');
}
}
if($_POST['kupit'] > 60){
header('Location: shop.php?buy_no');
}
if(isset($_POST['kupit']) && strlen($_POST['kupit'])==0 || isset($_POST['kupit']) && $_POST['kupit']<1) msg("Bạn Chưa nhập số lượng!");
if(isset($_POST['kupit']) && $datauser['balans']<$kup)header('Location: shop.php?buy_no');
}else{
echo 'bạn không đủ cấp độ để trồng cây này';
}
/// Mod cua hang vat nuoi
}else{
	//Cua hang vat nuoi
	$tongvatnuoi50 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE  `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '50'"), 0);
	$tongvatnuoi51 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE  `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '51'"), 0);
	$tongvatnuoi52 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE  `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '52'"), 0);
	$tongvatnuoi53 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE  `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '53'"), 0);
	$tongvatnuoi54 = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_vatnuoi` WHERE  `id_user` = '".$datauser["id"]."' AND `vatnuoi` = '54'"), 0);
	if(isset($_GET['mua'])){

		if($post['id'] != 52 && $post['id'] != 53){
			if($datauser['balans'] >= $post['cena']){
				if($post['id'] == 50 && $datauser['farm_vatnuoi']*3 > $tongvatnuoi50){
				mysql_query("INSERT INTO `fermer_vatnuoi` (`vatnuoi`, `id_user`, `time`) VALUES  ('".$post["id"]."', '".$user_id."', '".time()."') ");
				mysql_query("UPDATE `users` SET `balans` = `balans`- '".$post["cena"]."' WHERE `id` = '".$user_id."' LIMIT 1");
				$q="UPDATE `users` SET `balans` = `balans`- '".$post["cena"]."' WHERE `id` = '".$user_id."' LIMIT 1";
				mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/shop_info.php','".date('d-m-Y  h:i:s A')."')");
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Mua thành công!</div>';
				}elseif($post['id'] == 50){
					echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Gà trong nông trại đã full rồi bạn ơi!</div>';
				}
				if($post['id'] == 51 && $datauser['farm_vatnuoi'] > $tongvatnuoi51){
				mysql_query("INSERT INTO `fermer_vatnuoi` (`vatnuoi`, `id_user`, `time`) VALUES  ('".$post["id"]."', '".$user_id."', '".time()."') ");
				mysql_query("UPDATE `users` SET `balans` = `balans`- '".$post["cena"]."' WHERE `id` = '".$user_id."' LIMIT 1");
				$q="UPDATE `users` SET `balans` = `balans`- '".$post["cena"]."' WHERE `id` = '".$user_id."' LIMIT 1";
				mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/shop_info.php','".date('d-m-Y  h:i:s A')."')");
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Mua thành công!</div>';
				}elseif($post['id'] == 51){
					echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Lợn trong nông trại đã full rồi bạn ơi!</div>';
				}
				if($post['id'] == 54 && $datauser['farm_vatnuoi']+1 > $tongvatnuoi54){
				mysql_query("INSERT INTO `fermer_vatnuoi` (`vatnuoi`, `id_user`, `time`) VALUES  ('".$post["id"]."', '".$user_id."', '".time()."') ");
				mysql_query("UPDATE `users` SET `balans` = `balans`- '".$post["cena"]."' WHERE `id` = '".$user_id."' LIMIT 1");
				$q="UPDATE `users` SET `balans` = `balans`- '".$post["cena"]."' WHERE `id` = '".$user_id."' LIMIT 1";
				mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/shop_info.php','".date('d-m-Y  h:i:s A')."')");
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Mua thành công!</div>';
				}elseif($post['id'] == 54){
					echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Cá trong ao cá đã full rồi bạn ơi!</div>';
				}
			}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ xu để mua thú nuôi này!</div>';
			}
		}else{
			if($datauser['luong'] >= $post['cena']){
				if($post['id'] == 52 && $datauser['farm_vatnuoi']-1 > $tongvatnuoi52){
				mysql_query("INSERT INTO `fermer_vatnuoi` (`vatnuoi`, `id_user`, `time`) VALUES  ('".$post["id"]."', '".$user_id."', '".time()."') ");
				mysql_query("UPDATE `users` SET `luong` = `luong`- '".$post["cena"]."' WHERE `id` = '".$user_id."' LIMIT 1");
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Mua thành công!</div>';
				}elseif($post['id'] == 52){
					echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bò trong nông trại đã full rồi bạn ơi!</div>';
				}
				if($post['id'] == 53 && $datauser['farm_vatnuoi']-1 > $tongvatnuoi53){
				mysql_query("INSERT INTO `fermer_vatnuoi` (`vatnuoi`, `id_user`, `time`) VALUES  ('".$post["id"]."', '".$user_id."', '".time()."') ");
				mysql_query("UPDATE `users` SET `luong` = `luong`- '".$post["cena"]."' WHERE `id` = '".$user_id."' LIMIT 1");
				echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Mua thành công!</div>';
				}elseif($post['id'] == 53){
					echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Cừu trong nông trại đã full rồi bạn ơi!</div>';
				}
			}else{
			echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ lượng để mua thú nuôi này!</div>';
			}
		}
	}
	$timediff=$post['timelon'];
	$oneMinute=60;
	$oneHour=60*60;
	$oneDay=60*60*24;
	$dayfield=floor($timediff/$oneDay);
	$hourfield=floor(($timediff-$dayfield*$oneDay)/$oneHour);
	$minutefield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour)/$oneMinute);
	$secondfield=floor(($timediff-$dayfield*$oneDay-$hourfield*$oneHour-$minutefield*$oneMinute));
	if($dayfield>0)$day=$dayfield.' ngày ';
	if($minutefield>0)$minutefield=$minutefield." phút";else$minutefield='';
	$time_2=$day.$hourfield." giờ ".$minutefield;
	$timechet=floor($post['timechet']/60/60/24);
	echo "<div class='mainblok'><div class='phdr'><b>Mua Vật Nuôi</b></div>";
	if($post['id'] != 52 && $post['id'] != 53){
	echo '
	<div class="list1"><img src="img/sv1/'.$post['id'].'.png" alt="*" /> '.htmlspecialchars($post['name']).'</div>
	<div class="list1">Giá: '.$post['cena'].' Xu';
	echo '<br /> Kinh Nghiệm: +'.$post['oput'].'';
	echo '<br />Thời Gian Lớn: <b>'.$time_2.'</b> <br/>';
	echo 'Thời gian sống: <b>'.$timechet.' ngày</b> <br/>';
		if($post['id'] == 50){
			echo 'Sản lượng: ~<b>'.($post['rand1']*2).' trứng</b> <br/>';
		}else{
			echo 'Vật nuôi lớn bán được: ~<b>'.($post['rand2']).' Xu</b> <br/>';
		}
	echo '1 ngày không cho ăn sẽ chêt<br/>';
	echo '<b>[<a href="cuahang.html?id='.$post['id'].'&mua"> Mua về nuôi</a> ]</b></div>';
	}else{
	echo '
	<div class="list1"><img src="img/sv1/'.$post['id'].'.png" alt="*" /> '.htmlspecialchars($post['name']).'</div>
	<div class="list1"><img src="img/icon/money.png" alt="*" /> Giá: '.$post['cena'].' Lượng';
	echo '<br /><img src="img/icon/experience.png" alt="*" /> Kinh Nghiệm: +'.$post['oput'].'';
	echo '<br />Thời Gian Lớn: <b>'.$time_2.'</b> <br/>';
	echo 'Thời gian sống: <b>'.$timechet.' ngày</b> <br/>';
		if($post['id'] == 52 || $post['id'] == 53){
			if($post['id'] == 53){
			echo 'Sản lượng: ~<b>'.($post['rand1']*2).' lông cừu</b> <br/>';
			}
			if($post['id'] == 52){
			echo 'Sản lượng: ~<b>'.($post['rand1']*2).' sữa</b> <br/>';
			}
		}else{
			echo 'Vật nuôi lớn bán được: ~<b>'.($post['rand2']).' Xu</b> <br/>';
		}
	echo '1 ngày không cho ăn sẽ chêt<br/>';
	echo '<b>[<a href="cuahang.html?id='.$post['id'].'&mua"> Mua về nuôi</a> ]</b></div>';
	}
	//ket thuc cua hang vat nuoi
}
?>