<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Thông tin khế';
require('../incfiles/head.php');
if(isset($_GET['id']))
$int = intval($_GET['id']);
$kiemtra = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$datauser["id"]."'"));
if($kiemtra['id'] == $int){
if(isset($_GET['thuhoach_yes'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Thu hoạch khế thành công</div>';
if(isset($_GET['thuhoach_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Ú là. Khế đã đến thời gian thu hoạch đâu bạn. Xanh lè à! ^^</div>';
if(isset($_GET['nangcap_yes'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Nâng cấp khế thành công</div>';
if(isset($_GET['nangcap_no'])) echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ tiền để nâng cấp khế!</div>';

// thu hoach khe
if(isset($_GET['thuhoach']) && time() >= $datauser['tgcaykhe'] + 7200){
	if($datauser['leve-caykhe'] == 0){
		$sanluongkhe = 30;
	}else{
		$sanluongkhe = 30*$datauser['leve-caykhe']+5;
	}
	$kiemtrakhe = mysql_fetch_array(mysql_query("SELECT `semen` FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '13'"));
	//$tongkhe = mysql_result(mysql_query("SELECT `semen` FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '13'"));
		// Mod gộp sản lượng khế vào trong kho //
		if($kiemtrakhe['semen'] == 13){
			$tongkhe = mysql_result(mysql_query("SELECT COUNT(*) FROM `fermer_sclad` WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '13'"), 0);
			if($tongkhe == 1){
			mysql_query("UPDATE `fermer_sclad` SET `kol` = `kol` + '".$sanluongkhe."' WHERE `id_user` = '".$datauser["id"]."' AND `semen` = '13' ");
			}else{
				echo 'Số khế dư thừa trong kho của bạn quá nhiều hãy vào bán bớt đi, để lưu trữ tiếp nhé!';
			}
		}else{
			mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$sanluongkhe."', '13', '".$datauser["id"]."') ");
			}
	//mysql_query("INSERT INTO `fermer_sclad` (`kol` , `semen`, `id_user`) VALUES  ('".$sanluongkhe."', '13', '".$datauser["id"]."') ");

	
	mysql_query("UPDATE `users` SET `tgcaykhe` = '".time()."' WHERE `id`='".$datauser["id"]."'");
	//echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã thu hoạch khế thành công</div>';
	header('Location: khe'.$datauser[id].'&thuhoach_yes');
}elseif(isset($_GET['thuhoach']) && time() < $datauser['tgcaykhe'] + 7200){
	header('Location: khe'.$datauser[id].'&thuhoach_no');
}
// nag cap khe
if($datauser['leve-caykhe'] < 10){
	if(isset($_GET['nangcap']) && time() < $datauser['tgcaykhe'] + 7200){
		if($datauser['leve-caykhe'] == 0){
			$tiennc = 3000;
		}else{
			$leverck = $datauser['leve-caykhe'];
			$tiennc = 9000*$leverck+500;
		}
		if($datauser['balans'] >= $tiennc){
			mysql_query("UPDATE `users` SET `leve-caykhe` = `leve-caykhe` + '1' WHERE `id` = '".$datauser["id"]."' LIMIT 1");
			mysql_query("UPDATE `users` SET `balans` = `balans` - $tiennc WHERE `id` = '".$datauser["id"]."' LIMIT 1");
			$q="UPDATE `users` SET `balans` = `balans` - $tiennc WHERE `id` = '".$datauser["id"]."' LIMIT 1";
			mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./nongtrai/caykhe.php','".date('d-m-Y  h:i:s A')."')");
			header('Location: khe'.$datauser[id].'&nangcap_yes');
		}else{
			header('Location: khe'.$datauser[id].'&nangcap_no');
		}
	}elseif(isset($_SET['nangcap']) && time() >= $datauser['tgcaykhe'] + 7200){
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn ơi, khế phải xanh mới được nâng cấp nha. Chín nâng cấp mình thiệt đó</div>';
	}
}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Cây khế của bạn đã đạt cấp độ tối đa rồi. Không thể nâng cấp nữa</div>';
}
echo '<div class="mainblok"><div class="phdr" style="font-weight: bold;">Nông Trại</div>';
if($datauser['giaodien'] == 0){
		require('../nongtrai/my2.php');
		}else{
		require('../nongtrai/my.php');
		}
echo '<div class="mainblok"><div class="phdr" style="font-weight: bold;">Thông Tin Cây Khế</div>';
echo '<div class="list1">';
if(time() >= $datauser['tgcaykhe'] + 7200){
if($datauser['leve-caykhe'] == 0){
		$sanluongkhe = 30;
	}else{
		$sanluongkhe = 30*$datauser['leve-caykhe']+5;
	}
echo '<table>
		<tr>
			<td width="15%">
				<img src="/images/caykhechin.png" width="100px"/></a>
			</td>
			<td width="90%">
				<b>Cây Khế</b><br/>';
					if($datauser['leve-caykhe'] != 10){
						echo '<img src="img/thongtink.png"><b>Cấp Độ Khế: <span style="color: blue">'.$datauser['leve-caykhe'].'</span><br/>';
					}elseif($datauser['leve-caykhe'] == 10){
						echo '<img src="img/thongtink.png"><b>Cấp Độ Khế: <span style="color: blue">'.$datauser['leve-caykhe'].' [MAX]</span><br/>';
					}
				echo '
				<img src="img/thuhoachk.png"><b>[ <a href="khe'.$datauser['id'].'&thuhoach">Thu Hoạch Khế</a> ]</b> (Sản lượng: <b>'.$sanluongkhe.'<b> Quả)<br/>
			</td>
		</tr>
	  </table>
</div>
';
}else{
	echo ' 
	<table>
		<tr>
			<td width="15%">
				<img src="/images/caykhe.png" width="100px"><br>
			</td>
			<td width="90%">
			<b>Cây Khế</b><br/>';
				if($datauser['leve-caykhe'] != 10){
				echo '<img src="img/thongtink.png"><b>Cấp Độ Khế: <span style="color: blue">'.$datauser['leve-caykhe'].'</span><br/>';
				}elseif($datauser['leve-caykhe'] == 10){
				echo '<img src="img/thongtink.png"><b>Cấp Độ Khế: <span style="color: blue">'.$datauser['leve-caykhe'].' [MAX]</span><br/>';
				}
				$timethukhe = $datauser['tgcaykhe']+7200 - time();
				$tinhtimephut = floor($timethukhe/60);
				$tinhtimegio = floor($tinhtimephut/60);
				$tinhtimegiodu = floor($tinhtimephut%60);
				if($tinhtimegio == 0){
					echo '<img src="/images/dongho.png" width="25px"> Còn: '.$tinhtimephut.' phút nữa sẽ thu hoạch';
				}elseif($tinhtimegio < 0){
					echo '<img src="/images/dongho.png" width="25px"> Khế tạm thời không thể tính giờ, hãy đợi thu khế lần này xong nhé!';
				}
				else{
					echo '<img src="/images/dongho.png" width="25px"> Còn: '.$tinhtimegio.' giờ '.$tinhtimegiodu.' phút nữa sẽ thu hoạch';
				}
				if($datauser['leve-caykhe'] == 0){
				$tiennc = 3000;
				}elseif($datauser['leve-caykhe'] >= 9){
					$leverck = $datauser['leve-caykhe'];
					$tiennc = 15000*$leverck+500;
				}else{
					$leverck = $datauser['leve-caykhe'];
					$tiennc = 9000*$leverck+500;
				}
echo'<br/>
	<img src="img/nangcapk.png"><b>[ <a href="khe'.$datauser['id'].'&nangcap">Nâng cấp cây khế</a> ]</b> (Giá: '.$tiennc.' Xu<b> )
			</td>
			</tr>
		  </table>
';
echo '</div>';
}
}else{
	echo '<div class="list1">Không phải cây khế của bạn rồi, chọn lại nhé!</div>';
}
echo '<div class="phdr">« <a href="/nongtrai/">Nông trại</a></div>';
require('../incfiles/foot.php');
?>