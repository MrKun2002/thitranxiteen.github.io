<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
include_once('func.php');
$textl = 'Cửa hàng phân bón!';
require('../incfiles/head.php');
if($user_id){
if(isset($_GET['buy_ok']))msg('Mua! Thành Công');
if(isset($_GET['buy_no'])) msg("Không đủ tiền!");

if(isset($_GET['id'])){
include 'shop_udobr_info.php';
}else{
echo '<div class="list1"><b><a href="cuahang.html">Tạp Hóa</a> | Cửa Hàng Phân Bón</b></div>';
include 'shop_udobr_index.php';
}
echo "<div class='phdr'>";
echo "&raquo; <a href='my.php'>Trang trại</a>";
if(isset($_GET['id']))echo " | &laquo; <a href='shop_udobr.php'>Cửa hàng phân bón</a>";
echo "</div></div>";
}else{
msg('Vui lòng đăng nhập!');
}require('../incfiles/foot.php');
?>
