<?php
define('_IN_JOHNCMS', 1);
$rootpath = '';
require('incfiles/core.php');
if (isset($_POST['msg'])) {
   $msg = isset($_POST['msg']) ? mb_substr(trim($_POST['msg']), 0, 150) : '';
   $flood = functions::antiflood();
   if ($ban['1'] || $ban['13'])
       $error[] = $lng['access_forbidden'];
   if ($flood)
       $error = $lng['error_flood'] . ' ' . $flood . '&#160;' . $lng['seconds'];
   if (!$error) {
       $req = mysql_query("SELECT * FROM `guest` WHERE `user_id` = '$user_id' ORDER BY `time` DESC");
       $res = mysql_fetch_array($req);
       if ($res['text'] == $msg) {
           exit;
       }
   }   
   if (!$error && mb_strlen($msg) >= 2) {
		 $bantv = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_ban_users` WHERE `user_id` = '".$datauser["id"]."' AND `wap` = '1'"), 0);
		 if($user_id){
		 if($bantv == 0){
		 $kiemtime = mysql_fetch_array(mysql_query("SELECT * FROM `guest` WHERE `user_id` = '$user_id' ORDER BY `id` DESC LIMIT 1"));
		 $tinhtimepost = $kiemtime['time']+5;
		 if($tinhtimepost <= time()){
            $msg = str_replace(array_keys($timkiemkitumahoa), $timkiemkitumahoa,$msg);
		
		if(mysql_query("INSERT INTO `guest` SET
            `adm` = '$admset',
            `time` = '" . time() . "',
            `user_id` = '$user_id',
            `name` = '$from',
            `text` = '" . mysql_real_escape_string($msg) . "',
            `ip` = '" . core::$ip . "',
            `browser` = '" . mysql_real_escape_string($agn) . "'
       ") == TRUE){
		    noel_chat_box(mysql_real_escape_string($msg),$datauser);
			botchat(mysql_real_escape_string($msg));
	   }
	    
       if ($user_id) {
          $postguest = $datauser['postguest'] + 1;
          mysql_query("UPDATE `users` SET `postguest` = '$postguest', `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
       }
	  }else{
	   echo '<div class="list4">Bạn viết quá nhanh hãy đợi 5 giây sau rồi viết tiếp</div>';
	  }
	  }else{
	  echo '<div class="list4">Bạn không được đăng bài viết này. Thử nghiệm :D</div>';
	  }
	  }else{
	  echo '<div class="list4">Bạn chưa đăng nhập</div>';
	  }
   }else{
	echo '<div class="list4">Bạn nhập nhập văn bản quá ngắn</div>';
   }
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0'"), 0);
  if ($total) {
        $req = mysql_query("SELECT `guest`.*, `guest`.`id` AS `gid`, `users`.`lastdate`, `users`.`id`, `users`.`rights`, `users`.`name`
                    FROM `guest` LEFT JOIN `users` ON `guest`.`user_id` = `users`.`id`
                    WHERE `guest`.`adm`='0' ORDER BY `time` DESC LIMIT ".(!$is_mobile ? 5 : 5).""); 
echo '<div class="forumtxt">';
        while ($gres = mysql_fetch_assoc($req)) {
				$chars=str_split($gres['text']);
				$count=0;
				foreach($chars as &$chars)
				{
					if($chars==':' || $chars=='/' || $chars==';' || $chars == '-' || $chars == '*'  || $chars == '^')
					{
						$count++;
					}
				}
				$post = functions::checkout($gres['text']);
				if($count >= 4){
					$post = str_replace(array_keys($timkiem2), $timkiem2,$post);
				}
        $post = str_replace(array_keys($timkiemkitumahoa), $timkiemkitumahoa,$post);
		$post = explode(' ',$post);
		$vanbanfix = '';
			foreach($post as $post => $key){
				if(strlen($key) < 35){
					$vanbanfix .= $key.' '; 
				}
			}
		$post = $vanbanfix;
        $post = bbcode::notags($post);
        if ($set_user['smileys'])
          if($gres['id'] == 2){
          $outputhtml .= (time() > $gres['lastdate'] + 600 ? ' <div class="list4"><img src="/images/ON.gif" title="Trực Tuyến" /> ' : ' <div class="list4"><img src="/images/ON.gif" title="Trực Tuyến" /> ').'<b>Già Làng</b>: '.$post.'<br /></div>';
          ++$i;
		  }elseif($gres['id'] == 4783){
          $outputhtml .= (time() > $gres['lastdate'] + 600 ? ' <div class="list4"><img src="/images/ON.gif" title="Trực Tuyến" /> ' : ' <div class="list4"><img src="/images/ON.gif" title="Trực Tuyến" /> ').'<b>Ông già noel</b>: '.$post.'<br /></div>';
          ++$i;
		  }else{
          $outputhtml .= (time() > $gres['lastdate'] + 600 ? ' <div class="list4"><img src="/images/OFF.gif" title="Ngoại Tuyến" /> ' : ' <div class="list4"><img src="/images/ON.gif" title="Trực Tuyến" /> ').'<a href="/users/'.$gres['name'].'_'.$gres['id'].'.html"><b>'. nick($gres['id']).'</b></a>: '.$post.'<br /></div>';
          ++$i;
		  }
        }
      echo $outputhtml;
  }
?>