<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<link rel="stylesheet" style="text/css" href ="css/bootstrap.min.css">
<link href="css/baokim.css" rel="stylesheet">
<script src="js/jsmin.js"></script>
<script src="js/bootstrap.js"></script>
<script>
	$(document).ready(function(){
    $(".form-control").tooltip({ placement: 'right'});
});
</script>



</head>
<body>
<div class="container"> 
	<form class="form-horizontal form-bk" role="form"  method="post" action="transaction.php">
	<h2 class="form-control-heading">NẠP THẺ CÀO</h2>
<div class="form-group" >
    <label for="txtpin" class="col-lg-2 control-label">Loại thẻ</label> <br>
    <div class="col-lg-10" margin-left=-50px>
	
      <select class="form-control" name="chonmang" style="width:260px">
		  <option value="VIETEL">Viettel</option>
		  <option value="MOBI">Mobifone</option>
		  
		  <option value="VINA">Vinaphone</option>
		  <option value="GATE">Gate</option>
		  <option value="VTC">VTC</option>
		  
		</select> 
		

    </div>
  </div>
  <div class="form-group">
    <label for="txtpin" class="col-lg-2 control-label">Tài khoản</label>
    <div class="col-lg-10">
          <input type="text" class="form-control" id="txtuser" name="txtuser" style="width:260px"/>
      </div>
  </div>
  
  <div class="form-group">
    <label for="txtpin" class="col-lg-2 control-label i1">Mã thẻ</label>
    <div class="col-lg-10">
      <input  type="text" class="form-control" id="txtpin " name="txtpin" placeholder="Mã thẻ" style="width:260px" />

    </div>
  </div>
  <div class="form-group">
    <label for="txtseri" class="col-lg-2 control-label">Số seri</label>
    <div class="col-lg-10">
      <input type="text" class="form-control" id="txtseri" name="txtseri" placeholder="Số seri" style="width:260px" >

    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
      <button type="submit" class="btn btn-primary" name="napthe" value="ok">Nạp thẻ</button>
    </div>
  </div>
       




</div>  
</form>
<br>

</body>