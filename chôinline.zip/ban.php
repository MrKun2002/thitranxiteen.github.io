<?php
echo 'Bạn bị band v.v vì một số lí do như. QC Wap, lập nick phụ quá nhiều, có thể liên hệ với AD theo số 0166.260.4973 để kêu oan :D.';
?>