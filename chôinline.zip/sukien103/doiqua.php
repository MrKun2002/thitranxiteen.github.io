<?php
define('_IN_JOHNCMS', 1);
$headmod = 'mod';
require('../incfiles/core.php');
if(!$user_id){
require('../incfiles/head.php');
echo functions::display_error($lng['access_guest_forbidden']);
require('../incfiles/end.php');
exit;
}
$textl = 'Quà Sự kiện 10/3 ';
require('../incfiles/head.php');
echo '<div class="mainblok"><div class="phdr"><b>Sự kiện 10/3</b></div>';
echo'
<div class="list1"><img src="/images/canh/106.png"> <a href="/sukien103/kiemb.php">Kiếm Buster [500 Điểm]</a></div>
<div class="list1"><img src="/images/ao/19.png"> <a href="/sukien103/aoelizabeth.php">Elizabeth [200 Điểm]</a></div>

<div class="list1"><img src="/images/quan/21.png"> <a href="/sukien103/quanelizabeth.php">Elizabeth  [200 Điểm]</a></div>
<div class="list1"><img src="/images/ao/18.png"> <a href="/sukien103/aonapoleon.php">Napoleon [200 Điểm]</a></div>
<div class="list1"><img src="/images/quan/19.png"> <a href="/sukien103/quannapoleon.php">Napoleon [200 Điểm]</a></div>
<div class="list1"><img src="/images/canh/102.png"> <a href="/sukien103/canhlua.php">Cánh Lửa [500 Điểm]</a></div>
<div class="list1"><img src="/images/canh/103.png"> <a href="/sukien103/canhbang.php">Cánh Băng Bí Ẩn [500 Điểm]</a></div>
<div class="list1"><img src="/images/canh/3002.png"> <a href="/sukien103/canhvt.php">Cánh Vệ Thần Màu Nhiệm [2000 Điểm]</a></div>
<div class="list1"><img src="/images/canh/13.png"> <a href="/sukien103/cttqn.php">Cánh Tiểu Thần Quyền Năng [250 Điểm]</a></div>
<div class="list1"><img src="/images/docamtay/25ctty.png"> <a href="/sukien103/ctty.php">Cung Thần Tình Yêu [1000 điểm]</a></div>
';

echo '<div class="phdr"><a href="index.php">' . $lng['back'] . '</a></div></div>
<div class="list1"><img src="/images/toc/9hilit9.png"> <a href="/sukien103/hight.php">Tóc highlight [150 điểm]</a></div>
<div class="list1"><img src="/images/thucung/19.png"> <a href="/sukien103/ngua.php">Pet Kỳ Lân Truyền Thuyết [300 điểm]</a></div>
<div class="list1"><img src="/images/docamtay/3quab.png"> <a href="/sukien103/qbong.php">Quả bóng [400 điểm]</a></div>
<div class="list1"><img src="/images/thucung/22.png"> <a href="/sukien103/ruakini.php">Pet Rùa kini [200 điểm]</a></div>
<div class="list1"><img src="/images/toc/Sgk842.png"> <a href="/sukien103/tocsgkc1.php">Tóc Songoku [100 điểm]</a></div>
<div class="list1"><img src="/images/toc/50.png"> <a href="/sukien103/tocsgk.php">Tóc Siêu saya [200 điểm]</a></div>
<div class="list1"><img src="/images/thucung/15.png"> <a href="/sukien103/khunglong.php"> Pet Khủng Long [5000 điểm]</a></div>
<div class="list1"><img src="/images/thucung/23.png"> <a href="/sukien103/pikachu.php">Pet pikachu [200 điểm]</a></div>
<div class="list1"><img src="/images/non/nonaothuat.png"> <a href="/sukien103/nonaothuat.php">Nón Ảo Thuật Quyền Năng [500 điểm]</a></div>
<div class="list1"><img src="/images/ao/aonaruto.png"> <a href="/sukien103/aonaruto.php">Áo Naruto [1000 điểm]</a></div>
<div class="list1"><img src="/images/quan/quannaruto.png"> <a href="/sukien103/quannaruto.php">Quần Naruto [1000 điểm]</a></div>
<div class="list1"><img src="/images/thucung/totoro.png"> <a href="/sukien103/totoro.php">Pet Totoro [1000 điểm]</a></div>
<div class="phdr"> Sự Kiện Mod by Sin</div>
';
require_once('../incfiles/end.php');
?>
