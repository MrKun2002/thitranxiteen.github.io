<?php
define('_IN_JOHNCMS', 1);
$headmod = 'mod';
$bhead = 2;
require('../incfiles/core.php');
if(!$user_id){
require('../incfiles/head.php');
echo functions::display_error($lng['access_guest_forbidden']);
require('../incfiles/end.php');
exit;
}
$textl = 'Sự Kiện 10/3';
require('../incfiles/head.php');
echo '<div class="homeforum"><div class="icon-home"><div class="home">Sự Kiện 10/3</div></div></div>';
echo'<div class="phdr">Thông tin</div>';
echo'<table cellpadding="0" cellspacing="0" width="99%" border="0" style="table-layout:fixed;word-wrap: break-word;">
<tr><td width="45px;" class="blog-avatar">';
echo '<img src="http://choionline.cf/sukien103/hungvuong.png"><div class="menu"><b>Bạn có ' . $datauser['cautuyet'] . ' Hộp quà</div>';
echo'</td><td style="vertical-align: bottom;"><table cellpadding="0" cellspacing="0"><tbody>
<tr><td class="current-blog" rowspan="2" style=""><div class="blog-bg-left">';
echo'<img src="/giaodien/images/left-blog.png"></div>';
echo '<img src="/images/on.png" alt="online"/> ';
echo'<font color="red"><b>NPC Hùng Vương</font>';
echo'<div class="text">';

echo'<div class="phdr">Sự Kiện</div>';
echo'</br><a href="/sukien103/muahopqua.php"><font color="2c5170">- Mua hộp quà Xu </font></div></div>';
echo'</br><a href="/sukien103/muaqualg.php"><font color="2c5170">- Mua hộp quà Lượng </font></div></div>';
echo'</br><a href="choionline.cf"><font color="2c5170">- Trang Chủ</font></div></div>';
echo'</br><a href="/sukien103/doiqua.php"><font color="2c5170">- Đổi quà</font></div></div>';
echo'</br><a href="/sukien103/huongdan.php"><font color="2c5170">- Hướng Dẫn</font></div></div>';
echo'</td></tr></tbody></table></td></tr></tbody></table><div class="phdr">Sự Kiện Mod by Sin</div>';
require('../incfiles/end.php');
?>