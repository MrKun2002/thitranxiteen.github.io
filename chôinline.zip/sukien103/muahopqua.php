<?php
define('_IN_JOHNCMS', 1);
$headmod = 'mod';
require('../incfiles/core.php');
if(!$user_id){
require('../incfiles/head.php');
echo functions::display_error($lng['access_guest_forbidden']);
require('../incfiles/end.php');
exit;
}
$textl = 'Mua hộp quà';
require('../incfiles/head.php');
echo '<div class="mainblok"><div class="phdr"><b>Mua hộp quà</b></div>';
if(isset($_POST['submit'])){
$cautuyet = functions::checkout($_POST['cautuyet']);
$rand = rand(0,2);
$a= $cautuyet;
$b= 100;
if(empty($cautuyet)) {echo 'Vui lòng nhập số hộp quà muốn mua';}
else if($datauser['tienvnd'] < $a*$b )
{
echo 'Tài khoản của bạn không đủ xu để mua nhé chăm chỉ cày đi nhé';
}
else if($a < 0 )
{
echo 'Cấm bug anh band giờ';
}




else {


if($rand == 0) {
echo '<div class="menu list-top"><font color="red">Mua hộp quà thành công.</font></div>';
mysql_query("UPDATE `users` SET `cautuyet`=`cautuyet` + '".$a."',`tienvnd`=`tienvnd` - '".$a*$b."' WHERE `id`='".$user_id."'");

} else if($rand == 1) {
echo '<div class="menu list-top"><font color="red">Mua Hộp Quà thành công.</font></div>';
mysql_query("UPDATE `users` SET `cautuyet`=`cautuyet` + '".$a."', `tienvnd`=`tienvnd` - '".$a*$b."', `free`=`free` + '".$a."' WHERE `id`='".$user_id."'");
} else if($rand == 2) {
echo '<div class="menu list-top"><font color="red">Mua hộp quà thành công.</font></div>';
mysql_query("UPDATE `users` SET `cautuyet`=`cautuyet` + '".$a."', `tienvnd`=`tienvnd` - '".$a*$b."' WHERE `id`='".$user_id."'");
}
}
}else{
echo '' .
'<div class="list1"><b>Bạn muốn mua bao nhiêu?</b><br>Giá 1 hộp quà là <b>5.000 Xu</b> <br><form method="post">' .
'<input name="cautuyet" type="text" value=""/>' .
'<br/>' .
'<input type="submit" value="Mua" name="submit" /><br />' .'</div>';
}
echo '<div class="phdr"><a href="index.php">' . $lng['back'] . '</a></div></div>';
require_once('../incfiles/end.php');
?>
