<?php

define('_IN_JOHNCMS', 1);
$textl = ' Elizabeth ';
$headmod = 'nick';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
if ($id && $id != $user_id) {
$req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");
if (mysql_num_rows($req)) {

$user = mysql_fetch_assoc($req);
}
else {
}
}
else {
$id = false;
$user = $datauser;
}
if (!$user_id) {
require_once ('../incfiles/head.php');
echo functions::display_error($lng['access_guest_forbidden']);
require_once ('../incfiles/end.php');
exit;
}

switch($act){
case 'ok' :
if ($user['cautuyet'] < 200)
echo '<div class="menu">Bạn không đủ 200 Hộp quà để đổi thưởng nhé</div>';
else {

echo'<div class="phdr">Kết Quả</div> ';
$qua= rand(1,1);


if ($qua == 1) {
echo'<div class="menu">Xin chúc mừng bạn đã đổi vật phẩm  <b> Rùa Kini </b> thành công, hãy kiểm tra ở Rương Đồ</div> ';
$time = time();
$bot = ' @'.$login.' Vừa Đổi [b] Rùa kini [/b] Thành Công :O';
mysql_query("INSERT INTO `guest` SET
`adm` = '0',
`time` = '$time',
`user_id` = '1',
`name` = 'Admin',
`text` = '" . mysql_real_escape_string($bot) . "',
`ip` = '0000',
`browser` = 'IPHONE'
");
mysql_query("INSERT INTO `kho` SET `nick`='" . $login . "',`ten`='22',`loai`='thucung',`imgd`='/images/thucung/22.png'");

mysql_query("UPDATE `users` SET `cautuyet`=`cautuyet`-200 WHERE `id` = '$user_id' LIMIT 1");
}

}
break;
default:
echo '<div class="main"><div class="phdr"><b>Khu Đổi Quà 10/3</b> - [<a href="/avatar/bag.php"><b>Rương Đồ</b></a>]</div>';
echo '<div class="menu"><b>Đang có ' . $datauser['cautuyet'] . ' Hộp Quà </b></div>';
echo '<div class="menu">';
echo'<img src="'.$home.'/avatar/' . $datauser['id'] . '.png" alt="'. $datauser['name'] . '" />';
echo'</div>';
echo '<form action="ruakini.php?act=ok" name="but" method="post">';
echo'<div class="phdr">Vật phẩm Đổi</div><div class="menu"><img src="/images/thucung/22.png"/><b><font color="0000ff"> Rùa kini </font></b><br>Cần 200 Hộp Quà để đổi<br/><input type="submit" name="submit" value="Đổi"/></form></form>';

echo'</div>';

echo'</div>';

break;
}

require_once ("../incfiles/end.php");
?>
