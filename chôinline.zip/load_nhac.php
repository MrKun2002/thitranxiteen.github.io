<?php
if(isset($_GET['tt'])){
	if($_GET['tt'] == 'bat'){
	?>
		<div class="phdr">Nghe nhạc cùng ChoiOnline</div><div style="text-align: center;" class="gmenu"><div class="list1">
			<iframe width="410" height="300" src="http://mp3.zing.vn/embed/album/IO0CA6CE?autostart=true" frameborder="0" allowfullscreen="true"></iframe>
		</div></div></div></div>
	<?php
	}
}
?>