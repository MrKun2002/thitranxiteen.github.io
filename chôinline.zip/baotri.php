<?php
echo '<title>Bảo trì</title>';
echo '<div class="list1">ChoiOnline.Cf tạm thời đóng của tiến hành rest toàn bộ choionline để đưa choionline vào hoạt động chính thức.</br> thời gian: từ 19h50 đến 20h00 ngày 06/5/2015</br> hãy quay lại sau 10 phút nữa nhé. cảm ơn anh em đã ủng hộ! </div>';
?>