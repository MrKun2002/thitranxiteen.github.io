<?php
//---MOD-BY-BONGMA007---//
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$lng_profile = core::load_lng('profile');
if (!$user_id) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['access_guest_forbidden']);
    require('../incfiles/end.php');
    exit;
}
$user = functions::get_user($user);
if (!$user) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['user_does_not_exist']);
    require('../incfiles/end.php');
    exit;
}
$array = array(
    'activity'  => 'includes/profile',
    'ban'       => 'includes/profile',
    'edit'      => 'includes/profile',
    'images'    => 'includes/profile',
    'info'      => 'includes/profile',
    'ip'        => 'includes/profile',
    'guestbook' => 'includes/profile',
    'karma'     => 'includes/profile',
    'office'    => 'includes/profile',
    'password'  => 'includes/profile',
    'reset'     => 'includes/profile',
    'settings'  => 'includes/profile',
	'gioithieu' => 'includes/profile',
	'capduoi' => 'includes/profile',
    'stat'      => 'includes/profile',
    'friends'   => 'includes/profile'
);

$path = !empty($array[$act]) ? $array[$act] . '/' : '';

if (array_key_exists($act, $array) && file_exists($path . $act . '.php')) {
    require_once($path . $act . '.php');
} else {
    $headmod = 'profile,' . $user['id'];
    $textl = $lng['profile'] . ' của ' . htmlspecialchars($user['name']);
    require('../incfiles/head.php');
    echo '<div class="phdr">	<b>' . ($user['id'] != $user_id ? $lng_profile['user_profile'] : $lng_profile['my_profile']) . '</b>	</div>';	
    $menu = array();
    if ($user['id'] == $user_id || $rights >= 6 || ($rights == 7 && $rights > $user['rights'])) {
        $menu[] = '<b>[ <a href="profile.php?act=edit&amp;user=' . $user['id'] . '">' . $lng['edit'] . ' hồ sơ</a> ]</b> ';
    }
	if ($user['id'] == $user_id) {
        $menu[] = '<b>[ <a href="/users/profile.php?act=password"> Đổi mật khẩu</a> ]</b>';
    }
	if ($user['id'] == $user_id) {
        $menu[] = '<b>[ <a href="/users/profile.php?act=friends">Danh sách hảo hữu</a> ]</b>';
    }
    if ($user['id'] != $user_id && $rights >= 7 && $rights > $user['rights']) {
        $menu[] = '<b>[ <a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php?act=usr_del&amp;id=' . $user['id'] . '">' . $lng['delete'] . '</a> ]</b>';
    }
    if ($user['id'] != $user_id && $rights > $user['rights']) {
		 $menu[] = '<b>[ <a href="/users/profile.php?act=ban&mod=do&user=' . $user['id'] . '">' . $lng['ban_do'] . '</a> ]</b>';
    }
	if ($user['id'] != $user_id && $rights > $user['rights'] && $rights >= 7) {
		 $menu[] = '<b>[ <a href="/users/anxa.php?id=' . $user['id'] . '">Ân xá</a> ]</b>';
    }	
	if (!empty($menu)) {        echo '<div class="topmenu">' . functions::display_menu($menu) . '</div>';    }
    if ($user['dayb'] == date('j', time()) && $user['monthb'] == date('n', time())) {
        echo '<div class="gmenu">' . $lng['birthday'] . '!!!</div>';
    }
    echo '<div class="thongtin_mem"><p>' . functions::display_user($user, $arg) . '</p></div>';
	$total_photo = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . $user['id'] . "'"), 0);//MENUecho '<div class="dmenu" style="padding: 5px 4px;">';echo '<a href="profile.php?act=info&amp;user=' . $user['id'] . '" style="color:red; font-weight:bold;">Thông tin</a> · ';echo '<a href="album.php?act=list&amp;user=' . $user['id'] . '">Hình ảnh</a> (' . $total_photo . ') · ';echo '<a href="profile.php?act=friends&amp;user=' . $user['id'] . '">Bạn bè</a> ·'; echo '<a href="profile.php?act=activity&amp;user=' . $user['id'] . '">Hoạt động</a>';echo '</div>';/*
    $total_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='{$user['id']}' AND `type`='2' AND `friends`='1'"), 0);
 //Hành động
if ($user['id'] != $user_id) {
	if($user[imname] != ""){
	echo '<div class="thongtin_mem">Tên thật: '.$user['imname'].'</div>';
	}
	if($user[dayb] == 0 && $user[monthb] == 0 && $user[yearofbirth] == 0){
	}
	else{
	echo '<div class="thongtin_mem">Ra đời:';
	}
	if($user[dayb] != 0){
	echo ' Ngày '.$user[dayb].'';
	}
	if($user[monthb] != 0){
	echo ' Tháng '.$user[monthb].'';
	}
	if($user[yearofbirth] != 0){
	echo ' Năm '.$user[yearofbirth].'';
	}
	echo '</div>';
	if($user[sex] == 'm'){
		echo '<div class="thongtin_mem">Giới tính: Nam</div>';
		}
	else
		echo '<div class="thongtin_mem">[ Giới tính: Nữ ]</div>';
	echo '<div class="thongtin_mem"> Xu:'.$user[balans].'</div>';
	echo '<div class="thongtin_mem"> Sức Mạnh: '.$user[sucmanh].'</div>';
	echo '<div class="thongtin_mem"> <a href="/dautruong/ace/?id='.$user[id].'">Chiến đấu với '.$user[name].'</a></div>';
	echo '<div class="thongtin_mem"> <a href="/gamemini/chanle/on.html?id='.$user[id].'">Gạ '.$user[name].' chơi sóc đĩa</a></div>';
	echo '<div class="thongtin_mem"> <a href="/users/chude/' . $user['id'] . '">Bài viết của '.$user[name].' </a></div>';
	echo '<div class="thongtin_mem"> <a href="/nongtrai/nongtrai.html?id=' . $user['id'] . '">Nông trại của '.$user[name].'</a></div>';
	echo '<p style="margin: 10px 5px 5px 0px;">';
        if (!functions::is_ignor($user['id']) && functions::is_contact($user['id']) != 2) {
            if (!functions::is_friend($user['id'])) {
                $fr_in = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `from_id`='$user_id' AND `user_id`='{$user['id']}'"), 0);
                $fr_out = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `user_id`='$user_id' AND `from_id`='{$user['id']}'"), 0);
                if ($fr_in == 1) {
                    $friend = '<a class="underline" href="profile.php?act=friends&amp;do=ok&amp;id=' . $user['id'] . '">' . $lng_profile['confirm_friendship'] . '</a> | <a class="underline" href="profile.php?act=friends&amp;do=no&amp;id=' . $user['id'] . '">' . $lng_profile['decline_friendship'] . '</a>';
                } else if ($fr_out == 1) {
                    $friend = '<a class="underline" href="profile.php?act=friends&amp;do=cancel&amp;id=' . $user['id'] . '">' . $lng_profile['canceled_demand_friend'] . '</a>';
                } else {
                    $friend = '<a id="submit" href="profile.php?act=friends&amp;do=add&amp;id=' . $user['id'] . '">' . $lng_profile['in_friend'] . '</a>';
                }
            } else {
                $friend = '<a id="submit" href="profile.php?act=friends&amp;do=delete&amp;id=' . $user['id'] . '">' . $lng_profile['remov_friend'] . '</a>';
            }
            echo '<a id="submit" href="profile.php?act=friends&do=add&id=' . $user['id'] . '">Kết bạn</a> ';
        }
		//Hết Kết Bạn
		        if (functions::is_contact($user['id']) != 2) {
            if (!functions::is_contact($user['id'])) {
                echo '<a id="submit" href="../mail/index.php?id=' . $user['id'] . '">Thêm vào liên lạc</a> ';
            } else {
                echo '<a id="submit" href="../mail/index.php?act=deluser&amp;id=' . $user['id'] . '">Chặn Tin Nhắn</a> ';
            }
        }
echo '<a id="submit" href="../mail/index.php?act=write&amp;id=' . $user['id'] . '">Tin nhắn</a> ';
//if (functions::is_contact($user['id']) != 2) {
//            echo '<a id="submit" href="../mail/index.php?act=ignor&amp;id=' . $user['id'] . '&amp;add">Chặn</a> ';
//        } else {
//            echo '<a id="submit" href="../mail/index.php?act=ignor&amp;id=' . $user['id'] . '&amp;del">Bỏ chặn</a> ';
//        }
}  
echo '</p></td></tr></table></div>'; 	
    if ($rights >= 7 && !$user['preg'] && empty($user['regadm'])) {
        echo '<div class="rmenu">' . $lng_profile['awaiting_registration'] . '</div>';
    }
    //Tường Nhà
	
	echo '<div class="mainblok">';
	if($datauser['id'] == $user['id']){
	echo '<div class="phdr">Phòng Chat Của Bạn</div>';
	}else{
		echo '<div class="phdr">Phòng Chat Của '.$user['name'].'</div>';
	}
	if ($rights >= 1) {    
	$guest = counters::guestbook(2);     
	}
	$arg = array (    
	'comments_table' => 'cms_users_guestbook', 
	// Таблица Гостевой    
	'object_table' => 'users',                 	// Таблица комментируемых объектов    
	'script' => 'profile.php?act=guestbook',   // Имя скрипта (с параметрами вызова)    
	'sub_id_name' => 'user',                   // Имя идентификатора комментируемого объекта    
	'sub_id' => $user['id'],                   // Идентификатор комментируемого объекта    
	'owner' => $user['id'],                    // Владелец объекта    
	'owner_delete' => true,                    // Возможность владельцу удалять комментарий    
	'owner_reply' => true,                     // Возможность владельцу отвечать на комментарий    
	'title' => $lng['comments'],               // Название раздела    
	'context_top' => $context_top              // Выводится вверху списка
	);
	$comm = new comments($arg);
	echo '</div>';
	if($datauser[rights] == 9){
	echo '<div class="thongtin_mem"> <a href="http://choionline.cf/shop/mail_ban.php?id=' . $user['id'] . '">Bắn thành viên '.$user[name].' vĩnh viễn</a></div>';
	}
}

require_once('../incfiles/end.php');