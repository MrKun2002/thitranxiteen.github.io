<?php
define('_IN_JOHNCMS', 1);
$headmod = 'mod';
require('../incfiles/core.php');
error_reporting(0);
if(!$user_id){
require('../incfiles/head.php');
echo functions::display_error($lng['access_guest_forbidden']);
require('../incfiles/end.php');
exit;
}
$textl = 'Thông tin - Sự kiện';
require('../incfiles/head.php');

function cattu($string,$start,$length){
$arrwords = explode(" ",$string);
$arrsubwords=array_slice($arrwords,$start,$length);
$result = implode(" ",$arrsubwords);
return $result;
}

echo '<div class="mainblok"><div class="phdr"><b>'.($_GET['mod'] == 'me' ? 'Thông Báo của tôi':''.($_GET['mod'] == 'fme' ? 'Thông Báo về tôi':'Bảng Thông Báo').'').'</b></div>';
switch($mod) {
default:
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `hoatdong` WHERE `type`!='e' AND `user_id` = '".$datauser["id"]."'"), 0);
if($tong) {
mysql_query("UPDATE `hoatdong` SET `view`='1' WHERE `user_id`='{$user_id}'");
$req = mysql_query("SELECT * FROM `hoatdong` WHERE `type`!='e' AND `user_id` = '".$datauser["id"]."' ORDER BY `time` DESC LIMIT $start, $kmess");
while ($res=mysql_fetch_array($req)) {
if($res['sid'] == 0){
$text = mysql_fetch_array(mysql_query("SELECT `noi_dung` as `text` FROM `community_baiviet_nd` WHERE `id`='{$res['community_id_baviet']}'"));
$text = preg_replace('#\[c\](.*?)\[/c\]#si', '', $text['text']);$text = preg_replace('#\[URL=(.+?)\](.+?)\[/URL\]#is','', $text);
$text = preg_replace('#\[url=(.+?)\](.+?)\[/url\]#is','', $text);
$text = preg_replace('#\[img\](.+?)\[/img\]#is','', $text);
$text = preg_replace('#\[IMG\](.+?)\[/IMG\]#is','', $text);
$text4 = mysql_fetch_array(mysql_query("SELECT `title` as `text` FROM `community_baiviet` WHERE `id`='{$res['community_bang']}'"));
}else{
$text = mysql_fetch_array(mysql_query("SELECT `text` FROM `forum` WHERE `id`='{$res['sid']}' AND `type`='m'"));
$text = preg_replace('#\[c\](.*?)\[/c\]#si', '', $text['text']);$text = preg_replace('#\[URL=(.+?)\](.+?)\[/URL\]#is','', $text);
$text = preg_replace('#\[url=(.+?)\](.+?)\[/url\]#is','', $text);
$text = preg_replace('#\[img\](.+?)\[/img\]#is','', $text);
$text = preg_replace('#\[IMG\](.+?)\[/IMG\]#is','', $text);
$text4 = mysql_fetch_array(mysql_query("SELECT `text` FROM `forum` WHERE `id`='{$res['sid']}' AND `type`='t'"));
}
$text61 = mysql_query("SELECT * FROM `users` WHERE `id`='$res[fr_user]'");
//$text94 mysql_fetch_array(mysql_query("SELECT * FROM `hoatdong` WHERE `fr_user`='{$res['sid']}' AND `type`='t'"));
$res1=mysql_fetch_array($text61);
echo '
<div class="list1">
'.($res['type'] != 'x' && $res['type'] != 'b' && $res['type'] != 'z' && $res['type'] != 'p' ? '<img src="/images/write.gif" alt="" />&#160;
<a href="'.$res1['name'].'_'.$res['fr_user'].'.html">'.($res['fr_user'] == $user_id ? 'Bạn':''.nick($res['fr_user']).'').'</a>&#160;đã&#160;':'').'
'.(
$res['type'] == 'l' ? 'thích bài viết':''.(
$res['type'] == 'r' ? 'nhắc đến '.($res['user_id'] == $user_id ? 'bạn':'<a href="profile.php?user='.$res['user_id'].'">'.nick($res['user_id']).'</a>').'':''.(
$res['type'] == 'c' ? 'bình luận':''.(
$res['type'] == 'x' ? '<img src="/images/muiten.png"> '.$res['loinhan'].' ':''.(
$res['type'] == 'p' ? '<img src="/images/muiten.png"> '.$res['loinhan'].' ':''.(
$res['type'] == 'b' ? '<img src="/images/muiten.png"> '.$res['loinhan'].' ':''.(
$res['type'] == 'z' ? ' '.$res['loinhan'].' ':''.(
$res['type'] == 'd' ? 'bỏ thích':''.(
$res['type'] == 'g' ? 'đăng một chủ đề':''.(
$res['type'] == 'e' ? 'bình luận':'').'').'').'').'').'').'').'').'').'').'
&#160;
'.($res['type'] != 'x' && $res['type'] != 'b' && $res['type'] != 'z' && $res['type'] != 'p' ? '<a href="/thongbaofr/?mod=go&id='.$res['id'].'">'.(
$res['type'] == 'g' && $res['type'] != 'x' && $res['type'] != 'b' && $res['type'] != 'z' && $res['type'] != 'p' ? ''.trim(cattu($text4['text'], 0, 5)).'':''.trim(cattu($text, 0, 5)).'').'...</a>'.(
$res['type'] == 'r'? '&#160;trong một bài viết':''.(
$res['type'] == 'l' || $res['type'] == 'd' ? '&#160;của&#160;':'').'').''.(
$res['type'] != 'g' && $res['type'] != 'r' && $res['type'] != 'x' && $res['type'] != 'b' && $res['type'] != 'z' && $res['type'] != 'p' ? ''.(
$res['type'] != 'l' && $res['type'] != 'd' && $res['type'] != 'x' && $res['type'] != 'b' && $res['type'] != 'z' && $res['type'] != 'p' ? '&#160;trong chủ đề của&#160;':'').''.(
$res['user_id'] == $user_id ? 'bạn':'<a href="profile.php?user='.$res['user_id'].'">'.nick($res['user_id']).'</a>').'':'').'':'').'</div>';

// Mod xoa thong bao theo thoi gian
			$rowtimenew = $res['time'] + 86400;
			$rowht = time();
			if ($rowht >= $rowtimenew)
			{
				mysql_query("DELETE FROM `hoatdong` WHERE `id` = '".$res["id"]."'");
			}
}
if ($tong > $kmess){echo '<div class="topmenu">' . functions::display_pagination('/thongbaofr/', $start, $tong, $kmess) . '</div>';
}
} else {
echo '<div class="list1">Không có Thông Báo nào!</div>';
}
break;
case 'go':
$id = intval(trim(abs($_GET['id'])));
$kt2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `hoatdong` WHERE `id`='{$id}'"), 0);
$kt = mysql_fetch_array(mysql_query("SELECT * FROM `hoatdong` WHERE `id`='{$id}'"));
if($kt['user_id'] == $user_id) {
mysql_query("DELETE FROM `hoatdong` WHERE `id`= '".$id."'");
}
if($kt['sid'] == 0){
$text2 = mysql_fetch_array(mysql_query("SELECT `title` as `text`,`id` FROM `community_baiviet` WHERE `id`='{$kt['community_bang']}'"));
}else{
$text = mysql_fetch_array(mysql_query("SELECT `text`,`refid` FROM `forum` WHERE `id`='{$kt['sid']}' AND `type`='m'"));
$text2 = mysql_fetch_array(mysql_query("SELECT `text`,`id` FROM `forum` WHERE `id`='{$text['refid']}' AND `type`='t'"));
}
if($kt2 == 0) {
header("Location: /thongbaofr/");
} else {
if($kt['sid'] == 0){
$link = '/baiviet/'.functions::viethuy($text2['text']).'-'.$text2['id'].'_p'.$kt['page'].'.html';
}else{
$link = '/forum/'.functions::viethuy($text2['text']).'_'.$text2['id'].'_p'.$kt['page'].'.html';
}
header("Location: $link");
}
break;
case 'clear':
mysql_query("UPDATE `hoatdong` SET `view`='1' WHERE `user_id`='{$user_id}'");
header("Location: /thongbaofr/?mod=fme");
break;
//Delete Đã ĐỌC
case 'rdelete':
mysql_query("UPDATE `hoatdong` SET `view`='1' WHERE `user_id`='{$user_id}'");
header("Location: /thongbaofr/");
break;
//Delete ALL
case 'xoaall':
mysql_query("DELETE FROM `fish_tb`");
mysql_query("DELETE FROM `hoatdong`");
mysql_query("DELETE FROM `thongbao`");
mysql_query("DELETE FROM `carodata`");
mysql_query("DELETE FROM `carocmt`");
mysql_query("DELETE FROM `khodo` WHERE `loaisp` = '' AND `name`=''");
header("Location: /thongbaofr/");
break;
}

if ($datauser['rights'] == 9){
echo '<div class="list1"><a style="font-weight:bold; color:red" href="/thongbaofr/?mod=xoaall">» Xoá tất cả thông báo</a></div>';
}
echo '</div>';
require('../incfiles/end.php');
?>
