<?php
/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
$headmod = 'lode';
$textl = 'Tools Thêm Đồ';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
$id = $_GET['id'];


if ($id && $id != $user_id) {


    $req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");


    if (mysql_num_rows($req)) {


        $user = mysql_fetch_assoc($req);}}


if (!$user_id) {


    echo 'Ch? cho ng??i dùng ??ng ký';


    require_once ('../incfiles/end.php');


    exit;


}


switch($_GET['act'])
{
default:
echo'<div class="phdr">Thêm Đồ Vào Shop</div>';
if ($datauser['rights']<=8){
echo'<br/> Bạn không thể add đồ vào shop';
}
if ($datauser['rights']==9){
echo'<form action ="admin.php?act=ketqua" method="post">';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop`"), 0) + 4;
$them= $tong+1;
$puaru= $them+1;
//echo 'ID (hiện tại là '.$them.' , ID để bạn thêm là: <b>'.$puaru.'</b>  !)<br/><input name="id"/><br/>';
echo 'Name (Trùng với ID tên Item), Nếu ITEM là 100.png thì Name là <b>100</b><br/><input name="name"/><br/>';
echo 'Loại Sản Phẫm<br/><input name="loaisp"/><br/>';
echo 'Giá Mua<br/><input name="giamua"/><br/>';
echo 'Giá Bán<br/><input name="giaban"/><br/>';
echo 'Sức Mạnh<br/><input name="sucmanh"/><br/>';
echo 'Giới tính<br/><input name="sex"/><br/>';
echo 'Time (18000)<br/><input name="time"/><br/>';
echo 'Tên vật phẩm<br/><input name="tenvatpham"/><br/>';
echo'<input type="submit" value="Thêm"></input></form>';
}
break;
case 'ketqua':
//$id = isset($_POST['id'])?abs(intval($_POST['id'])):false;
$name = isset($_POST['name'])?abs(intval($_POST['name'])):false;
$giamua = isset($_POST['giamua'])?abs(intval($_POST['giamua'])):false;
$giaban = isset($_POST['giaban'])?abs(intval($_POST['giaban'])):false;
$loaisp = isset($_POST['loaisp']) ? trim($_POST['loaisp']) : ''; 
$sucmanh = isset($_POST['sucmanh'])?abs(intval($_POST['sucmanh'])):false;
$sex = isset($_POST['sex'])?abs(intval($_POST['sex'])):false;
$time = isset($_POST['time']) ? trim($_POST['time']) : '';
$tenvatpham = isset($_POST['tenvatpham']) ? functions::check(mb_substr($_POST['tenvatpham'], 0, 50)) : '';
$danh = 1;
$ketqua = 1;
$usd = mysql_fetch_assoc(mysql_query("select `id` from `shop` where `id`='".$user_id."';"));
if ($datauser['rights']==9){


if ("'.$danh.'" == "'.$ketqua.'")
{
$time = time()+10;


// ????????? ????? ??????


mysql_query("UPDATE `forum` SET `time` = '$realtime' WHERE `id` = '3538' LIMIT 1") or die('Không thê? câ?p nhâ?t');


// ????????? ?????????? ?????


mysql_query("UPDATE `users` SET


`postforum`=`postforum`+1,


`tienxu`=`tienxu`+10,


`lastpost` = 'time()'


WHERE `id` = '2'");


mysql_query("INSERT INTO `shop` SET

            `name` = '$name',

            `loaisp` = '$loaisp',

            `giamua` = '$giamua',

            `giaban` = '$giaban',

            `sucmanh` = '$sucmanh',
            
			`sex` = '$sex',

            `time` = '$time',
			
			`tenvatpham` = '$tenvatpham'
			

        ") or exit(__LINE__ . ': ' . mysql_error());

echo'Xin chúc mừng bạn vừa thêm đồ thành công<br>';
echo'<a href="admin.php"> Thêm Tiếp</a><br>';
}
else{



echo'Lỗi Quay Lại!!';
echo'<a href="/shop/admin.php">Trở về</a>';
}
}
else{
echo'Lỗi! Quay Lại.';
echo'<a href="/shop/admin.php">Trở về</a>';
}


break;
}
require_once ("../incfiles/end.php");
?>