<?php
define('_IN_JOHNCMS', 1);
$textl = 'Bảng Xếp Hạng  ';
$headmod = 'nick';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
$id = $_GET['id'];
if ($id && $id != $user_id) {
    $req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");
    if (mysql_num_rows($req)) {
        $user = mysql_fetch_assoc($req);}
		}
if (!$user_id) {
    echo 'Chỉ cho người dùng đăng ký';
    require_once ('../incfiles/end.php');
    exit;
}
echo '
<div class="mainblok"><div class="phdr"> TOP Xu</div></div><div class="gmenu">';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `balans` > 0"), 0);
$req = mysql_query("SELECT `id`, `balans`, `name`, `rights` FROM `users` WHERE `balans` > 0 ORDER BY `balans` DESC LIMIT $start, $kmess");
if (mysql_num_rows($req)) {
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
if ($res['rights'] == 0 ) {
$mau = '000000';
}
if ($res['rights'] == 1 ) {
$mau = '0000FF';
}
if ($res['rights'] == 2 ) {
$mau = '0000FF';
}
if ($res['rights'] == 3 ) {
$mau = '0000FF';
}
if ($res['rights'] == 4 ) {
$mau = '0000FF';
}
if ($res['rights'] == 5 ) {
$mau = '0000FF';
}
if ($res['rights'] == 6 ) {
$mau = '009900';
}
if ($res['rights'] == 7 ) {
$mau = 'ff00ff';
}
if ($res['rights'] == 9 ) {
$mau = 'FF0000';
}
echo '<div class="list1">';
echo '<table width="100%" cellpadding="0" cellspacing="0"><tr><td><img src="../avatar/'.$res['id'].'.png"></td>
<td width="90%">
<a href="/users/'.$res['name'].'_'.$res['id'].'.html"><span style="color:#'.$mau.'">'.$res['name'].'</span></a><br/>
Xu đang sở hữu: '.$res['balans'].'<br/>';
if($i == 0){
echo '<b style="color: red; padding-top: 4px;">TOP 1  <b>';
}
if($i == 1){
echo '<b>TOP 2<b>';
}
if($i == 2){
echo '<b>TOP 3<b>';
}
echo '</td></tr></table></div>';
++$i;
}
} else {
echo '<div class="list1">Trống</div>';
}
echo '</div>';
echo '
<div class="mainblok"><div class="phdr"> TOP Lượng</div></div><div class="gmenu">';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `balans` > 0"), 0);
$req = mysql_query("SELECT `id`, `luong`, `name`, `rights` FROM `users` WHERE `balans` > 0 ORDER BY `luong` DESC LIMIT $start, $kmess");
if (mysql_num_rows($req)) {
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
if ($res['rights'] == 0 ) {
$mau = '000000';
}
if ($res['rights'] == 1 ) {
$mau = '0000FF';
}
if ($res['rights'] == 2 ) {
$mau = '0000FF';
}
if ($res['rights'] == 3 ) {
$mau = '0000FF';
}
if ($res['rights'] == 4 ) {
$mau = '0000FF';
}
if ($res['rights'] == 5 ) {
$mau = '0000FF';
}
if ($res['rights'] == 6 ) {
$mau = '009900';
}
if ($res['rights'] == 7 ) {
$mau = 'ff00ff';
}
if ($res['rights'] == 9 ) {
$mau = 'FF0000';
}
echo '<div class="list1">';
echo '<table width="100%" cellpadding="0" cellspacing="0"><tr><td><img src="../avatar/'.$res['id'].'.png"></td>
<td width="90%">
<a href="/users/'.$res['name'].'_'.$res['id'].'.html"><span style="color:#'.$mau.'">'.$res['name'].'</span></a><br/>
Lượng đang sở hữu: '.$res['luong'].'<br/>';
if($i == 0){
echo '<b style="color: red; padding-top: 4px;">TOP 1  <b>';
}
if($i == 1){
echo '<b>TOP 2<b>';
}
if($i == 2){
echo '<b>TOP 3<b>';
}
echo '</td></tr></table></div>';
++$i;
}
} else {
echo '<div class="list1">Trống</div>';
}
echo '</div>';
echo '
<div class="mainblok"><div class="phdr"> TOP Lever</div></div><div class="gmenu">';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `balans` > 0"), 0);
$req = mysql_query("SELECT `id`, `fermer_level`, `name`, `rights` FROM `users` WHERE `fermer_level` > 0 ORDER BY `fermer_level` DESC LIMIT $start, $kmess");
if (mysql_num_rows($req)) {
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
if ($res['rights'] == 0 ) {
$mau = '000000';
}
if ($res['rights'] == 1 ) {
$mau = '0000FF';
}
if ($res['rights'] == 2 ) {
$mau = '0000FF';
}
if ($res['rights'] == 3 ) {
$mau = '0000FF';
}
if ($res['rights'] == 4 ) {
$mau = '0000FF';
}
if ($res['rights'] == 5 ) {
$mau = '0000FF';
}
if ($res['rights'] == 6 ) {
$mau = '009900';
}
if ($res['rights'] == 7 ) {
$mau = 'ff00ff';
}
if ($res['rights'] == 9 ) {
$mau = 'FF0000';
}
echo '<div class="list1">';
echo '<table width="100%" cellpadding="0" cellspacing="0"><tr><td><img src="../avatar/'.$res['id'].'.png"></td>
<td width="90%">
<a href="/users/'.$res['name'].'_'.$res['id'].'.html"><span style="color:#'.$mau.'">'.$res['name'].'</span></a><br/>
Lever Hiện tại: '.$res['fermer_level'].'<br/>';
if($i == 0){
echo '<b style="color: red; padding-top: 4px;">TOP 1  <b>';
}
if($i == 1){
echo '<b>TOP 2<b>';
}
if($i == 2){
echo '<b>TOP 3<b>';
}
echo '</td></tr></table></div>';
++$i;
}
} else {
echo '<div class="list1">Trống</div>';
}
echo '</div>';
echo '</div>';
echo '
<div class="mainblok"><div class="phdr"> TOP SỨC MẠNH</div></div><div class="gmenu">';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `luutrusm` > 0"), 0);
$req = mysql_query("SELECT `id`, `sucmanh`, `luutrusm`, `name`, `rights` FROM `users` WHERE `luutrusm` > 0 ORDER BY `luutrusm` DESC LIMIT $start, $kmess");
if (mysql_num_rows($req)) {
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
if ($res['rights'] == 0 ) {
$mau = '000000';
}
if ($res['rights'] == 1 ) {
$mau = '0000FF';
}
if ($res['rights'] == 2 ) {
$mau = '0000FF';
}
if ($res['rights'] == 3 ) {
$mau = '0000FF';
}
if ($res['rights'] == 4 ) {
$mau = '0000FF';
}
if ($res['rights'] == 5 ) {
$mau = '0000FF';
}
if ($res['rights'] == 6 ) {
$mau = '009900';
}
if ($res['rights'] == 7 ) {
$mau = 'ff00ff';
}
if ($res['rights'] == 9 ) {
$mau = 'FF0000';
}
echo '<div class="list1">';
echo '<table width="100%" cellpadding="0" cellspacing="0"><tr><td><img src="../avatar/'.$res['id'].'.png"></td>
<td width="90%">
<a href="/users/'.$res['name'].'_'.$res['id'].'.html"><span style="color:#'.$mau.'">'.$res['name'].'</span></a><br/>
SM Đang Nắm Giữ: '.$res['luutrusm'].'<br/>';
if($i == 0){
echo '<b style="color: red; padding-top: 4px;">TOP 1  <b>';
}
if($i == 1){
echo '<b>TOP 2<b>';
}
if($i == 2){
echo '<b>TOP 3<b>';
}
echo '</td></tr></table></div>';
++$i;
}
} else {
echo '<div class="list1">Trống</div>';
}
echo '</div>';
//-- Ket thuc top suc manh --/


require_once ("../incfiles/end.php");
?>