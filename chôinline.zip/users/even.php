<?php
/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);
$headmod = 'lode';
$textl = 'Tools Thêm Đồ';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
$id = $_GET['id'];


if ($id && $id != $user_id) {


    $req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");


    if (mysql_num_rows($req)) {


        $user = mysql_fetch_assoc($req);}}


if (!$user_id) {


    echo 'Ch? cho ng??i dùng ??ng ký';


    require_once ('../incfiles/end.php');


    exit;


}


switch($_GET['act'])
{
default:
echo'<div class="phdr">Thêm đồ nâng cấp vào shop nâng cấp</div>';
if ($datauser['rights']<=8){
echo'<br/> Bạn không thể add đồ vào shop';
}
if ($datauser['rights']==9){
echo'<form action ="even.php?act=ketqua" method="post">';
$them= $tong+1;
$puaru= $them+1;
//echo 'ID (hiện tại là '.$them.' , ID để bạn thêm là: <b>'.$puaru.'</b>  !)<br/><input name="id"/><br/>';

echo 'Name ID Hình Ảnh Của Item Mới Tạo Ra, Nếu ITEM là 100.png thì Name là <b>100</b><br/><input name="name"/><br/>';
echo 'Tên Của Item Mới Tạo Ra<b>(VD: Cánh tiểu tiên)</b>:<br/><input name="tenvatpham"/><br/>';
echo 'Loại Sản Phẫm<br/><input name="loaisp"/><br/>';
echo 'Giá Bán<br/><input name="giaban"/><br/>';
echo 'Sức Mạnh<br/><input name="sucmanh"/><br/>';
echo 'Số điểm cần để đổi.<br/><input name="sodiem"/><br/>';
echo'<input type="submit" value="Thêm"></input></form>';
}
break;
case 'ketqua':
//$id = isset($_POST['id'])?abs(intval($_POST['id'])):false;
$name = isset($_POST['name'])?abs(intval($_POST['name'])):false;
$tenvatpham = isset($_POST['tenvatpham']) ? functions::check(mb_substr($_POST['tenvatpham'], 0, 50)) : '';
$loaisp = isset($_POST['loaisp']) ? trim($_POST['loaisp']) : ''; 
$giaban = isset($_POST['giaban'])?abs(intval($_POST['giaban'])):false;
$sucmanh = isset($_POST['sucmanh'])?abs(intval($_POST['sucmanh'])):false;
$sodiem = isset($_POST['sodiem'])?abs(intval($_POST['sodiem'])):false;
$danh = 1;
$ketqua = 1;
$usd = mysql_fetch_assoc(mysql_query("select `id` from `shop_quayso` where `id`='".$user_id."';"));
if ($datauser['rights']==9){


if ("'.$danh.'" == "'.$ketqua.'")
{
$time = time()+10;


// ????????? ????? ??????


//mysql_query("UPDATE `forum` SET `time` = '$realtime' WHERE `id` = '3538' LIMIT 1") or die('Không thê? câ?p nhâ?t');


// ????????? ?????????? ?????


mysql_query("INSERT INTO `even_gamemini` SET

            `name_id` = '$name',
			
			`name_vp` = '$tenvatpham',
            
			`loaisp` = '$loaisp',
			
			`giaban` = '$giaban',
			
			`sucmanh` = '$sucmanh',
			
			`sodiem` = '$sodiem'	

        ") or exit(__LINE__ . ': ' . mysql_error());

echo'Xin chúc mừng bạn vừa thêm đồ thành công<br>';
echo'<a href="even.php"> Thêm Tiếp</a><br>';
}
else{



echo'Lỗi Quay Lại!!';
echo'<a href="even.php">Trở về</a>';
}
}
else{
echo'Lỗi! Quay Lại.';
echo'<a href="even.php">Trở về</a>';
}


break;
}
require_once ("../incfiles/end.php");
?>