<?php
define('_IN_JOHNCMS', 1);
$textl = 'Chém - Tấn công';
$headmod = 'nick';
$idbot=2;
$topic=5047;
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
$id = $_GET['id'];
if ($id && $id != $user_id) {
    $req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");
    if (mysql_num_rows($req)) {
        $user = mysql_fetch_assoc($req);}
		}
if (!$user_id) {
    echo 'Chỉ cho người dùng đăng ký';
    require_once ('../incfiles/end.php');
    exit;
}
echo '<div class="mainblok"><div class="phdr"> Đấu Trường</div></div>';
//
	// Mod tan comng//
if($datauser['sucmanh'] >= 0 && $user['sucmanh'] >= 0)
{
	if (!$act && $id){
	if($datauser['sucmanh']>=100 && $user['sucmanh'] >=100){
	echo '
	<table width="100%">
		<tr>
			<td width="33%" style="text-align: right;">
				<img src="/avatar/'.$datauser['id'].'.png" width="46px"><br/>
				<b>SM: '.$datauser['sucmanh'].'</b>
			</td>
			<td width="34%" style="text-align: center;">
				<a href="/dautruong/ace/?act=ok&amp;id='.$id.'" style="background: #561d00; padding: 5px 10px; color: #fff; border: 1px; margin: 2px 2px; border-radius: 5px; margin: 10px;"><b>Đánh</b></a>
				
			</td>
			<td width="33%" style="text-align: left;">
				<img src="/avatar/'.$user['id'].'.png" width="46px"><br/>
				<b>SM: '.$user['sucmanh'].'</b>
			</td>
		</tr>
	</table>';
	}
	else if($datauser['sucmanh']< 100){
	echo '<div class="list1">Bạn không còn sức để thông '.$user['name'].' nữa rồi!</div>';
	}
	else if($user['sucmanh'] < 100){
	echo '<div class="list1">Đối thủ đã kiệt sức rồi, đừng có thông nữa!</div>';
	}
	else if($datauser['id'] == $user['id']){
	echo '<div class="list1">Điên, định tự sát à.</div>';
	}
	} 
	else{
	if ($act && $id){
	if($user['sucmanh']>= 100 && $datauser['sucmanh'] >= 100){
	if($user['sucmanh'] > $datauser['sucmanh'])
		$nhonhat = $datauser['sucmanh'];
	else
		$nhonhat = $user['sucmanh'];
	$nhonhat2 = $nhonhat/2;
	$chem = rand($nhatnhat2,$nhonhat);
	$why = $_POST['why'];
	$rechem = $chem/10;
	$differencetolocaltime=+7;
	$new_U=date('U')+ $differencetolocaltime*3600 ;
	$fulllocaldatetime= date('h:i a d/m/Y', $new_U);
	$msg = ''.$fulllocaldatetime.', '.$login.' đã tấn công '.$user['name'].' vì lý do [red]'.$why.'[/red] bằng [b]'.$chem.' HP[/b] và thu về được [b]'.$rechem.' HP[/b]!';
	mysql_query("UPDATE `users` SET `sucmanh`=`sucmanh`-'$chem '  WHERE `id` = '$id' LIMIT 1");
	mysql_query("UPDATE `users` SET `sucmanh`=`sucmanh`-'$chem'  WHERE `id` = '$user_id' LIMIT 1");
	mysql_query("UPDATE `users` SET `sucmanh`=`sucmanh`+'$rechem'  WHERE `id` = '$user_id' LIMIT 1");
	$system = '
	Bạn bị <b>'.$login.'</b> đánh!<br/>
	<img src="http://choionline.cf/images/bidanh.png">Bạn bị  Đau quá nó giám đánh mình, <a href="/dautruong/ace/?id='.$user_id.'"><b>Đánh trả</b></a>';
	mysql_query("INSERT INTO `hoatdong` SET
	`time` = '".time()."',
	`fr_user` = '0',
	`loinhan` = '" . mysql_real_escape_string($system) . "',
	`type` = 'z',
	`user_id` = '".$id."';");
	// Обновляем время топика
	mysql_query("UPDATE `forum` SET `time` = '" . time() . "' WHERE `id` = '5047' LIMIT 1") or die('Không thể cập nhật');
	// Обновляем статистику юзера
	mysql_query("INSERT INTO `cms_mail` SET
	`user_id` = '0',
	`from_id` = '".$id."',
	`type` = 'b',
	`time` = '" . time() . "',
	");
	$msg2 = 'Bạn vừa bị '.$login.' tấn công bằng '.$chem.' HP! Lí do: '.$why.'. Hãy <a href="/dautruong/ace?id='.$user_id.'">đáp trả</a> lại nào!';
	$username = $user['name'];
	echo '<div class="gmenu"><div class="list1" style="background-color: #f7bf9d;">
	<table width="100%">
		<tr>
			<td width="33%" style="text-align: right;">
				<img src="/avatar/'.$datauser['id'].'.png"><br/>
				<b>SM: '.$datauser['sucmanh'].'</b>
			</td>
			<td width="34%" style="text-align: center;">
				<img src="/images/danhnhau.gif"><br/><br/>
				<a href="" style="background: #561d00; padding: 5px 10px; color: #fff; border: 1px; margin: 2px 2px; border-radius: 5px; margin: 10px;"><b>Đánh tiếp</b></a>
				
			</td>
			<td width="33%" style="text-align: left;">
				<img src="/avatar/'.$user['id'].'.png"><br/>
				<b>SM: '.$user['sucmanh'].'</b>
			</td>
		</tr>
	</table></div></div>
	';
	
	$randum[0] = '<div class="list1">- Bạn nắm được tóc của <b>'.$user['name'].'</b> và đập xuống đất như điên và khiến cho <b>'.$user['name'].'</b> bị tiêu hao mất '.$chem.' sức mạnh </div>';
	$randum[1] = '<div class="list1">- Bạn đã sử dụng tuyệt chiêu trấn phái, đá thẳng vào *** của <b>'.$user['name'].'</b> khiến cho <b>'.$user['name'].'</b> bị thốn và tiêu hao '.$chem.' sức mạnh </div>';
	$randum[2] = '<div class="list1">- Bạn tát liên tiếp vào mặt <b>'.$user['name'].'</b> khiến cho mặt của <b>'.$user['name'].'</b> bị xưng lên như ong đốt và bị tiêu hao mất '.$chem.' sức mạnh </div>';
	$randum[3] = '<div class="list1">- Bạn điên cuồng đập thẳng cái dép vào mặt <b>'.$user['name'].'</b> ngay lập tức <b>'.$user['name'].'</b> khóc nhè và bị tiêu hao '.$chem.' sức mạnh </div>';
	$rand = rand(0,3);
	echo '<div class="list1">'.$randum[$rand].'';
	}
	else if($datauser['sucmanh']< 100){
	echo '<div class="list1">Bạn không còn sức để thông '.$user['name'].' nữa rồi</div>';
	}
	else if($user['sucmanh'] < 100){
	echo '<div class="list1">Đối thủ đã kiệt sức rồi, đừng có thông nữa, án mạng giờ đấy!</div>';
	}
	}
	}
}



$view = $_GET['view'];
switch($view) {
case 'top':
//-- Mod Top Suc manh --/
echo '

<div class="gmenu"><div class="list1">Bạn đang có:';
if (!empty($datauser['sucmanh']))
    echo '<li>' . $datauser['sucmanh'] . ' Sức mạnh</li></div>';
else echo '<li>Bạn đang quá yếu :D</li></div>';
echo '
</div></div><div class="mainblok"><div class="phdr"> TOP SỨC MẠNH</div></div><div class="gmenu">';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `luutrusm` > 0"), 0);
$req = mysql_query("SELECT `id`, `sucmanh`, `luutrusm`, `name`, `rights` FROM `users` WHERE `luutrusm` > 0 ORDER BY `luutrusm` DESC LIMIT $start, $kmess");
if (mysql_num_rows($req)) {
$i = 0;
while ($res = mysql_fetch_assoc($req)) {
if ($res['rights'] == 0 ) {
$mau = '000000';
}
if ($res['rights'] == 1 ) {
$mau = '0000FF';
}
if ($res['rights'] == 2 ) {
$mau = '0000FF';
}
if ($res['rights'] == 3 ) {
$mau = '0000FF';
}
if ($res['rights'] == 4 ) {
$mau = '0000FF';
}
if ($res['rights'] == 5 ) {
$mau = '0000FF';
}
if ($res['rights'] == 6 ) {
$mau = '009900';
}
if ($res['rights'] == 7 ) {
$mau = 'ff00ff';
}
if ($res['rights'] == 9 ) {
$mau = 'FF0000';
}
echo '<div class="list1">';
echo '<table width="100%" cellpadding="0" cellspacing="0"><tr><td><img src="../avatar/'.$res['id'].'.png"></td>
<td width="90%">
<a href="/users/'.$res['name'].'_'.$res['id'].'.html"><span style="color:#'.$mau.'">'.$res['name'].'</span></a><br/>
SM Chiến Đấu: '.$res['sucmanh'].'<br/>
SM Tiềm Tàng: '.$res['luutrusm'].'<br/>
<a href="/dautruong/ace/?id='.$res['id'].'"><b>[Đánh]</b></td></tr></table></div>';
++$i;
}
} else {
echo '<div class="list1">Trống</div>';
}
echo '</div>';
break;
}
//-- Ket thuc top suc manh --/

require_once ("../incfiles/end.php");
?>