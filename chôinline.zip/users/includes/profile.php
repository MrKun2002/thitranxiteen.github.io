<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$lng_profile = core::load_lng('profile');
if (!$user_id) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['access_guest_forbidden']);
    require('../incfiles/end.php');
    exit;
}
$user = functions::get_user($user);
if (!$user) {
    require('../incfiles/head.php');
    echo functions::display_error($lng['user_does_not_exist']);
    require('../incfiles/end.php');
    exit;
}
$array = array(
    'activity'  => 'includes/profile',
    'ban'       => 'includes/profile',
    'edit'      => 'includes/profile',
    'images'    => 'includes/profile',
    'info'      => 'includes/profile',
    'ip'        => 'includes/profile',
    'guestbook' => 'includes/profile',
    'karma'     => 'includes/profile',
    'office'    => 'includes/profile',
    'password'  => 'includes/profile',
    'reset'     => 'includes/profile',
    'settings'  => 'includes/profile',
    'gioithieu' => 'includes/profile',
    'capduoi' => 'includes/profile',
    'stat'      => 'includes/profile',
    'friends'   => 'includes/profile'
);
$path = !empty($array[$act]) ? $array[$act] . '/' : '';
if (array_key_exists($act, $array) && file_exists($path . $act . '.php')) {
    require_once($path . $act . '.php');
} else {
    $headmod = 'profile,' . $user['id'];
    $textl = $lng['profile'] . ' của ' . htmlspecialchars($user['name']);
    require('../incfiles/head.php');
    echo '<div class="phdr">	<b>' . ($user['id'] != $user_id ? $lng_profile['user_profile'] : $lng_profile['my_profile']) . '</b>	</div>';	
    $menu = array();
    if ($user['id'] == $user_id || $rights == 9 || ($rights == 7 && $rights > $user['rights'])) {
        $menu[] = '<a href="profile.php?act=edit&amp;user=' . $user['id'] . '">' . $lng['edit'] . '</a>';
    }
    if ($user['id'] != $user_id && $rights >= 7 && $rights > $user['rights']) {
        $menu[] = '<a href="' . $set['homeurl'] . '/' . $set['admp'] . '/index.php?act=usr_del&amp;id=' . $user['id'] . '">' . $lng['delete'] . '</a>';
    }
    if ($user['id'] != $user_id && $rights > $user['rights']) {
        $menu[] = '<a href="profile.php?act=ban&amp;mod=do&amp;user=' . $user['id'] . '">' . $lng['ban_do'] . '</a>';
    }    if (!empty($menu)) {        echo '<div class="topmenu">' . functions::display_menu($menu) . '</div>';    }
    if ($user['dayb'] == date('j', time()) && $user['monthb'] == date('n', time())) {
        echo '<div class="gmenu">' . $lng['birthday'] . '!!!</div>';
    }
    echo '<div class="user"><p>' . functions::display_user($user, $arg) . '</p></div>';
	$total_photo = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `user_id` = '" . $user['id'] . "'"), 0);//MENUecho '<div class="dmenu" style="padding: 5px 4px;">';echo '<a href="profile.php?act=info&amp;user=' . $user['id'] . '" style="color:red; font-weight:bold;">Thông tin</a> · ';echo '<a href="album.php?act=list&amp;user=' . $user['id'] . '">Hình ảnh</a> (' . $total_photo . ') · ';echo '<a href="profile.php?act=friends&amp;user=' . $user['id'] . '">Bạn bè</a> ·'; echo '<a href="profile.php?act=activity&amp;user=' . $user['id'] . '">Hoạt động</a>';echo '</div>';/*
    
	$total_friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `user_id`='{$user['id']}' AND `type`='2' AND `friends`='1'"), 0);
 //Hành động
if ($user['id'] != $user_id) {
echo '<div class="list1">';
        if (!functions::is_ignor($user['id']) && functions::is_contact($user['id']) != 2) {
            if (!functions::is_friend($user['id'])) {
                $fr_in = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `from_id`='$user_id' AND `user_id`='{$user['id']}'"), 0);
                $fr_out = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_contact` WHERE `type`='2' AND `user_id`='$user_id' AND `from_id`='{$user['id']}'"), 0);
                if ($fr_in == 1) {
                    $friend = '<a class="underline" href="profile.php?act=friends&amp;do=ok&amp;id=' . $user['id'] . '">' . $lng_profile['confirm_friendship'] . '</a> | <a class="underline" href="profile.php?act=friends&amp;do=no&amp;id=' . $user['id'] . '">' . $lng_profile['decline_friendship'] . '</a>';
                } else if ($fr_out == 1) {
                    $friend = '<a class="underline" href="profile.php?act=friends&amp;do=cancel&amp;id=' . $user['id'] . '">' . $lng_profile['canceled_demand_friend'] . '</a>';
                } else {
                    $friend = '<a id="submit" href="profile.php?act=friends&amp;do=add&amp;id=' . $user['id'] . '">' . $lng_profile['in_friend'] . '</a>';
                }
            } else {
                $friend = '<a id="submit" href="profile.php?act=friends&amp;do=delete&amp;id=' . $user['id'] . '">' . $lng_profile['remov_friend'] . '</a>';
            }
            echo '<a id="submit" href="profile.php?act=friends&amp;do=add&amp;id=' . $user['id'] . '">Kết bạn</a> ';
        }
		//Hết Kết Bạn
		        if (functions::is_contact($user['id']) != 2) {
            if (!functions::is_contact($user['id'])) {
                echo '<a id="submit" href="../mail/index.php?id=' . $user['id'] . '">Contact</a> ';
            } else {
                echo '<a id="submit" href="../mail/index.php?act=deluser&amp;id=' . $user['id'] . '">Delete Contact</a> ';
            }
        }
echo '<a id="submit" href="../mail/index.php?act=write&amp;id=' . $user['id'] . '">Tin nhắn</a> ';
if (functions::is_contact($user['id']) != 2) {
            echo '<a id="submit" href="../mail/index.php?act=ignor&amp;id=' . $user['id'] . '&amp;add">Chặn</a> ';
        } else {
            echo '<a id="submit" href="../mail/index.php?act=ignor&amp;id=' . $user['id'] . '&amp;del">Bỏ chặn</a> ';
        }
echo '</div>'; 
}  
	echo '<div class="dmenu" style="padding: 5px 4px;">
	<a href="profile.php?act=info&amp;user=' . $user['id'] . '" style="color:red; font-weight:bold;">Thông tin</a> · 
	<a href="album.php?act=list&amp;user=' . $user['id'] . '">Hình ảnh</a>&nbsp;(' . $total_photo . ') · 
	<a href="profile.php?act=friends&amp;user=' . $user['id'] . '">Bạn bè</a>&nbsp;(' . $total_friends . ') · 
	<a href="profile.php?act=activity&amp;user=' . $user['id'] . '">Hoạt động</a></div>';
	
    if ($rights >= 7 && !$user['preg'] && empty($user['regadm'])) {
        echo '<div class="rmenu">' . $lng_profile['awaiting_registration'] . '</div>';
    }
    //Tường Nhà
	echo '<div class="mainblok">';
	echo '<div class="phdr">Tâm trạng</div>';        
	if ($rights >= 1) {    
	$guest = counters::guestbook(2);     
	}
	$arg = array (    
	'comments_table' => 'cms_users_guestbook', 
	// Таблица Гостевой    
	'object_table' => 'users',                 	// Таблица комментируемых объектов    
	'script' => 'profile.php?act=guestbook',   // Имя скрипта (с параметрами вызова)    
	'sub_id_name' => 'user',                   // Имя идентификатора комментируемого объекта    
	'sub_id' => $user['id'],                   // Идентификатор комментируемого объекта    
	'owner' => $user['id'],                    // Владелец объекта    
	'owner_delete' => true,                    // Возможность владельцу удалять комментарий    
	'owner_reply' => true,                     // Возможность владельцу отвечать на комментарий    
	'title' => $lng['comments'],               // Название раздела    
	'context_top' => $context_top              // Выводится вверху списка
	);
	$comm = new comments($arg);
	echo '</div>';
}

require_once('../incfiles/end.php');