<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/head.php');
$id_user = intval($_GET['user']);

$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `gioithieu`='".$id_user."'"), 0);
if($total) {
$sql = mysql_query("SELECT * FROM `users` WHERE `gioithieu`='".$id_user."' ORDER BY `id` DESC LIMIT $start, $kmess");

echo '<div class="mainblok"><div class="phdr"><b>Thống kê đa cấp dưới</b></div><table cellpadding="0" cellspacing="0" width="100%" border="1"><tr><td width="50%" align="center"><b>Thành viên</b></td><td width="50%" align="center"><b>Cấp dưới</b></td></tr>';
while ($ql = mysql_fetch_assoc($sql)) {
echo '<tr><td width="50%" align="center" border="1"><a href="/users/profile.php?user='.$ql['id'].'">'.$ql['name'].'</a></td><td width="50%" align="center" border="1"><a href="/users/profile.php?act=capduoi&user='.$ql['id'].'">Xem...</a></td></tr>';
++$i;
}
echo '</table>';
if ($total > $kmess){echo '<div class="topmenu">' . functions::display_pagination('/users/profile.php?act=capduoi&user='.$id_user.'', $start, $total, $kmess) . '</div>';
}
echo '<div class="phdr"><b>Hướng dẫn</b></div><div class="list1"><b>Xem cấp dưới</b> là những thành viên mà người đó đã giới thiệu được</div><div class="list1">Bảng sẽ được sắp xếp theo thứ tự đăng ký của thành viên với ID tăng dần</div></div>';
} else {
echo '<div class="mainblok"><div class="phdr"><b>Thống kê đa cấp dưới</b></div>' . '<div class="list1" align="center"><b>Chưa giới thiệu được thành viên nào!</b></div></div>';
}
?>
