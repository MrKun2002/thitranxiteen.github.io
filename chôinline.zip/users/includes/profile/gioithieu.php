<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/head.php');
$id_user = intval($_GET['user']);
if($id_user != $user_id) {
echo 'Bạn đang cố xem link giới thiệu của người khác!';
require('../incfiles/end.php');
exit;
}
echo '<div class="mainblok"><div class="phdr"><b>Link giới thiệu</b></div>';
echo '<div class="list1"><b>- Link giới thiệu của bạn:</b><br><input type="text" value="'.$set['homeurl'].'/reg.php?gt='.$id_user.'"/><br>+ Link giới thiệu dùng để bạn giớ thiệu cho những thành viên khác tham gia vào wap.<br>- Người giới thiệu và người được giới thiệu sẽ được cộng mội khoản tiền vào tài khoản.</div></div>';
?>
