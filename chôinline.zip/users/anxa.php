<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
require('../incfiles/head.php');
if($datauser['rights'] >= 7){
	if(isset($_GET['id'])){
		$int = intval($_GET['id']);
		if($int > 0){
			$tt = mysql_query("SELECT `name` FROM `users` WHERE `id` = '".$int."'");
			if(mysql_num_rows($tt) > 0){
				$lenhb = mysql_query("SELECT `id` FROM `cms_ban_users` WHERE `user_id` = '".$int."'");
				if(mysql_num_rows($lenhb) > 0){
					$thongtin = mysql_fetch_assoc($tt);
					mysql_query("DELETE FROM `cms_ban_users` WHERE `user_id` = '".$int."'");
					$text = '<span style="color: red;">'.$datauser['name'].'</span> vừa thực hiện ân xá cho '.$thongtin['name'].' ';
					mysql_query("INSERT INTO `thongbao`  (`user_id`, `text`, `time`) VALUES ('".$datauser['id']."','".$text."','".time()."') ");
					header('Location: ../');
				}else{
					echo 'Thành viên này không bị ban';
				}
			}else{
					echo 'Không có thành viên này';
			}
		}
	}
}else{
	echo 'Bạn không có đủ quyền để truy cập vào đây';
}
require('../incfiles/end.php');
?>
