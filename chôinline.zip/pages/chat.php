<?php
//---MOD-BY-BONGMA007---//
define('_IN_JOHNCMS', 1);// -- MEnu GAME
require ('../incfiles/core.php');
require ('../incfiles/head.php');// -- MEnu GAME
echo "<script type='text/javascript'>
$(document).ready(function(){
$(\"#datachat\").load(\"chemgio.php\");
var refreshId = setInterval(function() {
$(\"#datachat\").load('$home/chemgio.php');
$(\"#datachat\").slideDown(\"slow\");
}, 10000);
$(\"#shoutbox\").validate({
debug: false,
submitHandler: function(form) {
$.post('$home/chemgio.php', $(\"#shoutbox\").serialize(),function(chatoutput) {
$(\"#datachat\").html(chatoutput);
});
$(\"#msg\").val(\"\");
}
});
});
</script>";
?>

<?php

//-- Thông báo--//
$mp = new mainpage();
if (!$mp) {
echo '<div class="mainblok"><div class="phdr">Thông Báo</div>';
echo $mp->news;
echo '</div>';
}
if($user_id){
if(isset($_GET['gd1'])){
			mysql_query("UPDATE `users` SET `giaodien2` = '1' WHERE `id` = '".$datauser["id"]."'");
			header('Location: /');
		}
		if(isset($_GET['gd2'])){
			mysql_query("UPDATE `users` SET `giaodien2` = '0' WHERE `id` = '".$datauser["id"]."'");
			header('Location: /');
}
//--Phòng Chát--//
echo '<div class="gmenu">';
echo '<div class="list1" style="text-align: center; font-weight: bold"><table width="100%"><tr><td width="50%"><a href="/?gd1">Giao Diện Tối</a></td><td width="50%"><a href="/?gd2">Giao Diện Sáng</td></tr></table></div>';
echo '</div>';
}
echo '<div class="mainblok"><div class="phdr">';
echo 'Công Viên Trung Tâm';
if ($rights >= 9) {
echo '  <a href="/guestbook/index.php?act=clean">[Xóa]</a>';
}
echo '</div></div>';
date_default_timezone_set('Asia/Ho_Chi_Minh');
$gio_time = date("H");
$phut_time = date("i");
$ngay_time = date("d");
if($gio_time == 23 && $phut_time <= 10){
	xoa_phong_chat();
}
echo '<div class="gmenu">';
// Even
// $sql = "SELECT * FROM `even_thamgia` WHERE `user_id` = '{$user_id}'";
// $kiemtra = mysql_fetch_assoc(mysql_query($sql));
if($datauser['time_qua_even'] != $ngay_time && $ngay_time == 8){
	echo '<div class="list4"><img src="/images/hopqua.png" alt="Hop qua"/> <a href="/guestbook/nhanqua.php"><b>Bạn nhận được một món quà và lời chúc từ Forum Việt nhân ngày 8/3</b></a></div>';
}
if($user_id){
$refer = base64_encode($_SERVER['REQUEST_URI']);
$token = mt_rand(1000, 10000);
$_SESSION['token'] = $token;
echo '<div class="list2"><form name="shoutbox" id="shoutbox" action="/guestbook/index.php?act=say" method="post">'.bbcode::auto_bb('shoutbox', 'msg').'
<textarea rows="3" placeholder="Hãy viết có đấu nhé bạn, cảm ơn!" id="msg" name="msg">
</textarea><input type="hidden" name="ref" value="'.$refer.'"/>
<input type="hidden" name="token" value="'.$token.'"><br />
<input type="submit" name="submit" value="Bình Luận"><a id="submit" href="/">Tải Lại</a></form>
 
</div>
';
} else {
echo '<div class="gmenu">Bạn Cần <a href="/dang-nhap.html"> Đăng nhập </a> để chém gió. Còn chưa có thì hãy <a href="/dang-ki.html"> Đăng kí </a> để gia nhập MXH nhé!</div>';
}
echo '<div id="datachat"></div>
<div class="list5"><img src="/images/chat.png" alt="Vào trung tâm công viên"/><a href="/guestbook/"> Vào Khu Trung Tâm Công Viên...</a></div>
</div>';

//--Kết thúc Phòng Chát//

echo '<div class="list5" style="text-align: left">
<b>Like để ủng hộ M2V.ME<br/>
<iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com/m2v.me&amp;width=120&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;share=false&amp;height=21&amp;appId=635724006448099" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:120px; height:21px;" allowtransparency="true"></iframe>
<br/><a href="http://facebook.com/m2v.me" title="Truy Cập fanpage của M2V.ME">Truy cập Fanpage</a></b> | <a href="https://" rel="publisher"><b>Google+</b></a>
</div>
';
echo '</div>';
echo '<div id="nhac_nen"></div>';
?>