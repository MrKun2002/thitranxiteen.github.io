
<?php

if($user_id){
	echo '<div class="phdr">Đang trong thành phố ChoiOnline</div>';

echo '<div class="list1"><center>
<div style="height: 150px; text-align: center; margin: auto;">
<span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/shop/"><img src="/images/khumuasam.png" width="25px" alt="icon"/><br><b>Khu Mua Sắm</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/sanbay/"><img src="/images/sanbay.png" width="25px" alt="icon"/><br><b>Sân Bay</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/nongtrai/?act=1"><img src="/images/nongtrai.png" width="25px" alt="icon"/><br><b>Nông Trại</b></a><br/>
</span><span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/cauca/"><img src="/images/khu-sinh-thai-1.png" width="25px" alt="icon"/><br><b>Khu Sinh Thái</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/gamemini/boss/"><img src="/images/dautruong.png" width="25px" alt="icon"/><br><b>Vượt Ải</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/khucongvien.php"><img src="/images/khumuasam.png" width="25px" alt="icon"/><br><b style="color: red;">Công Viên</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/giaitri/"><img src="/images/giaitri.png" width="25px" alt="icon"/><br><b>Khu Giải Trí</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/nhatu"><img src="/images/sanbay.png" width="25px" alt="icon"/><br><b>Nhà Tù</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left; font-size: 10px;">
<a href="/khuchoden/"><img src="/images/choden.png" width="25px" alt="icon"/><br><b>Chợ Đen</b></a>
</span></div></center></div></div><div class="clear"></div></div>';
//-- Thông báo--//
$mp = new mainpage();
if (!$mp) {
echo '<div class="mainblok"><div class="phdr">Thông Báo</div>';
echo $mp->news;
echo '</div>';

}
}
else{
echo '<div class="mainblok"><div class="phdr">Hệ thống</div>';
	echo '<div class="rmenu">
<center><form action="/login.php" method="post">
Tài khoản: <input type="text" name="n" value="" maxlength="28" size="0" class="name"/><br> 
Mật Khẩu: <input type="password" name="p" maxlength="25" size="0" class="pass"/>
<input type="hidden" name="mem" value="1" checked="checked"/><br>
<input type="submit" name="dangnhap" value="Chơi thôi"/>
</form>
<div style="font-size:10px;">
								Nếu bạn chưa có tài khoản, vui lòng <a href="/dang-ki.html">đăng ký</a></div></center>


';
echo '</div>';
}

?>