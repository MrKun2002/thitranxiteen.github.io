﻿
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SilverHand" />
	<title>Thong bao nap the</title>
</head>
<body>
<?php

include('../class/BKTransactionAPI.php');
if(isset($_POST['napthe'])){
	
	$seri = $_POST['txtseri'];
	$sopin = $_POST['txtpin'];
	$mang = $_POST['chonmang'];
	$user = $_POST['txtuser'];
//------------Chon mang--------------------
	if($mang==92){
			$ten = "Mobiphone";
		}
	else if($mang==107){
			$ten = "Viettel";
		}
	else if($mang==120){
			$ten = "Gate";
		}

	else $ten ="Vinaphone";
	}

$bk = new BKTransactionAPI("https://www.baokim.vn/the-cao/saleCard/wsdl");//link thật
$transaction_id = time();
$secure_pass = '0f7bcca1f2a9b50f';
	/*
	 * API nap the cao dien thoai cho Merchant
	 * */
	$info_topup = new TopupToMerchantRequest();
	$info_topup->api_username = 'ugrpvn';
	$info_topup->api_password = 'ugrpvn3456gtrhyh';
	$info_topup->card_id = $mang;
	$info_topup->merchant_id = '12363';
	$info_topup->pin_field = $sopin;
	$info_topup->seri_field = $seri;
	$info_topup->transaction_id = $transaction_id;

$data_sign_array = (array)$info_topup;
ksort($data_sign_array);

$data_sign = md5($secure_pass . implode('', $data_sign_array));
$info_topup->data_sign = $data_sign;
$test = new TopupToMerchantResponse();
$test = $bk->DoTopupToMerchant($info_topup);
date_default_timezone_set('Asia/Ho_Chi_Minh');
$time = date("Y-m-d H:i:s",mktime());
if($test->error_code==0){
	$tien = $test->info_card; 	
	switch($tien)
	{
		case 10000 : $gd = 100; break;
		case 20000 : $gd = 200; break;
		case 30000 : $gd = 300; break;
		case 50000 : $gd = 500; break;
		case 100000 : $gd = 1000; break;
		case 200000 : $gd = 2000; break;
		case 300000 : $gd = 3000; break;
		case 500000 : $gd = 5000; break;
		case 1000000 : $gd = 10000; break;
	}

	$file = "carddung.log";
	$fh = fopen($file,'a');
	fwrite($fh,"Tai khoan: ".$user.", Do muon mua: ".$item.", Loai the: ".$ten.", Menh gia: ".$tien.", Thoi gian: ".$time);
	fwrite($fh,"\r\n");
	fclose($fh);

	echo '<script>alert("Bạn đã thanh toán thành công thẻ cào '.$ten.' với mệnh giá '.$test->info_card.'");</script>';
	echo '<script>window.location=" http://likecuoi.com/vip/index.php";</script>';

}
else {echo '<script>alert("Thong tin the cao khong hop le (da su sung) !");</script>';
	echo $test->error_message;
	echo $test->error_code;
	$file = "cardsai.log";
	$fh = fopen($file,'a');
	fwrite($fh,"Tai khoan: ".$user.", Ma the: ".$sopin.", Seri: ".$seri.", Noi dung loi: ".$test->error_message.", Thoi gian: ".$time);
	fwrite($fh,"\r\n");
	fclose($fh);

}

?>
<script>
	window.location="../index.php";
</script>
</body>
</html>