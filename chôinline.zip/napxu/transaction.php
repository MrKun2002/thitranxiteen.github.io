<?php
header('Content-Type: text/html; charset=utf-8');
define('CORE_API_HTTP_USR', 'merchant_13754');
define('CORE_API_HTTP_PWD', '137549sa8dausoidj9wusaidoaisjd09wpodijsaupodjas8d');

$bk = 'https://www.baokim.vn/the-cao/restFul/send';
$seri = isset($_POST['txtseri']) ? $_POST['txtseri'] : '';
$sopin = isset($_POST['txtpin']) ? $_POST['txtpin'] : '';
//Loai the cao (VINA, MOBI, VIETEL, VTC, GATE)
$mang = isset($_POST['chonmang']) ? $_POST['chonmang'] : '';
$user = $_POST['txtuser'];

	if($mang=='MOBI'){
			$ten = "Mobifone";
		}
	else if($mang=='VIETEL'){
			$ten = "Viettel";
		}
	else if($mang=='GATE'){
			$ten = "Gate";
		}
	else if($mang=='VTC'){
			$ten = "VTC";
		}
	else $ten ="Vinaphone";

//Mã MerchantID dang kí trên Bảo Kim
$merchant_id = '13754';
//Api username 
$api_username = 'm2vme';
//Api Pwd d
$api_password = 'm2vme9sjgsJsd9ujbdusjv';
//Mã TransactionId 
$transaction_id = time();
//mat khau di kem ma website dang kí trên B?o Kim
$secure_code = 'da8ef929e96712d5';

$arrayPost = array(
	'merchant_id'=>$merchant_id,
	'api_username'=>$api_username,
	'api_password'=>$api_password,
	'transaction_id'=>$transaction_id,
	'card_id'=>$mang,
	'pin_field'=>$sopin,
	'seri_field'=>$seri,
	'algo_mode'=>'hmac'
);

ksort($arrayPost);

$data_sign = hash_hmac('SHA1',implode('',$arrayPost),$secure_code);

$arrayPost['data_sign'] = $data_sign;

$curl = curl_init($bk);

curl_setopt_array($curl, array(
	CURLOPT_POST=>true,
	CURLOPT_HEADER=>false,
	CURLINFO_HEADER_OUT=>true,
	CURLOPT_TIMEOUT=>30,
	CURLOPT_RETURNTRANSFER=>true,
	CURLOPT_SSL_VERIFYPEER => false,
	CURLOPT_HTTPAUTH=>CURLAUTH_DIGEST|CURLAUTH_BASIC,
	CURLOPT_USERPWD=>CORE_API_HTTP_USR.':'.CORE_API_HTTP_PWD,
	CURLOPT_POSTFIELDS=>http_build_query($arrayPost)
));

$data = curl_exec($curl);

$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

$result = json_decode($data,true);

date_default_timezone_set('Asia/Ho_Chi_Minh');
$time = date("Y-m-d H:i:s",mktime());
//$time = time();roi
if($status==200){
    $amount = $result['amount'];
	switch($amount) {
		case 10000 :$xu = 10000;break;
	//			case 10000 :$xu = 10000;break;

		case 20000 :$xu = 25000;break;
//				case 20000 :$xu = 37000;break;

		case 30000 :$xu = 38000;break;
//				case 30000 :$xu = 57000;break;

		case 50000 :$xu = 70000;break;
//				case 50000 :$xu = 105000;break;

		case 100000 :$xu = 150000;break;
//				case 100000 :$xu = 300000;break;

		case 200000 :$xu = 350000;break;
//				case 200000 :$xu = 700000;break;

		case 500000 :$xu = 1100000;break; 
//				case 500000 :$xu = 2200000;break; 

	}
		
	$dbhost="localhost";
    $dbuser="m2vm_123";
    $dbpass="vipprom2";
    $dbname="m2vm_123";
    $db = mysql_connect($dbhost,$dbuser,$dbpass) or die("cant connect db");
	mysql_select_db($dbname,$db) or die("cant select db");
	$id = "select id from users where name_lat = '$user'";
	
		$result = mysql_query($id,$db) or die($sql_ins);
		$ktm2v = mysql_fetch_array($result);
	
		@mysql_query("UPDATE users set  balans =balans + $xu  WHERE id= '".$ktm2v['id']."'");

	echo '<script>
	alert("Bạn đã thanh toán thành công thẻ '.$ten.' mệnh giá '.$amount.' ");
	
	window.location.href = "http://choionline.cf/";
	</script>';

}
else{

	  
	

	echo '<script>
	alert("Thong tin the cao khong hop le!");
	
	window.location.href = "http://choionline.cf/";
	</script>';
}

