<?php
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
$textl = 'Quay Số';
require('../../incfiles/head.php');
echo '
<div class="phdr">Quay Số Đây</div>
<div class="gmenu">';
if($user_id){
mysql_query("UPDATE `users` SET `can-cau` = '7' WHERE `id` = '".$datauser['id']."' LIMIT 1");
	echo '
<div class="list1"><table width="100%"><tbody><tr><td width="6%"><img src="img/quayso.gif" alt="">&nbsp;</td><td class="list1"  style="padding: 0px;" width="80%">
<style>
.list3{
background-color: #ecf9ff;
	border-radius: 5px;
	padding: 8px;
	border: solid 1px #cfe7f4;
}
</style>
<div class="list3"><a href="xu/">Quay số bằng xu</a></div>
<div class="list3"><a href="luong/">Quay số bằng lượng</a></div>
<div class="list3"><a href="chuyencan/">Quay số miễn phí</a></div>
</div></div></td></tr></tbody></table></div>

';

echo '<div class="list1"><center></center><b></b></div>';


}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng này nhé!</div>';
}
require('../../incfiles/end.php');
?>