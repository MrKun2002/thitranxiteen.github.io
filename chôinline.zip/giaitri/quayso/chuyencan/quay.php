<?php
/////////////////////////////////////////////////////
//---- CODE BOI VODOIVN VTG - choionline.cf -----//
///////////////////////////////////////////////////
// Xin hay giu ban quyen
define('_IN_JOHNCMS', 1);
require_once('../../../incfiles/core.php');
$textl = 'Quay Số';
require('../../../incfiles/head.php');
echo '
<div class="phdr">Quay Số Đây</div>
<div class="gmenu">';
if($user_id){
mysql_query("UPDATE `users` SET `can-cau` = '7' WHERE `id` = '".$datauser['id']."' LIMIT 1");
// ---Quay số bằng chuyencan--- //
if($datauser[chuyencan] >= 5){
if(isset($_GET[id])){
$int = intval($_GET[id]);
$ktsoluong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_quayso` WHERE `id` = '$int'"), 0);
if($ktsoluong >= 1){
if(isset($_GET[chuyencan])){
$tk_shop = mysql_fetch_array(mysql_query("SELECT * FROM `shop_quayso` WHERE `id` = '$int'"));
$loaisp = $tk_shop[loaisp];
$name_id = $tk_shop[name_id];
$tk_khodo = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `id_user` = '$user_id' AND `name` = '$name_id' AND `loaisp` = '$loaisp'"), 0);
if($tk_khodo == 0){
mysql_query("UPDATE `users` SET `chuyencan`= `chuyencan`-'5' WHERE `id` = '$datauser[id]'");
mysql_query("UPDATE `users` SET `fermer_oput`= `fermer_oput`+'25' WHERE `id` = '$datauser[id]'");
if(exp_chinhc($datauser[exp_chinh]) != ""){
	mysql_query("UPDATE `users` SET
		`exp_chinh` = `exp_chinh` + 1
		WHERE `id` = '{$user_id}'
		");
	}
// Mod ngan ngan gon
$kt_name = $tk_shop['name'];
$kt_loaisp = $tk_shop['loaisp'];
$kt_tile = $tk_shop['tile'];
// -- Mod ham random trung do -- //
$rand = rand(1,$kt_tile);
if($rand == 1){
	mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`) VALUES  ('$tk_shop[name_id]', '$tk_shop[loaisp]', '".$user_id."' , '$tk_shop[sucmanh]','$tk_shop[giaban]', '$tk_shop[name_vp]') ");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Xin chúc mừng bạn đã quay được '.$tk_shop['name_vp'].' và 25 kinh nghiệm!</div>';
	}else{
	$rand_do[1] = $tk_shop['name_dorand1'];
	$rand_do[2] = $tk_shop['name_dorand2'];
	$rand_do[3] = $tk_shop['name_dorand3'];
	$rand_do_nn = rand(1,3);
	$tk_khodo2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `id_user` = '$user_id' AND `name` = '".$rand_do[$rand_do_nn]."' AND `loaisp` = '$loaisp'"), 0);
	if($rand_do[$rand_do_nn] != 0 && $tk_khodo2 == 0){
	$tk_shop2 = mysql_fetch_array(mysql_query("SELECT * FROM `shop` WHERE `name` = '".$rand_do[$rand_do_nn]."' AND `loaisp` = '".$tk_shop["loaisp"]."'"));
	mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `giamua`, `giaban`, `time`) VALUES  ('".$tk_shop2['name']."', '".$tk_shop2['loaisp']."', '".$user_id."', '".$tk_shop2['giamua']."','".$tk_shop2['giaban']."','".$timedo."') ");
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn quay bị trượt và nhận được '.$tk_shop2['tenvatpham'].' và 25 kinh nghiệm !</div>';
	}else{
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn quay trượt rồi bạn nhận được 25 kinh nghiệm nông trại';
		if(exp_chinhc($datauser[exp_chinh]) != ""){
		
		echo 'và 1 điểm kinh nghiệm lerver chính!';
		}
		echo '</div>';
	}
}
}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn đã có món đồ này rồi quay làm gì nữa !</div>';
}
}
$xemdo = mysql_fetch_array(mysql_query("SELECT * FROM `shop_quayso` WHERE `id` = '$int' LIMIT 1"));
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$xemdo['loaisp'].'/'.$xemdo['name_id'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
$tiledinh = floor(1/$xemdo[tile]*100);
echo '
Tăng: '.$xemdo['sucmanh'].' SM<br/>
Tỉ lệ quay được: '.$tiledinh.' %<br/>
Cần: 5 Điểm Chuyên Cần ';
if($datauser[chuyencan] >= 5){
echo '<span style="color: #0A8B33;">(Đã đủ)</span>';
}else{
echo '<span style="color: red;">(Chưa đủ)</span>';
}
echo '<br/>';
echo '<b>[ <a href="'.$xemdo['id'].'&chuyencan">Quay Số</a> ]</b>
<br/>
</td></tr></tbody></table>
</div>';
}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Không có món đồ như này bạn à!</div>';
}
}
}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ điểm chuyên cần!</div>';
}
//---Kết thúc quay số bằng chuyên cần---//
echo '<div class="list1"><center></center><b></b></div>';


}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng này nhé!</div>';
}
require('../../../incfiles/end.php');
?>