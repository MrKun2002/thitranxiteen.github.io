<?php
/////////////////////////////////////////////////////
//---- CODE BOI VODOIVN VTG - choionline.cf -----//
///////////////////////////////////////////////////
// Xin hay giu ban quyen
define('_IN_JOHNCMS', 1);
require_once('../../../incfiles/core.php');
$textl = 'Quay Số';
require('../../../incfiles/head.php');
echo '
<div class="phdr">Quay Số Đây</div>
<div class="gmenu">';
if($user_id){
mysql_query("UPDATE `users` SET `can-cau` = '7' WHERE `id` = '".$datauser['id']."' LIMIT 1");
// ---Quay số bằng xu--- //
if($datauser[balans] >= 7000){
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `shop_quayso`"), 0);
$req = mysql_query("SELECT * FROM `shop_quayso` WHERE `id` ORDER BY `id` DESC LIMIT $start, $kmess");
while($post = mysql_fetch_array($req)){
echo '<div class="menu list-top">
<table cellpadding="0" cellspacing="0" width="100%">
<tbody><tr><td width="50">
<img src="/images/'.$post['loaisp'].'/'.$post['name_id'].'.png" alt="*" class="portrait"/>
</td><td width="auto" valign="top">';
$tiledinh = floor(1/$post[tile]*100);
echo '
<b>[ <a href="quay/'.$post['id'].'">'.$post['name_vp'].'</a> ]</b><br/>
Tăng: '.$post['sucmanh'].' SM<br/>
Tỉ lệ quay được: '.$tiledinh.' %';
echo '<br/>
</td></tr></tbody></table>
</div>';
}
if ($tong > $kmess){ //Phân Trang
echo '<div class="trang">' . functions::display_pagination('?', $start, $tong, $kmess) . '</div>';
}
}else{
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn không đủ xu!</div>';
}
//---Kết thúc quay số bằng xu---//
echo '<div class="list1"><center></center><b></b></div>';


}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng này nhé!</div>';
}
require('../../../incfiles/end.php');
?>