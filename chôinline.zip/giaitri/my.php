<?php
define('_IN_JOHNCMS', 1);

require_once('../incfiles/core.php');
$textl = 'Khu Mua Sắm';
if($user_id){
mysql_query("UPDATE `users` SET `can-cau` = '7' WHERE `id` = '".$datauser['id']."' LIMIT 1");
//-- Online Topic ---//
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '7'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '7'"), 0);
$totalonline = $online_u + $online_g;
$q = @mysql_query("select * from `users` where `lastdate` > " . (time() - 300) . " AND `can-cau` = '7';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)){
$trinhtrangvip = mysql_query("select `rights` from `users` where id='" . $arr['id'] . "'");
$trinhtrangviphonnua = mysql_fetch_array($trinhtrangvip);
if($arr['id'] != $datauser['id']){
$u_on[]='<a href="../users/' . $arr['name'] . '_' . $arr['id'] . '.html"><img src="/avatar/' . $arr['id'] . '.png"></a>';
}else{
	$u_on[]='<img src="/avatar/' . $arr['id'] . '.png">';
}
}
//Keet thuc topic
if($datauser['giaodien'] == 1){
date_default_timezone_set('Asia/Ho_Chi_Minh');
$kiemtra = date("H");
if($kiemtra >= 6 && $kiemtra <= 18){
echo '<div class="cola" style="padding: 0px;"><div class="nengiaitri_sang">
<marquee behavior="scroll" direction="left" scrollamount="1" style="margin-top: 10px"><img src="/iconvip/may1.png"></marquee>
</div><div class="legiaitri"></div>';
}else{
echo '<div class="cola" style="padding: 0px;"><div class="nengiaitri_toi">
</div><div class="legiaitri"></div>
';
}
echo '
<div style="margin-top: -30px;text-align: center;">
<a href="/giaitri/quayso/"><img style="margin-right: -10px; z-index: 100" src="img/quayso.gif" style="z-index: 1;"></a><img src="img/quayso.png"/><span style="margin-left: 70px;"></span><a href="/gamemini/"><img src="img/game.png"/></a>
</div>
<div class="nenda">';
if ($online_u > 0){
echo implode(' ',$u_on).'';
}else{
	echo 'Trống';
}
echo '</div></div>';
}else{
echo '<div class="list1"><img src="/icon/next.png"> <a href="/giaitri/quayso/"><b>Quay Số</b></a> (Hãy cố giành lấy các món đồ tại đây nào)</div>
<div class="list1"><img src="/icon/next.png"> <a href="/gamemini/"><b>Game Mini</b></a> (Bạn có thể tham gia chơi caro, sóc đĩa)</div>
';
}
}
?>