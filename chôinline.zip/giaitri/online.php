<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
if($user_id){
mysql_query("UPDATE `users` SET `can-cau` = '5' WHERE `id` = '".$datauser['id']."' LIMIT 1");
}
?>