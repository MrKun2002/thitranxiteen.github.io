<?php
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
$textl = 'Chuyển hóa sức mạnh';
require('../../incfiles/head.php');
require('function.php');
echo '<div class="phdr">Chuyển hóa sức mạnh</div><div class="gmenu">';
if($user_id){
	mysql_query("UPDATE `users` SET `can-cau` = '7' WHERE `id` = '".$datauser['id']."' LIMIT 1");
	echo '<div class="list1"><center></center><b></b></div>';
}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng này nhé!</div>';
}
require('../../incfiles/end.php');
?>