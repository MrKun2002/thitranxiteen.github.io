<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Quà tặng mỗi ngày';
require_once('../incfiles/head.php');
echo '<div class="phdr"><b>QUÀ TẶNG</b></div>';
echo '<div class="list1"><b><img src="/images/hopqua.png" alt="Nhận quà"/> Mỗi giờ sẽ nhận một lần nhé!.</b></div>';
if($datauser['thoigianon'] >= 3600)
{
	$randumqua = rand(1,21);
	if($randumqua == 1){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'300', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'300', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn nhận được 300 xu từ hệ thống!, cũng hơi ít nhỉ.</b></div>';
	}
	if($randumqua == 2){
	mysql_query("UPDATE `users` SET balans`=`balans`+'400', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET balans`=`balans`+'400', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn nhận được 400 xu từ hệ thống!.</b></div>';
	}
	if($randumqua == 3){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'500', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'500', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn nhận được 500 xu từ hệ thống!.</b></div>';
	}
	if($randumqua == 4){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'600', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'600', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn nhận được 600 xu từ hệ thống!.</b></div>';
	}
	if($randumqua == 5){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'700', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'700', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn nhận được 700 xu từ hệ thống!.</b></div>';
	}
	if($randumqua == 6){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'800', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'800', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn nhận được 800 xu từ hệ thống!.</b></div>';
	}
	if($randumqua == 7){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'900', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'900', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn nhận được 900 xu từ hệ thống!.</b></div>';
	}
	if($randumqua == 8){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'100', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'100', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Quá nhọ cho bạn, bạn nhận được 100 xu từ hệ thống. Chia buồn!!</b></div>';
	$text = '<span style="color: red;">'.$datauser['name'].'</span> thật may mắn mở hộp quà online mỗi giờ được 100 Xu, xin chia buồn ';
	mysql_query("INSERT INTO `thongbao`  (`user_id`, `text`, `time`) VALUES ('".$datauser['id']."','".$text."','0') ");
	}
	if($randumqua == 9){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'200', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'200', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn nhận được 200 xu từ hệ thống!. Chắc không bỏ dính răng rồi!</b></div>';
	}
	if($randumqua == 10){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1000', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1000', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn thật may mắn đã mở được 1000 xu</b></div>';
	}
	if($randumqua == 11){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'550', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'550', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn đã mở được 550 xu!</b></div>';
	}
	if($randumqua == 12){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'50', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'50', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn đã mở được 50 xu! Ui thật không may, :( Đừng tìm AD báo thù nhé, đây là do Già Làng :D</b></div>';
	$text = 'Zê <span style="color: red;">'.$datauser['name'].'</span> thật may mắn mở hộp quà online mỗi giờ được 50 Xu, xin chia buồn với bạn! ';
	mysql_query("INSERT INTO `thongbao`  (`user_id`, `text`, `time`) VALUES ('".$datauser['id']."','".$text."','0') ");
	}
	if($randumqua == 13){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1200', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1200', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Thật may mắn bạn mở được 1200 Xu</b></div>';
	}
	if($randumqua == 14){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1300', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1300', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Thật may mắn bạn mở được 1300 Xu.</b></div>';
	}
	if($randumqua == 15){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1400', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1400', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Thật may mắn bạn mở được 1400 Xu.</b></div>';
	}
	if($randumqua == 16){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1500', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1500', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Thật may mắn bạn mở được 1500 Xu, đi khoe thôi nào!.. Hoho</b></div>';
	}
	if($randumqua == 17){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1600', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1600', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Thật may mắn bạn mở được 1600 Xu, đi khoe thôi nào!.. Hoho</b></div>';
	}
	if($randumqua == 18){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1700', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1700', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Thật may mắn bạn mở được 1700 Xu, đi khoe thôi nào!.. Hoho</b></div>';
	}
	if($randumqua == 19){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1800', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1800', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Thật may mắn bạn mở được 1800 Xu, đi khoe thôi nào!.. Hoho</b></div>';
	$text = '<span style="color: red;">'.$datauser['name'].'</span> thật may mắn mở hộp quà online mỗi giờ được 1800 Xu ';
	mysql_query("INSERT INTO `thongbao`  (`user_id`, `text`, `time`) VALUES ('".$datauser['id']."','".$text."','0') ");
	}
	if($randumqua == 20){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'1900', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'1900', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Thật may mắn bạn mở được 1900 Xu, đi khoe thôi nào!.. Hoho</b></div>';
	$text = '<span style="color: red;">'.$datauser['name'].'</span> thật may mắn mở hộp quà online mỗi giờ được 1900 Xu ';
	mysql_query("INSERT INTO `thongbao`  (`user_id`, `text`, `time`) VALUES ('".$datauser['id']."','".$text."','0') ");
	}
	if($randumqua == 21){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'550', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'550', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn đã mở được 550 xu!</b></div>';
	}
	if($randumqua == 22){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'550', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'550', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn đã mở được 550 xu!</b></div>';
	}
	if($randumqua == 23){
	mysql_query("UPDATE `users` SET `balans`=`balans`+'666', `thoigianon` = '0' WHERE `id`='{$user_id}'");
	$q="UPDATE `users` SET `balans`=`balans`+'666', `thoigianon` = '0' WHERE `id`='{$user_id}'";
	mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/nhanon.php','".date('d-m-Y  h:i:s A')."')");
	echo '<div class="list1"><b>Bạn đã mở được 666 xu!</b></div>';
	}
	
} else {echo '<div class="list1"><b><font color="red">Lỗi </font> Bạn đã nhận quà rồi</b></div>';}echo '</div>';
require_once('../incfiles/end.php');
?>