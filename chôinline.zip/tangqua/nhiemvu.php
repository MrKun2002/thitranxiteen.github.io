<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Nhiệm vụ mỗi ngày';
require_once('../incfiles/head.php');
echo '<div class="phdr"><b>QUÀ TẶNG</b></div>';
echo '<b>Lái buôn</b>: Nhiệm vụ hôm nay là bạn phải thu hoạch được 4 cây cà chua';
$timcachua == mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user` = '$datauser[id]'");
if($timcachua[semen] == 4){
	echo 'timf thay';
}else{
echo 'khong thay';
}


require_once('../incfiles/end.php');
?>