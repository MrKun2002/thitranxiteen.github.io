<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Quà tặng mỗi ngày';
require_once('../incfiles/head.php');
echo '
<div class="phdr">COPY VĂN BẢN</div>
<b>Văn bản cho mạng xã hội như facebook, my teamobi, forum ngọc rồng, hiệp sĩ </b>
<textarea>
choionline chính thức gia mắt mọi người với phiên bản hoàn toàn mới, một diễn đàn game thủ đang hot nhất hiện nay với những tính năng đọc đáo như chơi avatar ngay trên wap, cùng trải nghiệm cậu cá và chăm farm bá đạo nhất thời đại không hề hút máu. 
Ngoài ra khi bạn đến với choionline.cf bạn sẽ còn có những cơ hội tham gia những even với giải thưởng là những chiếc thẻ cào điện thoại giá trị hay là những cuộc chém gió tung nóc nhà của ae trong toàn thể choionline.cf. Vâng choionline.cf là một trang không thể không ghé thăm đúng không các bạn. Truy cập ngay http://choionline.cf để tham gia ngay nào các bạn
</textarea>
<br/><b>Văn bản BBCODE copy lên các forum như m4v,...</b>
<textarea>
[b]choionline[/b] chính thức gia mắt mọi người với phiên bản hoàn toàn mới, một diễn đàn game thủ đang hot nhất hiện nay với những tính năng đọc đáo như chơi avatar ngay trên wap, cùng trải nghiệm cậu cá và chăm farm bá đạo nhất thời đại không hề hút máu.
Ngoài ra khi bạn đến với [url=http://choionline.cf]choionline.cf[/b][/url] bạn sẽ còn có những cơ hội tham gia những even với giải thưởng là những chiếc thẻ cào điện thoại giá trị hay là những cuộc chém gió tung nóc nhà của ae trong toàn thể choionline.cf. Vâng [b]choionline.cf[/b] là một trang không thể không ghé thăm đúng không các bạn. Truy cập ngay [url=http://choionline.cf/dang-ki.html][b]Hãy vào đăng kí ngay[/b][/url] để tham gia ngay nào các bạn
</textarea>
<br/><b>Văn bản HTML copy lên các trang wap của bạn</b>
<textarea>
<b>choionline</b> chính thức gia mắt mọi người với phiên bản hoàn toàn mới, một diễn đàn game thủ đang hot nhất hiện nay với những tính năng đọc đáo như chơi avatar ngay trên wap, cùng trải nghiệm cậu cá và chăm farm bá đạo nhất thời đại không hề hút máu.<br/> Ngoài ra khi bạn đến với <a href="http://choionline.cf"><b>choionline.cf</b></a> bạn sẽ còn có những cơ hội tham gia những even với giải thưởng là những chiếc thẻ cào điện thoại giá trị hay là những cuộc chém gió tung nóc nhà của ae trong toàn thể choionline.cf. Vâng <b>choionline.cf</b> là một trang không thể không ghé thăm đúng không các bạn. Truy cập ngay <a href="http://choionline.cf/dang-ki.html"><b>Hãy vào đăng kí ngay</a></b> để tham gia ngay nào các bạn
</textarea>
';
require_once('../incfiles/end.php')
?>