<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Quà tặng mỗi ngày';
require_once('../incfiles/head.php');
echo '<div class="phdr"><b>QUÀ TẶNG</b></div>';
echo '<div class="list1"><b>Bạn chỉ được nhận quà duy nhất một lần một ngày.</b></div>';
if(time() > $datauser['tgiannhanqua'] + 3600 * 24){echo '<div class="list1">';
$rand = rand(1,21);
if($rand == 1) {echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn rất may mắn đã mở được 3000 xu từ hộp quà may mắn mỗi ngày!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'3000', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'3000', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
$text = '<span style="color: red;">'.$datauser['name'].'</span> thật may mắn mở hộp quà hàng ngày được 3000 xu ';
mysql_query("INSERT INTO `thongbao`  (`user_id`, `text`, `time`) VALUES ('".$datauser['id']."','".$text."','".time()."') ");
} 
else if($rand == 2) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 200 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'200', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'200', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
} 
else if($rand == 3) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 300 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'300', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'300', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
} else if($rand == 4) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 400 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'400', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'400', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
} else if($rand == 5) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 500 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'500', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'500', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
} 
else if($rand == 6) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 600 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'600', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'600', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
} 
else if($rand == 7) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 700 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'700', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'700', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
} 
else if($rand == 8) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 800 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'800', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'800', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
} 
else if($rand == 9) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 900 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'900', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'900', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
} 
else if($rand == 10) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 1000 xu từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `balans`=`balans`+'1000', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'1000', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./tangqua/index.php','".date('d-m-Y  h:i:s A')."')");
}
else if($rand == 11) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 10 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'10', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 12) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 20 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'20', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 13) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 30 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'10', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 14) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 40 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'40', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 15) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 50 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'50', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 16) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 60 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'60', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 17) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 70 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'70', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 18) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 80 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'80', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 19) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 90 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'90', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 20) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 100 kinh nghiệm từ hộp quà may mắn!';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'100', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
}
else if($rand == 21) {
echo '<img src="/images/hopqua.png" alt="Nhận quà"/> Bạn nhận được 200 kinh nghiệm từ hộp quà may mắn! Xin chúc mừng bạn';
mysql_query("UPDATE `users` SET `fermer_oput`=`fermer_oput`+'200', `tgiannhanqua` = '".time()."' WHERE `id`='{$user_id}'");
$text = '<span style="color: red;">'.$datauser['name'].'</span> thật may mắn mở hộp quà hàng ngày được 200 Kinh nghiệm ';
mysql_query("INSERT INTO `thongbao`  (`user_id`, `text`, `time`) VALUES ('".$datauser['id']."','".$text."','".time()."') ");
}
}
else {echo '<div class="list1"><b><font color="red">Lỗi </font> Bạn đã nhận quà rồi</b></div>';
}echo '</div>';
require_once('../incfiles/end.php');
?>