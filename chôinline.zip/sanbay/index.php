<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Sân Bay';
require('../incfiles/head.php');
if($user_id){
echo '<div class="phdr">Sân Bay</div>
<div class="gmenu">
<div class="list1"><img src="/icon/next.png"> <b><a href="daohoang">Đi Đến Đảo Hoang</a></b><br/>- Là nơi chứa nhiều khoáng sản và các vật phẩm quý báu...</div>
<div class="list1"><img src="/icon/next.png"> <b><a href="house">Đi Hollywood</a></b><br/>- Hãy đến và mua sắm những ngôi nhà trong mơ và tiêu tiền theo cách của bạn đi nào :D...</div>
<div class="list1"><img src="/icon/next.png"> Đang cập nhật thêm nơi đến...</div>
</div>';
}
require('../incfiles/end.php');
?>