<?php
define('_IN_JOHNCMS', 1);
$headmod = 'mod';
$textl = 'Hoang đảo';
require('../../incfiles/core.php');
if(!$user_id){
require('../../incfiles/head.php');
echo functions::display_error($lng['access_guest_forbidden']);
require('../../incfiles/end.php');
exit;
}
$textl = 'Khu Khai Quật';
require('../../incfiles/head.php');
mysql_query("UPDATE `users` SET `can-cau` = '6' WHERE `id` = '".$datauser['id']."' LIMIT 1");
//-- Online Topic ---//
$online_u = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '6'"), 0);
$online_g = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > " . (time() - 300) . " AND `can-cau` = '6'"), 0);
$totalonline = $online_u + $online_g;
$q = @mysql_query("select * from `users` where `lastdate` > " . (time() - 300) . " AND `can-cau` = '6';");
$count = mysql_num_rows($q);
while ($arr = mysql_fetch_array($q)){
$trinhtrangvip = mysql_query("select `rights` from `users` where id='" . $arr['id'] . "'");
$trinhtrangviphonnua = mysql_fetch_array($trinhtrangvip);
if($arr['id'] != $datauser['id']){
$u_on[]='<a href="../../users/' . $arr['name'] . '_' . $arr['id'] . '.html"><img src="/avatar/' . $arr['id'] . '.png"></a>';
}else{
	$u_on[]='<img src="/avatar/' . $arr['id'] . '.png">';
}
}
echo '<div class="mainblok"><div class="phdr"><b>Hoang đảo</b></div>';
$kt = mysql_result(mysql_query("SELECT COUNT(*) FROM `daovang` WHERE `user_id`='{$user_id}'"), 0);
if($kt == 0) {
mysql_query("INSERT INTO `daovang` SET `user_id`='{$user_id}', `doben`='100', `coin`='0', `kcuong`='0', `vang`='0'");
}
$dv = mysql_fetch_array(mysql_query("SELECT * FROM `daovang` WHERE `user_id`='{$user_id}'"));
$time = time();
echo '<div class="list1">Sức khỏe: <b>'.$dv['doben'].'/100</b>';
if(($dv['time'] + 28800) > time()) {
$time = $dv['time'] + 28800 - time();
echo ' - Bạn cần '.date('H:i', $time).' phút nữa để phục hồi sức khỏe!';
}
echo '</div>';
date_default_timezone_set('Asia/Ho_Chi_Minh');
$kiemtra = date("H");
if($kiemtra >= 6 && $kiemtra <= 18){
echo '<div class="nenkhaiquat">
<marquee behavior="scroll" direction="left" scrollamount="1" style="margin-top: 5px"><img src="/iconvip/may1.png"></marquee>
<marquee behavior="scroll" direction="left" scrollamount="2" style="margin-top: 10px"><img src="/iconvip/may2.png"></marquee>
</div>';
}else{
echo '<div class="nenkhaiquat_toi"></div>';
}

echo '<div class="conduong"></div><div class="cola" style="margin-top: -2px; min-height: 90px; text-align: center">';
if ($online_u > 0){
echo implode(' ',$u_on).'';
}else{
	echo 'Trống';
}
echo '</div>';
echo '<div class="list1"><form method="post"><input type="submit" name="submit" value="Khai Quật" /></form>';
if(isset($_POST['submit'])) {
if($dv['doben'] <= 0) {
echo 'Bạn đã mệt lắm rồi không thể khai quật tiếp được nữa, hãy nghĩ ngơi dưỡng sức đi nhé!';
} else {
$tien = rand(100, 700);
$da = rand(50, 250);
$rand = rand(1, 11);
$sucluc = 10;
if($rand == 1) {
mysql_query("UPDATE `daovang` SET `vang`=`vang`+'1', `coin`=`coin`+'{$tien}' WHERE `user_id`='{$user_id}'");

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");
echo '<img src="img/vang1.png" width="32"  alt="Vang" /> Bạn vừa đào được một cục vàng trị giá '.$tien.' Xu';
}
if($rand == 2) {
mysql_query("UPDATE `daovang` SET `kcuong`=`kcuong`+'1', `coin`=`coin`+'{$kcuong}' WHERE `user_id`='{$user_id}'");

mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `giamua`, `giaban`, `sucmanh`) VALUES  ('1', 'da', '".$user_id."', '0','0','0') ");

echo '<img src="img/kcuong.png" alt="Kim cương" width="32px"/> Bạn vừa đào được một viên kim cương xanh, xin chúc mừng!';
}
if($rand == 3) {
if($dv['doben'] < 20){
	echo 'Sức của bạn còn quá yếu, không thể kéo nổi hòn đá này. Bạn đã đành phải bỏ lại tảng đá và ra về tay trắng';
}else{

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$da}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$da}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");
echo '<img src="img/da.png" width="32" alt="Đá" /> Bạn đào phải tảng đá lớn mất khá nhiều sức mới mang nó lên được và bán đượć '.$da.' Xu!';
$sucluc = 10;
}
}
if($rand == 4) {

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");
echo '<img src="img/tuitien.png" alt="Túi tiền" /> Bạn vừa đào được món đồ cổ và bán đi được '.$tien.' Xu!';
}
if($rand == 5) {
mysql_query("UPDATE `daovang` SET `vang`=`vang`+'1', `coin`=`coin`+'{$tien}' WHERE `user_id`='{$user_id}'");

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");
echo '<img src="img/vang1.png" width="32"  alt="Vang" /> Bạn vừa đào được một cục vàng trị giá '.$tien.' Xu';
}
if($rand == 6) {
mysql_query("UPDATE `daovang` SET `vang`=`vang`+'1', `coin`=`coin`+'{$tien}' WHERE `user_id`='{$user_id}'");

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");

echo '<img src="img/vang1.png" width="32"  width="32"  alt="Vang" /> Bạn vừa đào được một cục vàng trị giá '.$tien.' Xu';
}
if($rand == 7) {
mysql_query("UPDATE `daovang` SET `vang`=`vang`+'1', `coin`=`coin`+'{$tien}' WHERE `user_id`='{$user_id}'");

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");

echo '<img src="img/vang1.png" width="32"  width="32"  alt="Vang" /> Bạn vừa đào được một cục vàng trị giá '.$tien.' Xu';
}
if($rand == 8) {
mysql_query("UPDATE `daovang` SET `vang`=`vang`+'1', `coin`=`coin`+'{$tien}' WHERE `user_id`='{$user_id}'");

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");

echo '<img src="img/vang1.png" width="32"  width="32"  alt="Vang" /> Bạn vừa đào được một cục vàng trị giá '.$tien.' Xu';
}
if($rand == 9) {
if($dv['doben'] < 20){
	echo 'Sức của bạn còn quá yếu, không thể kéo nổi hòn đá này. Bạn đã đành phải bỏ lại tảng đá và ra về tay trắng';
}else{

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$da}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$da}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");
echo '<img src="img/da.png" alt="Đá" /> Bạn đào phải tảng đá lớn mất khá nhiều sức mới mang nó lên được và bán đượć '.$da.' Xu!';
$sucluc = 10;
}
}
if($rand == 10) {

mysql_query("UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`+'{$tien}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");

echo '<img src="img/tuitien.png" width="32" alt="Túi tiền" /> Bạn vừa đào được món đồ cổ và bán đi được '.$tien.' Xu!';
}
if($rand == 11) {
if($datauser['balans'] >= $tien){
mysql_query("UPDATE `users` SET `balans`=`balans`-'{$tien}' WHERE `id`='{$user_id}'");
$q="UPDATE `users` SET `balans`=`balans`-'{$tien}' WHERE `id`='{$user_id}'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./sanbay/daohoang/index.php','".date('d-m-Y  h:i:s A')."')");

echo '<img src="img/tuitien.png" width="32" alt="Túi tiền" /> Bạn gặp thú dữ, và bị thú dữ đuổi. Bạn chạy bạt mạng và thoát chết nhưng lại rơi mất '.$tien.' Xu!';
}else{
	mysql_query("UPDATE `users` SET `balans`= '0' WHERE `id`='{$user_id}'");

echo '<img src="img/tuitien.png" width="32" alt="Túi tiền" /> Bạn gặp thú dữ, và bị thú dữ đuổi. Bạn chạy bạt mạng và thoát chết nhưng lại rơi mất hết số tiền trong túi!';
}
}
mysql_query("UPDATE `daovang` SET `doben`=`doben`-'{$sucluc}' WHERE `user_id`='{$user_id}'");
}
}
echo '</div></div>';
echo '

<div class="list1"><table width="100%"><tbody><tr><td width="6%"><img class="avatarfr" src="/avatar/'.$user_id.'.png" width="32" height="32" alt="">&nbsp;</td><td class="list3" width="80%"><img src="/images/online.png"><b> <font color="red">'.$datauser['name'].'</font></b><div class="sub"><div>
<span class="gray"><img src="img/vang1.png" width="12px"> </span> <b>'.$dv['vang'].' </b> Thỏi
<br><img src="img/kcuong.png" width="12px"> <b>'.$dv['kcuong'].'</b> Viên
</div></div></td></tr></tbody></table></div>
';
require('../../incfiles/end.php');
?>
