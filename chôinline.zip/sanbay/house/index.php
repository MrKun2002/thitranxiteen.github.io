<?php 
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
require_once('inc.php');
$textl = 'Hollywood - Nhà Ở Đẹp Nhất';
?>
<?php
require('../../incfiles/head.php');
?>
<style>
body{
		min-width: <?php echo 336+$css;?>px;
		text-algin: center;
	}
</style>
<?php
echo '<div class="phdr">Nhà Của Bạn</div>';
if(isset($_GET[yes_nha])) echo '<div class="rmenu list-top" style="text-align: center; font-size: 16px;">Mua Nhà Thành Công Rồi, hãy cố gắng trang trí nó thật là đẹp mắt nhé!.. </div>';
if(isset($_GET[no_tien])) echo '<div class="rmenu list-top" style="text-align: center; font-size: 16px;">Bạn không đủ xu để mua ngôi nhà này.. </div>';
if(isset($_GET[no_lv])) echo '<div class="rmenu list-top" style="text-align: center; font-size: 12px;">Cấp độ của ngôi nhà không được lớn hơn cấp độ chính của bạn, hãy đi đăng bài viết tại cộng đồng hoặc quay số để nhận điểm kinh nghiệm tăng cấp độ chính nhé.. </div>';
if(isset($_GET[yes_lv])) echo '<div class="rmenu list-top" style="text-align: center; font-size: 12px;">Nâng cấp thành công. </div>';
if(isset($_GET[no_tiennc])) echo '<div class="rmenu list-top" style="text-align: center; font-size: 12px;">Bạn không đủ tiền để nâng cấp ngôi nhà của bạn </div>';
$sql_nha = "SELECT * FROM gamemini_house_users WHERE user_id = '{$user_id}'";
$data->query($sql_nha);
$rows = $data->num_rows();
$assoc = $data->fetch_assoc();
if($rows == 0){
	if(isset($_GET[mua])){
	if(isset($_POST[dongy])){
		if($datauser[balans] >= 10000){
			$insert = "INSERT INTO gamemini_house_users SET user_id = '{$user_id}'";
			$data->query($insert);
			$update = "UPDATE users SET `balans` = `balans` - '10000' WHERE id = '{$user_id}' LIMIT 1";
			$data->query($update);
			header('Location: ../house/?yes_nha');
		}else{
			header('Location: ../house/?no_tien');
		}
	}elseif(isset($_POST[khong])){
		header('Location: ../house/');
	}
	echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn có muốn thật sự mua nhà này không?<br/>
	<form action="" method="post">
	<input type="submit" name="dongy" value="Có"/>
	<input type="submit" name="khong" value="Không"/>
	</form>
	</div>';
	}
	echo 'Bạn chưa có nhà để ở hả, tội nghiệp quá, cố gắng kiếm đủ <b>10.000 Xu</b> mà sắm cho mình cái nhà đi..';
	echo '<div class="list5"><a id="nut" href="?mua">Mua Nhà Thôi</a></div>';
}else{
	if(isset($_GET[nangcap])){
		if($assoc[lerver] == 0){
			$tiencan = 50000;
		}else{
			$tiencan = 100000*$assoc[lerver];
		}
		if(isset($_POST[dongy])){
			
			if(exp_chinhc($datauser[exp_chinh]) > $assoc[lerver] && $datauser[balans] >= $tiencan){
				$update_1 = "UPDATE users SET `balans` = `balans` - '{$tiencan}' WHERE id = '{$user_id}' LIMIT 1";
				$update_2 = "UPDATE gamemini_house_users SET `lerver` = `lerver` + '1' WHERE user_id = '{$user_id}' LIMIT 1";
				$data->query($update_1);
				$data->query($update_2);
				header('Location: ../house/?yes_lv');
			}elseif(exp_chinhc($datauser[exp_chinh]) <= $assoc[lerver]){
				header('Location: ../house/?no_lv');
			}elseif($datauser[balans] < $tiencan){
				header('Location: ../house/?no_tiennc');
			}
		}elseif(isset($_POST[khong])){
			header('Location: ../house/');
		}
		echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn có muốn nâng cấp ngôi nhà này lên với giá <b>'.$tiencan.'</b> xu không ?<br/>
		<form action="" method="post">
		<input type="submit" name="dongy" value="Có"/>
		<input type="submit" name="khong" value="Không"/>
		</form>
		</div>';
	}
	if($datauser[giaodien] == 1){
		include('hd.php');
	}else{
		include('low.php');
	}
	echo '<div class="list5"><a id="nut" href="edit/">Chỉnh Sửa Nhà</a> <a id="nut" href="shop/">Mua Sắm Đồ</a> <a id="nut" href="?nangcap">Mở Rồng Thêm</a></div>';
}
echo '<div class="list5"><a id="nut" href="bxh.php">Bảng Xếp Hạng</a></div>';
require('../../incfiles/end.php');
?>