<?php
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
$textl = 'Chơi chẵn lẻ';
require_once('../../incfiles/head.php');
if (!$user_id) {
echo functions::display_error($lng['access_guest_forbidden']);
require('../../incfiles/end.php');
exit;
}
mysql_query("UPDATE `users` SET `can-cau` = '7' WHERE `id` = '".$datauser['id']."' LIMIT 1");
echo '<div class="mainblok"><div class="phdr"><b>Chơi chẵn lẻ</b></div>';
if($user_id ==1) {

$id = (int)$_GET['id'];
switch($act) {
default:
if(isset($_POST['submit'])){
$idchoi =intval($_POST['idchoi']);
$chon = intval($_POST['chon']);
$datcuoc = intval($_POST['datcuoc']);
$sql = mysql_query("SELECT * FROM `users` WHERE `id`= '".$idchoi."'");
$arr_sql = mysql_fetch_array($sql);
$archon = array(
1 => 'Chẵn',
2 => 'Lẻ'
);
$s_ql = mysql_query("SELECT * FROM `users`");
$arr = mysql_fetch_array($s_ql);
$ktid  =  mysql_result(mysql_query("SELECT COUNT(`id`)FROM `users` WHERE `id`='".$idchoi."'" ), 0);
if(empty($idchoi)) {
echo '<div class="rmenu">Bạn chưa nhập ID người chơi!</div>';
} else if($ktid == 0) {
echo '<div class="rmenu">ID người chơi không tồn tại!</div>';
} else if(empty($datcuoc)) {
echo '<div class="rmenu">Bạn chưa nhập số tiền đặt cược!</div>';
} else if($datcuoc <= 10) {
echo '<div class="rmenu">Bạn phải đặt cược với số tiền cần >= 10
Xu!</div>';
}	else if($datcuoc > 2000 ) {
echo '<div class="rmenu">Bạn phải đặt cược với số tiền cần < 2000 Xu
Xu!</div>';
} else if($datauser['balans'] < $datcuoc) {
echo '<div class="rmenu">Nội dung bạn nhập không phải chữ số hoặc tài khoản của bạn không đủ tiền, tài khoản của bạn cần >= số tiền đặt cược!</div>';
} else if($arr_sql['balans'] < $datcuoc) {
echo '<div class="rmenu">Tài khoản người bạn mời chơi không đủ tiền để đặt cược!</div>';
} else {
echo '<div class="gmenu">ID muốn chơi: '.$idchoi.'<div style="color:blue;">Người chơi cùng: <b>'.$arr_sql['name'].'</b></div>Bạn chọn: '.$archon[$chon].'<br>Đặt cược: '.$datcuoc.' Xu';
echo '<br><form action="/gamemini/chanle/on.html?act=resume_true&idchoi='.$idchoi.'&chon='.$chon.'&datcuoc='.$datcuoc.'" method="post"><input type="submit" name="mit" value="Tiếp tục"> -- <a href="/gamemini/chanle/on.html?act=resume_false">Hủy</a></form></div>';
}
} else {
echo '<div class="list1">';
echo 'Bạn đang có: '.$datauser['balans'].' Xu<br>';
echo '<form action="/gamemini/chanle/on.html" method="post">ID người cùng chơi:<br><input type="text" name="idchoi" value="'.$id.'" size="20"/><br>';
echo 'Bạn chọn:<br><select name="chon"><option value="1">-- Chẵn --</option><option value="2">-- Lẻ --</option></select>';
echo '<br>Số tiền cược:<br><input type="text" name="datcuoc" value="" size="20"/><br><input type="submit" value="Chơi thôi" name="submit" /><br />';
echo '</div>';
echo '<div class="phdr">Hướng dẫn</div><div class="list1">- Bạn hãy nhập ID người cùng chơi với bạn, chọn Chẵn hoặc Lẻ và chọn số tiền đặt cược, nó sẽ yêu cầu bạn xác nhận thông tin, bạn chọn "Tiếp tực" để gửi thư mời chơi và chọn "Hủy" để hủy bỏ lời mời.<br>- Bạn sẽ bị trừ số Xu = số Xu đã đặt cược nếu bạn thua khi đối phương có cùng đáp án với bạn.<br>Vd: Bạn chọn Chẵn, đối phương chọn chẵn thì bạn thua<br>- Bạn sẽ nhận được số Xu = 95% số Xu đã đặt cược nếu bạn thắng khi đối phương có đáp án khác bạn.<br>Vd: Bạn chọn chẵn đối phương chọn lẻ thì bạn thắng, 5% còn lại trừ vào phí dịch vụ.<br>Lưu ý: khi đặt cược số tiền của bạn sẽ bị trừ, sau 5 phút mà người được mời chơi không hồi đáp
số tiền sẽ được hoàn lại cho bạn.<br>Nếu bạn thắng cả số tiền cược và số tiền thắng cược sẽ được cộng vào tài khoản của bạn</div>';
}
break;
case 'resume_true':
$idchoi = (int)$_GET['idchoi'];
$chon = (int)$_GET['chon'];
$datcuoc = (int)$_GET['datcuoc'];
if(isset($_POST['mit'])) {
if($datauser[balans] >= $datcuoc){
$sql = mysql_query("SELECT * FROM `users` WHERE `id`= '".$idchoi."'");
$arr_sql = mysql_fetch_array($sql);
mysql_query("INSERT INTO `chanle` SET
`time` = '".time()."',
`to_id` = '" . $user_id . "',
`to_tl` = '".$chon."',
`coin` = '".$datcuoc."',
`from_id` = '" . $idchoi . "';");
$ql = mysql_query("SELECT * FROM `users` WHERE `id`= '".$user_id."'");
$arr_ql = mysql_fetch_array($ql);
// Mod cho vao trong mail he thong
$theme = ''.$arr_ql['name'].' Mời bạn chơi chẵn lẻ';
$system = '<b>'.$arr_ql['name'].'</b> muốn mời bạn chơi chẵn lẻ cùng bạn ấy, bạn có đồng ý không?<br>Với số tiền cược là: '.$datcuoc.' Xu<br><a href="/gamemini/chanle/on.html?act=dongy&toid='.$user_id.'&idchoi='.$idchoi.'&datcuoc='.$datcuoc.'"><b>Đồng ý</b></a> -- <a href="/gamemini/chanle/on.html?act=khong&toid='.$user_id.'&idchoi='.$idchoi.'&datcuoc='.$datcuoc.'"><b>Hủy bỏ</b></a>';
mysql_query("INSERT INTO `hoatdong` SET
`time` = '".time()."',
`fr_user` = '" . $user_id . "',
`tiencuoc` = '".$datcuoc."',
`loinhan` = '" . mysql_real_escape_string($system) . "',
`type` = 'x',
`user_id` = '" . $idchoi . "';");
//
mysql_query("UPDATE `users` SET
`balans`=`balans` - ".$datcuoc." WHERE `id`='".$user_id."'");
$q="UPDATE `users` SET
`balans`=`balans` - ".$datcuoc." WHERE `id`='".$user_id."'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./gamemini/chanle/chanle.php','".date('d-m-Y  h:i:s A')."')");
echo '<div class="gmenu">Bạn đã mời chơi thành công!</div>';
}else{
	echo 'Số tiền của bạn quá ít để tiếp tục chơi';
}
} else {
echo '<div class="rmenu" align="center"><b>Đã có lỗi xảy ra!</b></div>';
}
break;
case 'resume_false':
echo '<div class="rmenu">Bạn đã hủy bỏ lời mời chơi!</div>';
break;
case 'dongy':
$toid = (int)$_GET['toid'];
$idchoi = (int)$_GET['idchoi'];
$datcuoc = (int)$_GET['datcuoc'];
$chontl = (int)$_POST['chontl'];
$tid  =  mysql_result(mysql_query("SELECT COUNT(`from_tl`)FROM `chanle` WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'" ), 0);
if($tid == 0) {
echo '<div class="rmenu">Không có ai muốn chơi chẵn lẻ với bạn. Có thể bạn đã trả lời rồi hoặc đã quá 5 phút mà bạn không hồi đáp lời mời đã bị xoá.</div>';
mysql_query("DELETE FROM `chanle` WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'");
mysql_query("DELETE FROM `hoatdong` WHERE `fr_user`= '".$toid."' AND `user_id`='".$idchoi."' AND `tiencuoc`='".$datcuoc."'");
} else {
if(isset($_POST['submitna'])){
$user_choi = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$toid."'"));
$ip = long2ip($user_choi['ip']);
$ip2 = long2ip($datauser['ip']);
if($ip != $ip2){
if($datauser['balans'] < $datcuoc) {
echo '<div class="rmenu">Tài khoản của bạn cần >= số tiền đặt cược!</div>';
} else {
mysql_query("UPDATE `chanle` SET
`from_tl`='".$chontl."' WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'");
$idto = mysql_query("SELECT * FROM `chanle` WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'");
$arid = mysql_fetch_array($idto);
$id_na = mysql_query("SELECT * FROM `users` WHERE `id`='".$arid['to_id']."'");
$na = mysql_fetch_array($id_na);
$id_na2 = mysql_query("SELECT `name` FROM `users` WHERE `id`='".$arid['from_id']."'");
$na2 = mysql_fetch_array($id_na2);
$chonarr = array(
1 => 'Chẵn',
2 => 'Lẻ'
);
$a = $datcuoc;
$b = 100;
$c = 95;
if($arid['to_tl'] == $arid['from_tl']) {
echo '<div class="gmenu">Bạn đã thắng vì đoán đúng với đáp án của '.$na['name'].' là <b>'.$chonarr[$arid['to_tl']].'</b></div>';
mysql_query("DELETE FROM `chanle` WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'");
mysql_query("DELETE FROM `hoatdong` WHERE `fr_user`= '".$toid."' AND `user_id`='".$idchoi."' AND `tiencuoc`='".$datcuoc."'");
$noidungtl = 'Bạn đã thua, '.$na2['name'].' đã thắng vì có đáp án là <b>'.$chonarr[$arid['to_tl']].'</b>, giống như câu trả lời của bạn!<br>Bạn sẽ bị trừ '.$a/$b*$c.' Xu';
mysql_query("INSERT INTO `hoatdong` SET
`time` = '".time()."',
`fr_user` = '" . $idchoi . "',
`tiencuoc` = '".$datcuoc."',
`loinhan` = '" . mysql_real_escape_string($noidungtl) . "',
`type` = 'x',
`user_id` = '" .$toid. "';");
mysql_query("insert into `privat` values(0,'".$na['name']."','" . $noidungtl . "','" .time(). "','Báo kết quả','in','no','Chẵn lẻ','0','','','','" . mysql_real_escape_string($fname) . "');");
mysql_query("UPDATE `users` SET
`balans`=`balans` + ".$a/$b*$c." WHERE `id`='".$user_id."'");
$q="UPDATE `users` SET
`balans`=`balans` + ".$a/$b*$c." WHERE `id`='".$user_id."'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./gamemini/chanle/chanle.php','".date('d-m-Y  h:i:s A')."')");

} else if($arid['to_tl'] == 1 && $arid['from_tl'] == 2) {
echo '<div class="gmenu">Bạn đã thua vì chọn <b>'.$chonarr[$arid['from_tl']].'</b> không trùng với đáp án của '.$na['name'].'<br>'.$na['name'].' có đáp án là <b>'.$chonarr[$arid['to_tl']].'</b>!</div>';
$noidungtl = 'Bạn đã thắng vì chọn <b>'.$chonarr[$arid['to_tl']].'</b>, bạn '.$na2['name'].' đã thua vì đáp án không trùng với bạn.<br>- '.$na2['name'].' có đáp án là<b>'.$chonarr[$arid['from_tl']].'</b><br>Bạn sẽ nhận được '.$a/$b*$c.' Xu từ '.$na2['name'].'';
mysql_query("INSERT INTO `hoatdong` SET
`time` = '".time()."',
`fr_user` = '".$idchoi."',
`tiencuoc` = '".$datcuoc."',
`loinhan` = '".mysql_real_escape_string($noidungtl)."',
`type` = 'x',
`user_id` = '".$toid."';");
mysql_query("insert into `privat` values(0,'".$na['name']."','" . $noidungtl . "','" .time(). "','Báo kết quả','in','no','Chẵn lẻ','0','','','','" . mysql_real_escape_string($fname) . "');");
mysql_query("UPDATE `users` SET
`balans`=`balans` - ".$datcuoc." WHERE `id`='".$user_id."'");
$q="UPDATE `users` SET
`balans`=`balans` - ".$datcuoc." WHERE `id`='".$user_id."'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./gamemini/chanle/chanle.php','".date('d-m-Y  h:i:s A')."')");

mysql_query("UPDATE `users` SET
`balans`=`balans` + ".$datcuoc." + ".$a/$b*$c." WHERE `id`='".$arid['to_id']."'");
$q="UPDATE `users` SET
`balans`=`balans` + ".$datcuoc." + ".$a/$b*$c." WHERE `id`='".$arid['to_id']."'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./gamemini/chanle/chanle.php','".date('d-m-Y  h:i:s A')."')");

} else if($arid['to_tl'] == 2 && $arid['from_tl'] == 1) {echo '<div class="gmenu">Bạn đã thua vì chọn <b>'.$chonarr[$arid['from_tl']].'</b> không trùng với đáp án của '.$na['name'].'<br>'.$na['name'].' có đáp án là <b>'.$chonarr[$arid['to_tl']].'</b>!</div>';
$noidungtl = 'Bạn đã thắng vì chọn <b>'.$chonarr[$arid['to_tl']].'</b>, bạn '.$na2['name'].' đã thua vì đáp án không trùng với bạn.<br>- '.$na2['name'].' có đáp án là<b>'.$chonarr[$arid['from_tl']].'</b><br>Bạn sẽ nhận được '.$a/$b*$c.' Xu từ '.$na2['name'].'';
mysql_query("INSERT INTO `hoatdong` SET
`time` = '".time()."',
`fr_user` = '".$idchoi."',
`tiencuoc` = '".$datcuoc."',
`loinhan` = '" . mysql_real_escape_string($noidungtl) . "',
`type` = 'x',
`user_id` = '".$toid."';");
mysql_query("insert into `privat` values(0,'".$na['name']."','" . $noidungtl . "','" .time(). "','Báo kết quả','in','no','Chẵn lẻ','0','','','','" . mysql_real_escape_string($fname) . "');");
mysql_query("UPDATE `users` SET
`balans`=`balans` + ".$datcuoc." + ".$a/$b*$c." WHERE `id`='".$arid['to_id']."'");
$q="UPDATE `users` SET
`balans`=`balans` + ".$datcuoc." + ".$a/$b*$c." WHERE `id`='".$arid['to_id']."'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./gamemini/chanle/chanle.php','".date('d-m-Y  h:i:s A')."')");
mysql_query("UPDATE `users` SET
`balans`=`balans` - ".$a." WHERE `id`='".$user_id."'");
$q="UPDATE `users` SET
`balans`=`balans` - ".$a." WHERE `id`='".$user_id."'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./gamemini/chanle/chanle.php','".date('d-m-Y  h:i:s A')."')");
}
mysql_query("DELETE FROM `chanle` WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'");
mysql_query("DELETE FROM `hoatdong` WHERE `fr_user`= '".$toid."' AND `user_id`='".$idchoi."' AND `tiencuoc`='".$datcuoc."'");
}
}else{	echo 'Hệ thống phát hiện nick phụ, bạn không thể tham gia chơi với người này';}
} else {
echo '<div class="list1">';
echo '<form action="/gamemini/chanle/on.html?act=dongy&toid='.$toid.'&idchoi='.$idchoi.'&datcuoc='.$datcuoc.'" method="post">';
echo 'Bạn đang có: '.$datauser['balans'].' Xu<br>';
echo 'Bạn chọn:<br><select name="chontl"><option value="1">-- Chẵn --</option><option value="2">-- Lẻ --</option></select>';
echo '</div><div class="gmenu">';
echo 'Với số tiền cược là: '.$datcuoc.'<br>Nếu bạn thua bạn sẽ bị trừ số Xu = Số Xu đặt cược. Nếu bạn thắng bạn sẽ nhận được từ '.$na['name'].' 95% số Xu = số Xu đặt cược, 5% số tiền sẽ trừ vào phí dịch vụ.<br><input type="submit" value="Chơi" name="submitna" /><br /></from>';
echo '</div>';
}
}
break;
case 'khong':
$toid = (int)$_GET['toid'];
$idchoi = (int)$_GET['idchoi'];
$datcuoc = (int)$_GET['datcuoc'];
$tkid  =  mysql_result(mysql_query("SELECT COUNT(`from_tl`)FROM `chanle` WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'"), 0);
if($tkid == 0) {
echo '<div class="rmenu"><b>Không có ai muốn chơi chẵn lẻ với bạn!</b><br>Có thể lời mời đã bị hủy hoặc bạn đã trả lời rồi hoặc lời mời đã quá hạn 5 phút nó sẽ tự động xoá</div>';
mysql_query("DELETE FROM `chanle` WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'");
mysql_query("DELETE FROM `hoatdong` WHERE `fr_user`= '".$toid."' AND `user_id`='".$idchoi."' AND `tiencuoc`='".$datcuoc."'");
} else {
$user_t = mysql_query("SELECT `name` FROM `users` WHERE `id`= '".$toid."'");
$user_to = mysql_fetch_array($user_t);
$user_fr = mysql_query("SELECT `name` FROM `users` WHERE `id`= '".$idchoi."'");
$user_from = mysql_fetch_array($user_fr);
mysql_query("UPDATE `users` SET
`balans`=`balans` + ".$datcuoc." WHERE `id`='".$toid."'");
$q="UPDATE `users` SET
`balans`=`balans` + ".$datcuoc." WHERE `id`='".$toid."'";
mysql_query("insert into `tblabclog` values('".$_SESSION['userlg']."','".$q."','./gamemini/chanle/chanle.php','".date('d-m-Y  h:i:s A')."')");
echo '<div class="rmenu">Bạn đã hủy bỏ lời mời chơi của '.$user_to['name'].'!</div>';
$noidungtl = 'Bạn '.$user_from['name'].' đã từ chối lời mời chơi chẵn lẻ của bạn!<br>Hệ thống sẽ hoàn tiền cho bạn.';
mysql_query("INSERT INTO `hoatdong` SET
`time` = '".time()."',
`fr_user` = '" . $idchoi . "',
`tiencuoc` = '".$datcuoc."',
`loinhan` = '" . mysql_real_escape_string($noidungtl) . "',
`type` = 'x',
`user_id` = '" .$toid. "';");
mysql_query("DELETE FROM `chanle` WHERE `to_id`= '".$toid."' AND `from_id`='".$idchoi."' AND `coin`='".$datcuoc."'");
mysql_query("DELETE FROM `hoatdong` WHERE `fr_user`= '".$toid."' AND `user_id`='".$idchoi."' AND `tiencuoc`='".$datcuoc."'");
}
break;
case 'delall':
if($datauser['rights'] >= 9) {
mysql_query("DELETE FROM `chanle`");
echo 'Bạn đã xoá sạch dữ liệu chẵn lẻ!';
} else {
echo 'Bạn không đủ thẩm quyền';
}
break;
}
}
else{
echo' bảo trì';
}
echo '</div>';
require('../../incfiles/end.php');
?>
