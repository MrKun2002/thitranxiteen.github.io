<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Menu game mini';
require_once('../incfiles/head.php');
mysql_query("UPDATE `users` SET `can-cau` = '7' WHERE `id` = '".$datauser['id']."' LIMIT 1");
echo '<div class="phdr"><b>GAME MINI</b></div>';
echo '<div class="gmenu">
<div class="rmenu"><center>
<div style="height: 70px; text-align: center; margin: auto;">
<span style="width:30%;text-align:center;padding:4px; float: left;">
<a href="/gamemini/ai-la-trieu-phu"><img src="/images/altp.png" alt="icon"><br><b>Ai là triệu phú</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left;">
<a href="/gamemini/caroonline/"><img src="/images/caro.png" alt="icon"><br><b>Caro Online</b></a>
</span><span style="width:30%;text-align:center;padding:4px; float: left;">
<a href="/gamemini/batchu/"><img src="/images/batchu.png" alt="icon"><br><b>Đuổi Hình Bắt Chữ</b></a>
</span><div type="clear: both"></div>
</center>
</div>

</div>
';
require_once('../incfiles/end.php');
?>