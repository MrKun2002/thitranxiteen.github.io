<?php
define('_IN_JOHNCMS', 1);
$rootpath = '';
require('../../incfiles/core.php');
if($_POST['noidung'] && $_POST['tid']){
		$message= mb_substr($_POST['noidung'], 0, 40);
		
 $sql_ary_chat = array(
			'uid'			=> $datauser['id'],
			'cmt'			=> $message,
			'tid'			=> $_POST['tid'],
				);
		$sql = 'INSERT INTO carocmt (uid, cmt, tid) VALUES ('.$datauser['id'].', "'.$message.'", '.$_POST['tid'].') ';
		mysql_query($sql);
}
header('Location: /gamemini/caroonline/?id='.$_POST['tid'].'#chat');
?>
