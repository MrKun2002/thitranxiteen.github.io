<?php

define('_IN_JOHNCMS', 1);
$textl = ' Tin tức sự kiện ';
$headmod = 'nick';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

echo '<div class="main"><div class="phdr"><b>Thông tin - Sự kiện</b> </div>';
echo '
- <a href="/khuyenmai.html"><b>khuyến mãi nạp xu lượng từ 10/5-13/5</b></a><br> 

- <a href="/banggia.html"><b>Bảng giá nạp xu lượng</b></a><br> 

</div>';




echo'</div>';

echo'</div>';




require_once ("../incfiles/end.php");
?>
