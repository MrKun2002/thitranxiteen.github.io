<?php

define('_IN_JOHNCMS', 1);
$textl = ' Bảng giá nạp xu - lượng ';
$headmod = 'nick';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

echo '<div class="main"><div class="phdr"><b>Bảng giá nạp xu - lượng</b> </div>';
echo 'đây là bảng giá nạp cố định nhé tức là khi không khuyến mãi<br>
<b>* Bảng giá nạp lượng </b><br>
Mệnh giá -> Lượng<br>
- 10k -> 10 lượng<br>
- 20k -> 25 lượng<br>
- 30k -> 38 lượng<br>
- 50k -> 70 lượng<br>
- 100k -> 150 lượng<br>
- 200k -> 350 lượng<br>
- 500k -> 1100 lượng<br>
<b>* Bảng giá nạp xu </b><br>
Mệnh giá -> xu<br>
- 10k -> 10000 xu<br>
- 20k -> 25000 xu<br>
- 30k -> 38000 xu<br>
- 50k -> 70000 xu<br>
- 100k -> 150000 xu<br>
- 200k -> 350000 xu<br>
- 500k -> 1100000 xu<br>
</div>';




echo'<a href="/tintuc.html"><b>Xem các tin tức khác</b></a></div>';

echo'</div>';




require_once ("../incfiles/end.php");
?>
