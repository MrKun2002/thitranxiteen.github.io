<?php

define('_IN_JOHNCMS', 1);
$textl = ' khuyến mại khi nạp xu lượng ';
$headmod = 'nick';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");

echo '<div class="main"><div class="phdr"><b>Thông tin - Sự kiện</b> </div>';
echo '<b>Chương trình khuyến mãi khi nạp xu và lượng diễn ra từ 17h ngày 10/5 - 17h ngày 13/5 </b><br> khi nạp xu hoặc lượng tại ChoiOnline các bạn sẽ được khuyến mãi như sau<br>- Khi nạp xu, lượng = các mệnh giá từ 20k đến 50k sẽ được khuyến mãi 50% giá trị thẻ nạp.<br>- khi nạp xu, lượng các mệnh giá từ 100k trở lên sẽ được khuyến mãi 100% giá trị thẻ nạp.<br><a href="/banggia.html"><b>Bảng giá nạp xu lượng khi không khuyến mãi</b><br></a> trân trọng!</div>';




echo'<a href="/tintuc.html"><b>Xem các tin tức khác</b></a></div>';

echo'</div>';




require_once ("../incfiles/end.php");
?>
