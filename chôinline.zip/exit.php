<?php
//---MOD-BY-BONGMA007---//

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

define('_IN_JOHNCMS', 1);

$rootpath = '';
require('incfiles/core.php');
$referer = isset($_SERVER['HTTP_REFERER']) ? htmlspecialchars($_SERVER['HTTP_REFERER']) : core::$system_set['homeurl'];

if (isset($_POST['submit'])) {
    setcookie('cuid', '');
    setcookie('cups', '');
    session_destroy();
    header('Location: index.php');
} else {
    require('incfiles/head.php');
    echo'<div class="rmenu">' .
        '<p>Chúc bạn luôn vui vẻ khi đến với diễn đàn!<br />
Hệ thống tự động xoá Cookie.. loadding 99% <img src="../images/loading.gif" /></p>' .
        '<form action="exit.php" method="post"><p><input type="submit" name="submit" value="Thoát" /><a href="/"><input class="huy" type="button"  value="Huỷ"></a></form>' .
        '</div>';
    require('incfiles/end.php');
}