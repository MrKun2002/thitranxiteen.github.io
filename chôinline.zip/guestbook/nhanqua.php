<?php
/////////////////////////////////////////////////////
//---CODE VIẾT BỞI Forum viet.MOBI - VODOIVN VTG---//
///////////////////////////////////////////////////
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Sự Kiện';
require('../incfiles/head.php');
if($user_id){
	// Index Even
	date_default_timezone_set('Asia/Ho_Chi_Minh');
	$kiemtra = date("H");
	$kiemtra2 = date("i");
	$kiemtra3 = date("s");
	$kiemtra4 = date("d");
	echo '<div class="phdr">NHẬN QUÀ</div><div class="gmenu">';
	if($kiemtra4 == 8 && $datauser['time_qua_even'] != 8 && $datauser['sex'] == 'zh'){
	echo '<div class="list4">Chúc bạn ngày càng duyên dáng và xinh đẹp trong mắt con trai như AD :D. AD xin tặng các bạn 15 lượng làm món quà ngày hôm nay cho các bạn!</div></div>';
		mysql_query("UPDATE `users` SET `luong` = `luong`+15, `time_qua_even` = 8 WHERE `id` = ".$user_id."");
	}else{
		echo '<div class="list4">Bạn đã nhận quà rồi hoặc bạn không phải là nữ!</div></div>';
	}
}		
require('../incfiles/end.php');
?>