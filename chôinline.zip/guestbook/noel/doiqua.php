<?php
define('_IN_JOHNCMS', 0);
$textl = 'Ông già noel và túi quà';
require_once ('../../incfiles/core.php');
require_once ('../../incfiles/head.php');
include('function.php');
$data['name'] = "Túi Quà";
$data['sukien'] = "noel";
$data['linkpage'] = 'doiqua.php';
$data['start'] = $start;
$data['kmess'] = $kmess;
// if(isset($_GET['yes_vp'])){
// echo '<div class="thongbao">Đổi món quà thành công</div>';
// }
// if(isset($_GET['doiqua'])){
	// echo '<div class="phdr">'.$data['name'].'</div>';
	// $int = intval($_GET['doiqua']);
	ID item even hiện tại
	// $sql = mysql_query("SELECT * FROM `even_gamemini` WHERE `id` = '{$int}' AND `sukien` = '{$data['sukien']}'");
	// $count = mysql_num_rows($sql);
	// $vatpham = mysql_fetch_assoc($sql);
	// if($count > 0 && $datauser['diem_even'] >= $vatpham['sodiem']){	
		// ?>
			// <?php
				// if($_POST['co']){
					// mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`) VALUES  ('$vatpham[name_id]', '$vatpham[loaisp]', '".$user_id."' , '$vatpham[sucmanh]','$vatpham[giaban]', '$vatpham[name_vp]') ");
					// mysql_query("UPDATE `users` SET `diem_even` = `diem_even`-'{$vatpham['sodiem']}' WHERE `id` = '{$user_id}' LIMIT 1");
					// header('Location: doiqua.php?yes_vp');
				// }
				// if($_POST['khong']){
					// header('Location: doiqua.php');
				// }
			// ?>
			// <div class="thongbao">
				// Bạn có muốn đổi đồ này không ?
				// <br/>
				// <form method="POST">
					// <input type="submit" name="co" value="Đồng Ý"/>
					// <input type="submit" name="khong" value="Không"/>
				// </form>
			// </div>
		// <?php
	// }else{
		// echo '<div class="thongbao">Bạn không có đủ điểm để đổi món đồ này</div>';
	// }
// }else{
	// shop_even($data);
// }
require_once ('../../incfiles/end.php');
?>