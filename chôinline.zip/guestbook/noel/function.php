<?php
// Giao diện
// Hiển thị npc
function npc_even($data,$name_npc){
	echo '<div class="phdr">'.$name_npc['name'].'</div>';
?>
		<div class="list1">
			<table width="100%">
				<tbody>
					<tr>
						<td width="6%">
							<img src="<?php echo $name_npc['pic']; ?>" alt="">
						</td>
						<td style="padding: 0px;" width="80%">
						<div><b>[ <font color="red"><?php echo $name_npc['name']; ?></font> ]</b></div>
						<?php foreach($data as $item => $key){ ?>
							<div class="list3"><a href="<?php echo $key['url']; ?>"><?php echo $key['name']; ?></a></div>
						<?php } ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
<?php } ?>
<?php
// Hiển thị đồ đổi theo sự kiện....

function shop_even($even){
	echo '<div class="phdr">'.$even['name'].'</div>';
	$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `even_gamemini` WHERE `sukien` = '{$even['sukien']}'"), 0);
		echo '<div class="list1">Có tổng '.$tong.' món có thể để đổi quà nhé</div>';
		$res = mysql_query("SELECT * FROM `even_gamemini` WHERE `sukien` = '{$even['sukien']}' ORDER BY `id` DESC LIMIT {$even['start']}, {$even['kmess']}");
		while($post = mysql_fetch_array($res)){
		$sm= 'Tăng: '.$post['sucmanh'].' SM';
		echo '<div class="menu list-top">
		<table cellpadding="0" cellspacing="0" width="100%">
		<tbody><tr><td width="50">
		<img src="/images/'.$post['loaisp'].'/'.$post['name_id'].'.png" alt="*" class="portrait"/>
		</td><td width="auto" valign="top">';
		if($post['name_vp'] != ""){
			echo '<b>[ <span style="color: green">'.$post['name_vp'].'</span> ]</b></br>';
		}
		echo $sm;
		echo '<br/><b>Đổi đồ cần:</b>'.$post['sodiem'].' Điểm even</b><br/>';
		echo '<b>[ <a href="?doiqua='.$post['id'].'">Đổi Đồ Này</a> ]</b>
		</td></tr></tbody></table>
		</div>';
		}
		if ($tong > $kmess){ //Phân Trang
		echo '<div class="trang">' . functions::display_pagination($even['linkpage'].'?', $even['start'], $tong, $even['kmess']) . '</div>';
		}
	
?>	
<?php } ?>