<?php
define('_IN_JOHNCMS', 0);
$textl = 'Ông già noel';
require_once ('../../incfiles/core.php');
require_once ('../../incfiles/head.php');
include('function.php');
// if(isset($_GET['doikeo'])){
	// $kt_keo = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `loaisp` = 'vatpham' AND `name` = 4 AND `id_user` = $user_id"), 0);
	// if($kt_keo >= 1){
		// mysql_query("DELETE FROM `khodo` WHERE `id_user` = $user_id AND `loaisp` = 'vatpham' AND `name` = 4 LIMIT 1");
		// mysql_query("UPDATE `users` SET `diem_even` = `diem_even` + 1 WHERE `id` = '$user_id' LIMIT 1");
		// echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Đổi kẹo thành công, Ông già noel cho bạn lại 1 điểm thưởng!</div>';
	// }else{
		// echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn làm gì có kẹo mà đòi cho!</div>';
	// }
// }
// if(isset($_GET['doidochoi'])){
	// $kt_keo = mysql_result(mysql_query("SELECT COUNT(*) FROM `khodo` WHERE `loaisp` = 'vatpham' AND `name` = 5 AND `id_user` = $user_id"), 0);
	// if($kt_keo >= 1){
		// mysql_query("DELETE FROM `khodo` WHERE `id_user` = $user_id AND `loaisp` = 'vatpham' AND `name` = 5 LIMIT 1");
		// mysql_query("UPDATE `users` SET `diem_even` = `diem_even` + 1 WHERE `id` = '$user_id' LIMIT 1");
		// echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Đổi kẹo thành công, Ông già noel cho bạn lại 1 điểm thưởng!</div>';
	// }else{
		// echo '<div class="rmenu" style="text-align: center; font-size: 16px;">Bạn làm gì có kẹo mà đòi cho!</div>';
	// }
// }
// $npc['name'] = "Ông già noel và tuần lộc";
// $npc['pic'] = "noel.gif";
// $data[1]['url'] = 'ongnoel.php?doikeo';
// $data[1]['name'] = 'Đổi kẹo cho ông già noel';
// $data[2]['url'] = 'ongnoel.php?doidochoi';
// $data[2]['name'] = 'Đổi đồ chơi';
// npc_even($data,$npc);
require_once ('../../incfiles/end.php');
?>