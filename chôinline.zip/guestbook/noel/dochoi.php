<?php
define('_IN_JOHNCMS', 0);
$textl = 'Tìm kiếm đồ chơi';
require_once ('../../incfiles/core.php');
require_once ('../../incfiles/head.php');
include('function.php');
// echo '<div class="phdr">Khu vực tìm đồ chơi</div>';
// date_default_timezone_set('Asia/Ho_Chi_Minh');
// $gio = date("H");
// $phut = date("i");
// $timeConLai = 60-$phut;
// if(($gio == 12 && $gio < 13) || ($gio == 21 && $gio < 22)){
	// if($timeConLai > 0){
		// echo '<div class="list2">Thời gian hoạt động còn <span style="color: red;font-weight: bold;">'.$timeConLai.'</span> phút.</div>';
	// }else{
		// echo '<div class="list2">Đã hết thời gian hoạt động</div>';
	// }	
	// if($datauser['docamtay'] == 50){
		// if($_POST['submit']){
			// echo '<div class="list4">';
			// $time = time();
			// $tile = rand(1,4);
			// $sql = "SELECT * FROM `even_thamgia` WHERE `user_id` = '{$user_id}'";
			// $kiemtra = mysql_fetch_assoc(mysql_query($sql));
			// $num = mysql_num_rows(mysql_query($sql));
			// if($kiemtra['time_dao']+60 <= $time || $num == 0){
			// if($num > 0){
				// mysql_query("UPDATE `even_thamgia` SET `time_dao` = '{$time}' WHERE `user_id` = '{$user_id}' LIMIT 1");
			// }else{
				// mysql_query("INSERT INTO `even_thamgia` SET `time_dao` = '{$time}',`user_id` = '{$user_id}'");
			// }
			// if($tile == 1){
				// mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`, `thongtin`) 
				// VALUES  ('5', 'vatpham', '".$user_id."' , '0','0', 'Đồ chơi noel', 'Dùng cho sự kiện')
				// ");
				// echo 'Bạn tìm được một món đồ chơi';
				
			// }else{
				// echo 'Chỗ này không có đồ chơi bạn à';
			// }
			// }else{
				// echo 'Tôi mệt lắm rồi cho tôi nghỉ thêm tí để hồi sức tìm tiếp, thời gian ngỉ 1 phút';
			// }
		// }
		// ?>
			// </div><div class="list5">
			// <div style="margin-bottom: 10px;">Hãy thật chăm chỉ tìm những đồ chơi mà ông già noel đi đường bị đánh rơi, rồi mang cho ông già noel nhận thưởng nhé!<br/>
			// </div><div style="text-align: center"><form method="post">
				// <input type="submit" name="submit" value="Tìm đồ chơi"/>
			// </form>
			// </div>
		// <?php
	// }else{
		// echo '<div class="list4">';
		// echo 'Bạn không có cầm theo gậy tre, nếu không cầm gậy tre sẽ rất khó tìm đồ chơi, hay vào <b>SHOP</b> phần <a href="http://choionline.cf/shop/muasam/docamtay.html"><b>Đồ cầm tay</b></a> tìm gậy tre để mua rồi vào đây để tham gia hoạt động truy tìm đồ chơi thất lạc của ông già noel nhé!';
	// }
// }else{
	// echo '<div class="list4">';
	// echo 'Chưa đến giờ diễn ra hoạt động bạn ơi..';
// }
// echo '</div>';
require_once ('../../incfiles/end.php');
?>