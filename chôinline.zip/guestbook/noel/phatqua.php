<?php
define('_IN_JOHNCMS', 0);
$textl = 'Ông già noel';
require_once ('../../incfiles/core.php');
require_once ('../../incfiles/head.php');
date_default_timezone_set('Asia/Ho_Chi_Minh');
// echo '<div class="phdr">Chúc mừng năm mới</div><div class="list4">';
// $ngay = date("d");
// $gio = date("H");
// if($ngay == 1){
// $sql = "SELECT * FROM `even_thamgia` WHERE `user_id` = '{$user_id}'";
// $kiemtra = mysql_fetch_assoc(mysql_query($sql));
// $num = mysql_num_rows(mysql_query($sql));
// if($num > 0){
	// mysql_query("UPDATE `even_thamgia` SET `time_phatqua` = '{$ngay}' WHERE `user_id` = '{$user_id}' LIMIT 1");
// }else{
	// mysql_query("INSERT INTO `even_thamgia` SET `time_phatqua` = '{$ngay}',`user_id` = '{$user_id}'");
// }
// if($kiemtra['time_phatqua'] != $ngay){
	// $rand = rand(1,100);
	// if($rand >= 1 && $rand < 14){
		// mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`, `thongtin`) 
				// VALUES  ('5', 'da', '".$user_id."' , '0','0', 'Đá sức mạnh', 'Dùng để ép các đồ đã nâng cấp full mà dưới 10k sức mạnh')
				// ");
		// mysql_query("INSERT INTO `khodo` (`name` , `loaisp`, `id_user`, `sucmanh`, `giaban`, `tenvatpham`, `thongtin`) 
				// VALUES  ('5', 'da', '".$user_id."' , '0','0', 'Đá sức mạnh', 'Dùng để ép các đồ đã nâng cấp full mà dưới 10k sức mạnh')
				// ");
		// echo 'Bạn nhận được 2 viên đá ép X2 sức mạnh từ hộp quà năm mới';
	// }
	// if($rand >= 14 && $rand < 35){
		// $luong = rand(5,10);
		// mysql_query("UPDATE `users` SET `luong` = `luong`+'{$luong}' WHERE `id` = '{$user_id}'");
		// echo 'Bạn nhận được '.$luong.' lượng từ hộp quà năm mới';
	// }
	// if($rand >= 35 && $rand <= 100){
		// $xu = rand(30000,120000);
		// mysql_query("UPDATE `users` SET `balans` = `balans`+'{$xu}' WHERE `id` = '{$user_id}'");
		// echo 'Bạn nhận được '.$xu.' xu từ hộp quà năm mới';
	// }
// }else{
	// echo 'Bạn đã nhận quà rồi';
// }
// }else{
	// echo 'Chưa diễn ra sự kiện';
// }
// echo '</div>';
require_once ('../../incfiles/end.php');
// ?>