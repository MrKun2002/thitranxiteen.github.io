<?php
/////////////////////////////////////////////////////
//---CODE VIẾT BỞI Forum viet.MOBI - VODOIVN VTG---//
///////////////////////////////////////////////////
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
$textl = 'Sự Kiện';
require('../incfiles/head.php');
if($user_id){
// Index Even
date_default_timezone_set('Asia/Ho_Chi_Minh');
$kiemtra = date("H");
$kiemtra2 = date("i");
$kiemtra3 = date("s");
$kiemtra4 = date("d");
if(isset($_GET[top])){
	echo '<div class="phdr">THÔNG TIN VÀ BẢNG XẾP HẠNG EVEN</div><div class="gmenu">';
		 $dem = 0;
		echo '<div class="list5">
		Bạn đang có: '.$datauser[diem_even].'';
		$tong_bxh = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `diem_even` != 0"), 0);
		$res_bxh = mysql_query("SELECT * FROM `users` WHERE `diem_even` != 0 ORDER BY `diem_even` DESC");
		if($datauser[diem_even] != 0){
		echo ' Điểm thưởng và đang xếp hạng thứ';
		while ($post_bxh = mysql_fetch_array($res_bxh)){
		$dem++;
		if($post_bxh[id] == $user_id){
			echo ' <b>'.$dem.'</b>';
		}
		}
		}else{
			echo ' Điểm thưởng và chưa được xếp hạng tại đây, hãy cố gắng';
		}
		echo '</div></div>';
		$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `diem_even` != 0"), 0);
		$res = mysql_query("SELECT * FROM `users` WHERE `diem_even` != 0 ORDER BY `diem_even` DESC LIMIT $start, $kmess");
		echo "<div class='phdr'><b>TOP BẢNG XẾP HẠNG</b></div><div class='gmenu'>";
		echo '<div class="menu">Hiện có tổng '.$tong.' ae đã và đang tham gia even !</div>';
		while ($post = mysql_fetch_array($res)){
		echo '<div class="nenfr">
		<table cellpadding="0" cellspacing="0" width="100%">
		<tbody><tr><td width="50">
		<img src="/avatar/'.$post['id'].'.png" alt="*" class="portrait"/>
		</td><td width="auto" valign="top">';
		echo '
		Nick: '.$post['name'].'<br/>
		Đang có: <b>'.$post['diem_even'].'</b> Điểm Thưởng<br/>
		</td></tr></tbody></table>
		</div>';
		}
		if ($tong > $kmess){ //Phân Trang
		echo '<div class="trang">' . functions::display_pagination('npc.php?top&', $start, $tong, $kmess) . '</div>';
		}
	echo '</div></div>';
	require('../incfiles/end.php');
	exit;
}
echo '
<div class="phdr">Tiểu Zombie</div>
<div class="gmenu">';
echo '
<div class="list1"><table width="100%"><tbody><tr><td width="6%"><img src="img/NOEL.png" alt="">&nbsp;</td><td style="padding: 0px;" width="80%"><b>[ <font color="red">Tiểu Zombile</font> ]</b>
<div class="list3"><a href="noel/ongnoel.php">Cho Đổi kẹo và đồ chơi</a>
</div>
<div class="list3"><a href="noel/doiqua.php">Đổi Quà Sự Kiện</a>
</div>
<div class="list3"><a href="?top">Thành Tích và Xếp Hạng EVENT</a>
</div>
</div></div></td></tr></tbody></table></div>
';
}else{
	echo '<div class="list1">- Hãy đăng nhập để sử dụng chức năng này nhé!</div>';
}
echo '</div>';
require('../incfiles/end.php');
?>